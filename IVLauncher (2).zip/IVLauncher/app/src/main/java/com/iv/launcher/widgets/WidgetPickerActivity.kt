package com.iv.launcher.widgets

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.Intent
import android.os.Bundle
import android.os.Process
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import com.iv.launcher.data.WidgetCfg
import com.iv.launcher.data.WidgetKind
import kotlin.math.ceil

/** Lists all Android widgets on the phone (Gemini, Google, Spotify…) and adds the chosen one to home. */
class WidgetPickerActivity : ComponentActivity() {

    private var pendingId = -1
    private var pendingInfo: AppWidgetProviderInfo? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        WidgetHost.init(this)
        val pm = packageManager
        val providers = WidgetHost.manager.getInstalledProvidersForProfile(Process.myUserHandle())
            .map { info ->
                val appLabel = runCatching { pm.getApplicationLabel(pm.getApplicationInfo(info.provider.packageName, 0)).toString() }
                    .getOrDefault(info.provider.packageName)
                Triple(info, appLabel, info.loadLabel(pm) ?: "")
            }
            .sortedWith(compareBy({ !it.first.provider.packageName.contains("bard") && !it.first.provider.packageName.contains("googlequicksearchbox") }, { it.second.lowercase() }))

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                var q by remember { mutableStateOf("") }
                Column(Modifier.fillMaxSize().background(Color(0xFF0B0B0D)).statusBarsPadding().navigationBarsPadding()) {
                    Text("Add Android widget", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(20.dp))
                    Text(
                        "Gemini and Google are on top. Android may ask you once to allow IV to use widgets.",
                        color = Color(0xFF9A9AA2), fontSize = 13.sp, modifier = Modifier.padding(horizontal = 20.dp),
                    )
                    OutlinedTextField(
                        value = q, onValueChange = { q = it }, singleLine = true,
                        label = { Text("Search widgets") },
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                    )
                    val shown = providers.filter { q.isBlank() || it.second.contains(q, true) || it.third.contains(q, true) }
                    LazyColumn(Modifier.fillMaxSize()) {
                        items(shown, key = { it.first.provider.flattenToString() }) { (info, appLabel, label) ->
                            val icon = remember(info) {
                                runCatching { info.loadIcon(this@WidgetPickerActivity, resources.displayMetrics.densityDpi)?.toBitmap(96, 96)?.asImageBitmap() }.getOrNull()
                            }
                            Row(
                                Modifier.fillMaxWidth().clickable { pick(info) }.padding(horizontal = 20.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                if (icon != null) Image(icon, null, Modifier.size(40.dp))
                                else Spacer(Modifier.size(40.dp).background(Color(0xFF2A2A2E), RoundedCornerShape(10.dp)))
                                Spacer(Modifier.width(14.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(label, color = Color.White, fontSize = 15.sp)
                                    Text("$appLabel · ${cells(info).first}×${cells(info).second}", color = Color(0xFF9A9AA2), fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private fun cells(info: AppWidgetProviderInfo): Pair<Int, Int> {
        if (info.targetCellWidth > 0 && info.targetCellHeight > 0) {
            return info.targetCellWidth.coerceIn(1, 4) to info.targetCellHeight.coerceIn(1, 4)
        }
        val d = resources.displayMetrics.density
        val w = ceil((info.minWidth / d + 16) / 84f).toInt().coerceIn(1, 4)
        val h = ceil((info.minHeight / d + 16) / 100f).toInt().coerceIn(1, 4)
        return w to h
    }

    private fun pick(info: AppWidgetProviderInfo) {
        val id = WidgetHost.host.allocateAppWidgetId()
        pendingId = id
        pendingInfo = info
        if (WidgetHost.manager.bindAppWidgetIdIfAllowed(id, info.provider)) {
            configureOrAdd()
        } else {
            val intent = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider)
            @Suppress("DEPRECATION")
            startActivityForResult(intent, REQ_BIND)
        }
    }

    private fun configureOrAdd() {
        val info = pendingInfo ?: return
        if (info.configure != null) {
            runCatching {
                WidgetHost.host.startAppWidgetConfigureActivityForResult(this, pendingId, 0, REQ_CONFIGURE, null)
            }.onFailure { add() }
        } else add()
    }

    private fun add() {
        val info = pendingInfo ?: return
        val (w, h) = cells(info)
        Widgets.add(WidgetCfg(Widgets.newId(), WidgetKind.SYSTEM, w, h, appWidgetId = pendingId, fill = com.iv.launcher.data.FillType.NONE))
        Toast.makeText(this, "Widget added to your first home page", Toast.LENGTH_SHORT).show()
        pendingId = -1
        finish()
    }

    @Deprecated("Uses the platform widget flows that still rely on onActivityResult")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        val ok = resultCode == Activity.RESULT_OK
        when (requestCode) {
            REQ_BIND -> if (ok) configureOrAdd() else cancel()
            REQ_CONFIGURE -> if (ok) add() else cancel()
        }
    }

    private fun cancel() {
        if (pendingId >= 0) WidgetHost.delete(pendingId)
        pendingId = -1
    }

    companion object {
        private const val REQ_BIND = 11
        private const val REQ_CONFIGURE = 12
    }
}
