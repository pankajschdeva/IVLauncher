package com.iv.launcher.helper

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.iv.launcher.badges.Live
import com.iv.launcher.data.Store
import com.iv.launcher.ui.toColor
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

enum class CallMode { NONE, INCOMING, OUTGOING }

@Composable
fun CallContent(mode: CallMode) {
    val context = LocalContext.current
    val features by Store.features.collectAsState()
    val c = features.call
    val ringing by Live.ringing.collectAsState()
    val items by Live.items.collectAsState()
    val number by Live.number.collectAsState()
    val callItem = items.firstOrNull { it.isCall }
    val name = when (mode) {
        CallMode.INCOMING -> ringing?.name
        else -> callItem?.title
    }?.ifBlank { null } ?: number ?: "Unknown"
    val photo = if (mode == CallMode.INCOMING) ringing?.photo else callItem?.largeIcon
    var sheet by remember { mutableStateOf(0) }   // 0 none, 1 message, 2 remind

    Box(Modifier.fillMaxSize().background(Color(0xFF1B1B1E))) {
        // Background: caller photo (blurred) or IV home picture, then dark wash.
        val bg = remember(photo) { photo ?: com.iv.launcher.data.Store.loadBackground() }
        if (bg != null) {
            Image(
                bg.asImageBitmap(), null, contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize().blur(c.blurDp.dp),
            )
        }
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.45f), Color.Black.copy(alpha = 0.7f)))))

        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 26.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(70.dp))
            Text(name, color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Normal, maxLines = 2)
            val label = listOf(c.label, c.emoji).filter { it.isNotBlank() }.joinToString(" ")
            if (mode == CallMode.INCOMING) {
                if (label.isNotBlank()) Text(label, color = Color.White.copy(alpha = 0.7f), fontSize = 17.sp)
            } else {
                val start by Live.callStartedAt.collectAsState()
                val now by produceState(System.currentTimeMillis()) { while (true) { value = System.currentTimeMillis(); delay(1000) } }
                val sec = ((now - start) / 1000).coerceAtLeast(0)
                Text(
                    if (start == 0L) "calling…" else String.format("%02d:%02d", sec / 60, sec % 60),
                    color = Color.White.copy(alpha = 0.75f), fontSize = 17.sp,
                )
            }
            Spacer(Modifier.weight(1f))

            if (mode == CallMode.INCOMING) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                    RoundAction("💬", "Message") { sheet = 1 }
                    RoundAction("⏰", "Remind Me") { sheet = 2 }
                }
                Spacer(Modifier.height(34.dp))
                SlideToAnswer(c.sliderText, c.accent.toColor()) { CallActions.answer(context) }
                Spacer(Modifier.height(14.dp))
                Text(
                    if (c.volumeUpDeclines) "Press Volume Up to decline" else "Press Power to silence",
                    color = Color.White.copy(alpha = 0.55f), fontSize = 13.sp,
                )
                Spacer(Modifier.height(26.dp))
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.Bottom) {
                    RoundAction("📱", "Phone screen") {
                        Live.outgoingDismissed.value = true
                        callItem?.content?.let { runCatching { it.send() } }
                    }
                    RoundAction("✆", "End", tint = Color(0xFFFF3B30), big = true) { CallActions.hangUp(context) }
                    RoundAction("⌄", "Hide") { Live.outgoingDismissed.value = true }
                }
                Spacer(Modifier.height(60.dp))
            }
        }

        if (sheet != 0) {
            Box(
                Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.5f)).clickable { sheet = 0 },
                contentAlignment = Alignment.BottomCenter,
            ) {
                Column(
                    Modifier.fillMaxWidth().navigationBarsPadding().padding(12.dp)
                        .clip(RoundedCornerShape(26.dp)).background(Color(0xF2222226)).padding(vertical = 10.dp),
                ) {
                    val options: List<Pair<String, () -> Unit>> = if (sheet == 1) c.quickReplies.map { r -> r to { CallActions.reply(context, r) } }
                    else c.remindMinutes.map { m ->
                        (if (m >= 60) "In ${m / 60} hour${if (m >= 120) "s" else ""}" else "In $m minutes") to { CallActions.remind(context, m, name) }
                    }
                    options.forEach { (t, act) ->
                        Text(
                            t, color = Color.White, fontSize = 16.sp,
                            modifier = Modifier.fillMaxWidth().clickable { sheet = 0; act() }.padding(horizontal = 22.dp, vertical = 15.dp),
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun RoundAction(symbol: String, label: String, tint: Color = Color.White, big: Boolean = false, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(if (big) 76.dp else 58.dp).clip(CircleShape)
                .background(if (tint == Color.White) Color.White.copy(alpha = 0.18f) else tint)
                .clickable { onClick() },
            contentAlignment = Alignment.Center,
        ) { Text(symbol, color = Color.White, fontSize = if (big) 30.sp else 22.sp) }
        Spacer(Modifier.height(6.dp))
        Text(label, color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
    }
}

@OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
@Composable
private fun SlideToAnswer(text: String, accent: Color, onAnswer: () -> Unit) {
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()
    val x = remember { Animatable(0f) }
    var done by remember { mutableStateOf(false) }
    val shimmer = rememberInfiniteTransition(label = "shimmer")
    val sh by shimmer.animateFloat(-0.3f, 1.3f, infiniteRepeatable(tween(2200, easing = LinearEasing)), label = "s")

    BoxWithConstraints(
        Modifier.fillMaxWidth().height(76.dp).clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.16f)),
    ) {
        val thumb = with(density) { 66.dp.toPx() }
        val pad = with(density) { 5.dp.toPx() }
        val maxX = constraints.maxWidth - thumb - pad * 2
        Text(
            text,
            fontSize = 19.sp,
            modifier = Modifier.align(Alignment.Center).graphicsLayer { alpha = (1f - x.value / maxX * 1.6f).coerceIn(0f, 1f) },
            style = androidx.compose.ui.text.TextStyle(
                brush = Brush.horizontalGradient(
                    0f to Color.White.copy(alpha = 0.45f),
                    (sh - 0.15f).coerceIn(0f, 1f) to Color.White.copy(alpha = 0.45f),
                    sh.coerceIn(0f, 1f) to Color.White,
                    (sh + 0.15f).coerceIn(0f, 1f) to Color.White.copy(alpha = 0.45f),
                    1f to Color.White.copy(alpha = 0.45f),
                ),
            ),
        )
        Box(
            Modifier
                .offset { IntOffset((pad + x.value).roundToInt(), pad.roundToInt()) }
                .size(66.dp)
                .clip(CircleShape)
                .background(Color.White)
                .pointerInput(maxX) {
                    detectHorizontalDragGestures(
                        onDragEnd = {
                            scope.launch {
                                if (x.value > maxX * 0.82f && !done) {
                                    done = true
                                    x.animateTo(maxX, tween(120))
                                    onAnswer()
                                } else x.animateTo(0f, spring(dampingRatio = 0.6f))
                            }
                        },
                    ) { change, drag ->
                        change.consume()
                        scope.launch { x.snapTo((x.value + drag).coerceIn(0f, maxX)) }
                    }
                },
            contentAlignment = Alignment.Center,
        ) { Text("✆", color = accent, fontSize = 30.sp) }
    }
}
