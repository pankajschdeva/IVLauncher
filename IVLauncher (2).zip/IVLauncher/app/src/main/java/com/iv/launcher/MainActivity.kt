package com.iv.launcher

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.iv.launcher.data.Store
import com.iv.launcher.home.HomeRoot
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow

/** The home screen. */
class MainActivity : ComponentActivity() {

    private val homePressed = MutableSharedFlow<Unit>(extraBufferCapacity = 1, onBufferOverflow = BufferOverflow.DROP_OLDEST)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val theme by Store.theme.collectAsState()
            val features by Store.features.collectAsState()
            LaunchedEffect(theme.darkStatusIcons, features.statusBar.enabled) {
                WindowCompat.getInsetsController(window, window.decorView).apply {
                    isAppearanceLightStatusBars = theme.darkStatusIcons
                    isAppearanceLightNavigationBars = theme.darkStatusIcons
                    // IV draws its own status bar on home; Android's comes back with a swipe from the top.
                    systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                    if (features.statusBar.enabled) hide(WindowInsetsCompat.Type.statusBars())
                    else show(WindowInsetsCompat.Type.statusBars())
                }
            }
            HomeRoot(homePressed)
        }
    }

    override fun onStart() {
        super.onStart()
        com.iv.launcher.widgets.WidgetHost.start()
        com.iv.launcher.data.StatusInfo.start(this)
    }

    override fun onStop() {
        super.onStop()
        com.iv.launcher.widgets.WidgetHost.stop()
        com.iv.launcher.data.StatusInfo.stop()
    }

    /** Pressing Home while already on home: close drawer / menus, or go to the first page. */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN && intent.hasCategory(Intent.CATEGORY_HOME)) {
            homePressed.tryEmit(Unit)
        }
    }
}
