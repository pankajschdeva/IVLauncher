package com.iv.launcher.pin

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.content.pm.LauncherApps
import android.os.Bundle
import android.widget.Toast
import com.iv.launcher.data.AppRepo
import com.iv.launcher.data.FillType
import com.iv.launcher.data.WidgetCfg
import com.iv.launcher.data.WidgetKind
import com.iv.launcher.widgets.WidgetHost
import com.iv.launcher.widgets.Widgets

/**
 * Handles "Add to home screen" requests from other apps – Chrome website shortcuts, Maps directions,
 * Contacts, Google app widgets… – so they work with IV exactly like with Pixel Launcher.
 */
class PinRequestActivity : Activity() {

    private var request: LauncherApps.PinItemRequest? = null
    private var widgetId = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WidgetHost.init(this)
        val req = AppRepo.pinRequest(intent)
        if (req == null || !req.isValid) { finish(); return }
        request = req
        when (req.requestType) {
            LauncherApps.PinItemRequest.REQUEST_TYPE_SHORTCUT -> pinShortcut(req)
            LauncherApps.PinItemRequest.REQUEST_TYPE_APPWIDGET -> pinWidget(req)
            else -> finish()
        }
    }

    private fun pinShortcut(req: LauncherApps.PinItemRequest) {
        val info = req.shortcutInfo
        if (info == null || !req.accept()) { finish(); return }
        Widgets.add(
            WidgetCfg(
                id = Widgets.newId(), kind = WidgetKind.SHORTCUT, w = 1, h = 1,
                appKey = info.`package`, subtitle = info.id,
                title = (info.shortLabel ?: info.longLabel ?: "Shortcut").toString(),
                fill = FillType.NONE,
            )
        )
        Toast.makeText(this, "Added to home screen", Toast.LENGTH_SHORT).show()
        finish()
    }

    private fun pinWidget(req: LauncherApps.PinItemRequest) {
        val info = req.getAppWidgetProviderInfo(this) ?: run { finish(); return }
        widgetId = WidgetHost.host.allocateAppWidgetId()
        if (WidgetHost.manager.bindAppWidgetIdIfAllowed(widgetId, info.provider)) {
            finishWidget()
        } else {
            @Suppress("DEPRECATION")
            startActivityForResult(
                Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                    .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
                    .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider),
                REQ_BIND,
            )
        }
    }

    private fun finishWidget() {
        val req = request ?: return finish()
        val info = req.getAppWidgetProviderInfo(this)
        val ok = req.accept(Bundle().apply { putInt(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId) })
        if (!ok || info == null) { WidgetHost.delete(widgetId); finish(); return }
        val w = if (info.targetCellWidth > 0) info.targetCellWidth.coerceIn(1, 4) else 4
        val h = if (info.targetCellHeight > 0) info.targetCellHeight.coerceIn(1, 4) else 2
        Widgets.add(WidgetCfg(Widgets.newId(), WidgetKind.SYSTEM, w, h, appWidgetId = widgetId, fill = FillType.NONE))
        Toast.makeText(this, "Widget added to home screen", Toast.LENGTH_SHORT).show()
        finish()
    }

    @Deprecated("Widget binding still reports back through onActivityResult")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_BIND && resultCode == RESULT_OK) finishWidget()
        else { if (widgetId >= 0) WidgetHost.delete(widgetId); finish() }
    }

    companion object { private const val REQ_BIND = 21 }
}
