package com.iv.launcher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.ImageShader
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.LinearGradientShader
import androidx.compose.ui.graphics.Shader
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.font.DeviceFontFamilyName
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.iv.launcher.R
import com.iv.launcher.data.FillType
import com.iv.launcher.data.FontChoice
import com.iv.launcher.data.GradientSpec
import com.iv.launcher.data.Store
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

fun Long.toColor() = Color(this.toInt())          // ARGB Long → Compose Color
fun Color.toLong(): Long = toArgb().toLong() and 0xFFFFFFFFL

/** Linear gradient at an angle (0° = left→right, 90° = top→bottom) that fits whatever it paints. */
class AngleGradient(private val cols: List<Color>, private val angle: Float) : ShaderBrush() {
    override fun createShader(size: Size): Shader {
        val rad = Math.toRadians(angle.toDouble())
        val dx = cos(rad).toFloat()
        val dy = sin(rad).toFloat()
        val cx = size.width / 2f
        val cy = size.height / 2f
        val half = (abs(dx) * size.width + abs(dy) * size.height) / 2f
        return LinearGradientShader(
            from = Offset(cx - dx * half, cy - dy * half),
            to = Offset(cx + dx * half, cy + dy * half),
            colors = cols,
        )
    }
    override fun equals(other: Any?) = other is AngleGradient && other.cols == cols && other.angle == angle
    override fun hashCode() = cols.hashCode() * 31 + angle.hashCode()
}

fun GradientSpec.brush(alpha: Float = 1f): Brush {
    val cols = colors.ifEmpty { listOf(0xFF000000) }.map { it.toColor().let { c -> c.copy(alpha = c.alpha * alpha) } }
    return AngleGradient(if (cols.size == 1) listOf(cols[0], cols[0]) else cols, angle)
}

/** Paints a tile/dock/pill background according to a fill type. */
fun Modifier.ivFill(
    fill: FillType,
    color: Long,
    gradient: GradientSpec,
    alpha: Float,
    shape: Shape,
    outline: Boolean,
    outlineColor: Long,
    outlineWidthDp: Float = 1f,
    shadowDp: Float = 0f,
): Modifier {
    var m = this
    if (shadowDp > 0f && fill != FillType.NONE) m = m.shadow(shadowDp.dp, shape, clip = false)
    m = when (fill) {
        FillType.NONE -> m
        FillType.SOLID -> m.background(color.toColor().copy(alpha = color.toColor().alpha * alpha), shape)
        FillType.GRADIENT -> m.background(gradient.brush(alpha), shape)
        FillType.GLASS -> m
            .background(color.toColor().copy(alpha = alpha), shape)
            // soft top highlight that makes it read as glass
            .background(
                Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.10f), Color.Transparent)),
                shape,
            )
        FillType.PLUSH -> m
            .clip(shape)
            .background(gradient.brush(alpha))
            .drawBehind {
                drawRect(ShaderBrush(ImageShader(Plush.fur, TileMode.Repeated, TileMode.Repeated)), alpha = 0.55f)
                drawRect(
                    Brush.radialGradient(
                        listOf(Color.White.copy(alpha = 0.10f), Color.Transparent),
                        center = Offset(size.width * 0.35f, size.height * 0.3f),
                        radius = size.maxDimension * 0.8f,
                    )
                )
            }
    }
    if (outline && outlineWidthDp > 0f) m = m.border(outlineWidthDp.dp, outlineColor.toColor(), shape)
    return m
}

/** Procedural fur / felt texture for the Plush look. */
object Plush {
    val fur: ImageBitmap by lazy {
        val size = 160
        val bmp = android.graphics.Bitmap.createBitmap(size, size, android.graphics.Bitmap.Config.ARGB_8888)
        val c = android.graphics.Canvas(bmp)
        val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            strokeWidth = 1.1f
            strokeCap = android.graphics.Paint.Cap.ROUND
        }
        val rnd = java.util.Random(7)
        repeat(2600) {
            val x = rnd.nextFloat() * size
            val y = rnd.nextFloat() * size
            val len = 2f + rnd.nextFloat() * 5f
            val ang = rnd.nextFloat() * 6.2832f
            val light = rnd.nextBoolean()
            p.color = if (light) android.graphics.Color.argb(40 + rnd.nextInt(60), 255, 255, 255)
            else android.graphics.Color.argb(40 + rnd.nextInt(70), 0, 0, 0)
            // draw wrapped so the texture tiles seamlessly
            for (dx in intArrayOf(-size, 0, size)) for (dy in intArrayOf(-size, 0, size)) {
                c.drawLine(x + dx, y + dy, x + dx + cos(ang) * len, y + dy + sin(ang) * len, p)
            }
        }
        bmp.asImageBitmap()
    }
}

fun tileShape(cornerPercent: Int): Shape = RoundedCornerShape(cornerPercent.coerceIn(0, 50))

/** Font families. Bundled: Poppins, Inter, Lora. Device: Roboto/Google Sans, condensed, serif, mono. */
@OptIn(ExperimentalTextApi::class)
object Fonts {
    private val poppins = FontFamily(
        Font(R.font.poppins_light, FontWeight.Light),
        Font(R.font.poppins_regular, FontWeight.Normal),
        Font(R.font.poppins_medium, FontWeight.Medium),
        Font(R.font.poppins_bold, FontWeight.Bold),
    )
    private val inter = FontFamily(
        Font(R.font.inter_thin, FontWeight.Thin),
        Font(R.font.inter_light, FontWeight.Light),
        Font(R.font.inter_regular, FontWeight.Normal),
        Font(R.font.inter_medium, FontWeight.Medium),
        Font(R.font.inter_semibold, FontWeight.SemiBold),
        Font(R.font.inter_bold, FontWeight.Bold),
        Font(R.font.inter_black, FontWeight.Black),
    )
    private val lora = FontFamily(Font(R.font.lora))
    private val condensed = FontFamily(Font(DeviceFontFamilyName("sans-serif-condensed")))

    private var customVersion = -1L
    private var custom: FontFamily = FontFamily.Default

    fun family(choice: FontChoice, customFontVersion: Long): FontFamily = when (choice) {
        FontChoice.SYSTEM -> FontFamily.Default
        FontChoice.POPPINS -> poppins
        FontChoice.INTER -> inter
        FontChoice.LORA -> lora
        FontChoice.CONDENSED -> condensed
        FontChoice.SERIF -> FontFamily.Serif
        FontChoice.MONO -> FontFamily.Monospace
        FontChoice.CUSTOM -> {
            if (customVersion != customFontVersion) {
                customVersion = customFontVersion
                custom = runCatching {
                    if (Store.customFontFile.exists()) FontFamily(Font(Store.customFontFile)) else FontFamily.Default
                }.getOrDefault(FontFamily.Default)
            }
            custom
        }
    }

    val label = mapOf(
        FontChoice.SYSTEM to "System",
        FontChoice.POPPINS to "Poppins",
        FontChoice.INTER to "Inter",
        FontChoice.LORA to "Lora (serif)",
        FontChoice.CONDENSED to "Condensed",
        FontChoice.SERIF to "Serif",
        FontChoice.MONO to "Mono",
        FontChoice.CUSTOM to "My font",
    )
}

@Composable
fun rememberFont(choice: FontChoice, version: Long): FontFamily =
    remember(choice, version) { Fonts.family(choice, version) }
