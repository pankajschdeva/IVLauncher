package com.iv.launcher.settings

import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.iv.launcher.data.BadgeStyle
import com.iv.launcher.data.FeatureCfg
import com.iv.launcher.data.GestureAction
import com.iv.launcher.data.RingStyle
import com.iv.launcher.data.Store
import com.iv.launcher.data.ThemeCfg
import com.iv.launcher.helper.IvHelperService
import com.iv.launcher.lock.LockWallpaperService

/** How much battery a feature can use, shown next to its switch. */
private enum class Cost(val label: String, val color: Color) {
    NONE("No battery", Color(0xFF7BD88F)),
    VERY_LOW("Very low", Color(0xFF7BD88F)),
    LOW("Low", Color(0xFFFFD166)),
    MEDIUM("Medium", Color(0xFFFF9F68)),
}

private class Feat(
    val name: String,
    val cost: Cost,
    val on: Boolean,
    val tab: String,
    val note: String? = null,
    val needsHelper: Boolean = false,
    val toggle: (Boolean) -> Unit,
)

private fun f(block: (FeatureCfg) -> FeatureCfg) = Store.editFeatures(block)
private fun th(block: (ThemeCfg) -> ThemeCfg) = Store.editTheme(block)

/** Battery Saver: one switch that turns off everything that keeps redrawing or waking the phone. */
fun setBatterySaver(on: Boolean) {
    f { it.copy(batterySaver = on, statusBar = it.statusBar.copy(showSeconds = if (on) false else it.statusBar.showSeconds)) }
    th { it.copy(anim = it.anim.copy(enabled = !on)) }
}

/** The side menu: every IV feature in one list with its battery cost and an on/off switch. */
@Composable
fun FeatureHub(theme: ThemeCfg, features: FeatureCfg, onOpenTab: (String) -> Unit) {
    val context = LocalContext.current
    val helperOn by IvHelperService.running.collectAsState()
    val g = features.gestures
    val decorCost = if (features.decor.ringStyle == RingStyle.PULSE || features.decor.ringStyle == RingStyle.SPIN ||
        features.decor.stickers.isNotEmpty()) Cost.MEDIUM else Cost.LOW

    val list = listOf(
        Feat("IV status bar", Cost.VERY_LOW, features.statusBar.enabled, "Status Bar", "Time, 5G, signal, battery on home") { v -> f { it.copy(statusBar = it.statusBar.copy(enabled = v)) } },
        Feat("Notification numbers", Cost.VERY_LOW, theme.badge.style != BadgeStyle.OFF, "Badges") { v -> th { it.copy(badge = it.badge.copy(style = if (v) BadgeStyle.NUMBER else BadgeStyle.OFF)) } },
        Feat("Weather", Cost.VERY_LOW, features.weather.enabled, "Weather", "Updates every 30 min (2 h in Battery Saver)") { v -> f { it.copy(weather = it.weather.copy(enabled = v)) } },
        Feat("Animations", Cost.LOW, theme.anim.enabled, "Animations") { v -> th { it.copy(anim = it.anim.copy(enabled = v)) } },
        Feat("Tap home to talk", Cost.NONE, g.singleTap == GestureAction.VOICE, "Voice", "One tap on empty space → IV Voice") { v ->
            f { it.copy(gestures = it.gestures.copy(singleTap = if (v) GestureAction.VOICE else GestureAction.NONE)) }
        },
        Feat("IV Voice & commands", Cost.NONE, features.voice.enabled, "Voice", "Mic is used only while you talk") { v -> f { it.copy(voice = it.voice.copy(enabled = v)) } },
        Feat("Mic button next to Search", Cost.NONE, features.voice.micButton, "Voice") { v -> f { it.copy(voice = it.voice.copy(micButton = v)) } },
        Feat("Volume Down twice = IV Voice", Cost.NONE, features.voice.volumeDownTwice, "Voice", needsHelper = true) { v -> f { it.copy(voice = it.voice.copy(volumeDownTwice = v)) } },
        Feat("Arc picker", Cost.NONE, g.arcEnabled, "Arc Picker") { v -> f { it.copy(gestures = it.gestures.copy(arcEnabled = v)) } },
        Feat("Top pill", Cost.LOW, features.pill.enabled, "Top Pill", "Calls, recordings, timers, music", needsHelper = true) { v -> f { it.copy(pill = it.pill.copy(enabled = v)) } },
        Feat("Camera decor", decorCost, features.decor.enabled, "Camera Decor", "Static ring = low · Pulse/Spin/GIFs = medium", needsHelper = true) { v -> f { it.copy(decor = it.decor.copy(enabled = v)) } },
        Feat("IV incoming call screen", Cost.NONE, features.call.incoming, "Call Screen", needsHelper = true) { v -> f { it.copy(call = it.call.copy(incoming = v)) } },
        Feat("IV outgoing call screen", Cost.NONE, features.call.outgoing, "Call Screen", needsHelper = true) { v -> f { it.copy(call = it.call.copy(outgoing = v)) } },
        Feat("Volume Up declines calls", Cost.NONE, features.call.volumeUpDeclines, "Call Screen", needsHelper = true) { v -> f { it.copy(call = it.call.copy(volumeUpDeclines = v)) } },
    )

    Column(
        Modifier
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(vertical = 12.dp),
    ) {
        Text("All features", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp))
        Text("Turn off anything you don't use. Tap a name to open its settings.", color = Color(0xFF9A9AA2), fontSize = 13.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp))

        // Battery Saver card
        Row(
            Modifier
                .padding(14.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(if (features.batterySaver) Color(0xFF1F3A27) else Color(0xFF1B1B1F))
                .border(1.dp, if (features.batterySaver) Color(0xFF7BD88F) else Color.White.copy(alpha = 0.08f), RoundedCornerShape(20.dp))
                .clickable { setBatterySaver(!features.batterySaver) }
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text("Battery Saver", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    "Stops animations, moving camera rings and GIFs, seconds in the clock, and checks weather less often.",
                    color = Color(0xFFB8B8C0), fontSize = 12.5.sp,
                )
            }
            Spacer(Modifier.width(10.dp))
            Switch(checked = features.batterySaver, onCheckedChange = { setBatterySaver(it) })
        }

        list.forEach { ft ->
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f).clickable { onOpenTab(ft.tab) }) {
                    Text(ft.name, color = Color.White, fontSize = 15.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("● ", color = ft.cost.color, fontSize = 10.sp)
                        Text(ft.cost.label, color = ft.cost.color, fontSize = 12.sp)
                        if (ft.needsHelper && !helperOn) Text("  · needs IV Helper", color = Color(0xFFFFC56B), fontSize = 12.sp)
                    }
                    ft.note?.let { Text(it, color = Color(0xFF8A8A92), fontSize = 12.sp) }
                }
                Switch(checked = ft.on, onCheckedChange = { ft.toggle(it) })
            }
        }

        Spacer(Modifier.height(10.dp))
        Text(
            "Lock screen clock",
            color = MaterialTheme.colorScheme.primary, fontSize = 12.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp),
        )
        Row(
            Modifier.fillMaxWidth().clickable {
                runCatching {
                    context.startActivity(
                        Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
                            .putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, ComponentName(context, LockWallpaperService::class.java))
                    )
                }
            }.padding(horizontal = 20.dp, vertical = 8.dp),
        ) {
            Column {
                Text("IV lock screen (live wallpaper)", color = Color.White, fontSize = 15.sp)
                Text("● Low – redraws once a minute. To turn off, pick any normal wallpaper.", color = Cost.LOW.color, fontSize = 12.sp)
            }
        }

        val helperNeeded = list.any { it.needsHelper && it.on }
        Spacer(Modifier.height(6.dp))
        Row(
            Modifier.fillMaxWidth().clickable { IvHelperService.openSettings(context) }.padding(horizontal = 20.dp, vertical = 8.dp),
        ) {
            Column {
                Text("IV Helper: ${if (helperOn) "On" else "Off"}", color = Color.White, fontSize = 15.sp)
                Text(
                    if (helperNeeded) "Needed by the features marked above. Uses no battery while idle."
                    else "No feature needs it right now – you can turn it off.",
                    color = Color(0xFF8A8A92), fontSize = 12.sp,
                )
            }
        }
        Spacer(Modifier.height(30.dp))
    }
}
