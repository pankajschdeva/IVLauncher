package com.iv.launcher.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.iv.launcher.data.GradientSpec
import com.iv.launcher.ui.brush
import com.iv.launcher.ui.toColor
import kotlin.math.roundToInt

private val cardColor = Color(0xFF17171A)
private val subText = Color(0xFF9A9AA2)

/** A titled group of settings. */
@Composable
fun Section(title: String, hint: String? = null, content: @Composable () -> Unit) {
    Column(
        Modifier
            .padding(horizontal = 14.dp, vertical = 7.dp)
            .fillMaxWidth()
            .background(cardColor, RoundedCornerShape(22.dp))
            .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(22.dp))
            .padding(vertical = 8.dp),
    ) {
        Text(
            title.uppercase(),
            color = MaterialTheme.colorScheme.primary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.2.sp,
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp),
        )
        if (hint != null) {
            Text(hint, color = subText, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 18.dp).padding(bottom = 6.dp))
        }
        content()
    }
}

@Composable
private fun RowBase(title: String, subtitle: String?, onClick: (() -> Unit)?, trailing: @Composable () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
            .padding(horizontal = 18.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 15.sp)
            if (subtitle != null) Text(subtitle, color = subText, fontSize = 12.5.sp)
        }
        Spacer(Modifier.width(12.dp))
        trailing()
    }
}

@Composable
fun SwitchRow(title: String, checked: Boolean, subtitle: String? = null, onChange: (Boolean) -> Unit) =
    RowBase(title, subtitle, onClick = { onChange(!checked) }) {
        Switch(checked = checked, onCheckedChange = onChange)
    }

@Composable
fun ButtonRow(title: String, subtitle: String? = null, value: String? = null, onClick: () -> Unit) =
    RowBase(title, subtitle, onClick) {
        if (value != null) Text(value, color = subText, fontSize = 14.sp)
        Text("  ›", color = subText, fontSize = 18.sp)
    }

@Composable
fun SliderRow(
    title: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    format: (Float) -> String = { it.roundToInt().toString() },
    steps: Int = 0,
    onChange: (Float) -> Unit,
) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = Color.White, fontSize = 15.sp, modifier = Modifier.weight(1f))
            Text(format(value), color = subText, fontSize = 14.sp)
        }
        Slider(value = value.coerceIn(range), onValueChange = onChange, valueRange = range, steps = steps)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun <T> ChoiceRow(title: String, options: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp)) {
        Text(title, color = Color.White, fontSize = 15.sp)
        Spacer(Modifier.height(8.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { o ->
                val sel = o == selected
                Text(
                    label(o),
                    color = if (sel) Color.Black else Color.White,
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier
                        .background(if (sel) MaterialTheme.colorScheme.primary else Color.White.copy(alpha = 0.07f), RoundedCornerShape(50))
                        .clickable { onSelect(o) }
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                )
            }
        }
    }
}

@Composable
fun ColorRow(title: String, color: Long, subtitle: String? = null, onChange: (Long) -> Unit) {
    var open by remember { mutableStateOf(false) }
    RowBase(title, subtitle, onClick = { open = true }) {
        Swatch(color, 30)
    }
    if (open) ColorPickerDialog(color, onDismiss = { open = false }) { onChange(it); open = false }
}

@Composable
fun GradientRow(title: String, spec: GradientSpec, onChange: (GradientSpec) -> Unit) {
    var open by remember { mutableStateOf(false) }
    RowBase(title, "${spec.colors.size} colors · ${spec.angle.roundToInt()}°", onClick = { open = true }) {
        Box(Modifier.size(width = 64.dp, height = 30.dp).background(spec.brush(), RoundedCornerShape(10.dp)))
    }
    if (open) GradientDialog(spec, onDismiss = { open = false }) { onChange(it); open = false }
}

@Composable
private fun Swatch(color: Long, sizeDp: Int, modifier: Modifier = Modifier) {
    Box(
        modifier
            .size(sizeDp.dp)
            .background(
                Brush.linearGradient(listOf(Color(0xFF777777), Color(0xFFBBBBBB))),
                CircleShape,
            )
            .background(color.toColor(), CircleShape)
            .border(1.dp, Color.White.copy(alpha = 0.25f), CircleShape),
    )
}

private val swatches = listOf(
    0xFFFFFFFF, 0xFFF2F2F2, 0xFFBDBDBD, 0xFF6E6E73, 0xFF2C2C2E, 0xFF1C1C1E, 0xFF000000,
    0xFFE9E1CF, 0xFFB9A7FF, 0xFFC4A8FF, 0xFF7C5CFF, 0xFF5AC8FA, 0xFF34C759, 0xFFFFCC00,
    0xFFFF9500, 0xFFFF3B30, 0xFFFF2D55, 0xFFA2845E, 0x33FFFFFF, 0x80000000,
)

/** HSV + alpha colour picker with hex input. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ColorPickerDialog(initial: Long, onDismiss: () -> Unit, onPick: (Long) -> Unit) {
    val hsv = remember { FloatArray(3).also { android.graphics.Color.colorToHSV(initial.toInt(), it) } }
    var h by remember { mutableFloatStateOf(hsv[0]) }
    var s by remember { mutableFloatStateOf(hsv[1]) }
    var v by remember { mutableFloatStateOf(hsv[2]) }
    var a by remember { mutableFloatStateOf(((initial shr 24) and 0xFF) / 255f) }

    fun current(): Long {
        val rgb = android.graphics.Color.HSVToColor(floatArrayOf(h, s, v))
        val alpha = (a * 255).roundToInt().coerceIn(0, 255)
        return ((alpha.toLong() shl 24) or (rgb.toLong() and 0xFFFFFF))
    }
    var hex by remember { mutableStateOf(String.format("%08X", initial and 0xFFFFFFFFL)) }
    fun syncHex() { hex = String.format("%08X", current()) }

    fun setFrom(c: Long) {
        val t = FloatArray(3)
        android.graphics.Color.colorToHSV(c.toInt(), t)
        h = t[0]; s = t[1]; v = t[2]; a = ((c shr 24) and 0xFF) / 255f
        syncHex()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = { onPick(current()) }) { Text("Use color") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        containerColor = Color(0xFF1C1C1F),
        title = { Text("Pick a color", color = Color.White) },
        text = {
            Column {
                Box(
                    Modifier.fillMaxWidth().height(56.dp)
                        .background(Brush.linearGradient(listOf(Color(0xFF555555), Color(0xFFAAAAAA))), RoundedCornerShape(14.dp))
                        .background(current().toColor(), RoundedCornerShape(14.dp)),
                )
                Spacer(Modifier.height(10.dp))
                PickerSlider("Hue", h, 0f..360f) { h = it; syncHex() }
                PickerSlider("Saturation", s, 0f..1f) { s = it; syncHex() }
                PickerSlider("Brightness", v, 0f..1f) { v = it; syncHex() }
                PickerSlider("Opacity", a, 0f..1f) { a = it; syncHex() }
                OutlinedTextField(
                    value = hex,
                    onValueChange = { txt ->
                        val clean = txt.removePrefix("#").uppercase().filter { it in "0123456789ABCDEF" }.take(8)
                        hex = clean
                        val parsed = when (clean.length) {
                            6 -> clean.toLongOrNull(16)?.let { it or 0xFF000000 }
                            8 -> clean.toLongOrNull(16)
                            else -> null
                        }
                        if (parsed != null) {
                            val t = FloatArray(3)
                            android.graphics.Color.colorToHSV(parsed.toInt(), t)
                            h = t[0]; s = t[1]; v = t[2]; a = ((parsed shr 24) and 0xFF) / 255f
                        }
                    },
                    label = { Text("Hex (AARRGGBB or RRGGBB)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(10.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    swatches.forEach { c -> Swatch(c, 26, Modifier.clickable { setFrom(c) }) }
                }
            }
        },
    )
}

@Composable
private fun PickerSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = subText, fontSize = 12.sp, modifier = Modifier.width(76.dp))
        Slider(value = value, onValueChange = onChange, valueRange = range, modifier = Modifier.weight(1f))
    }
}

@Composable
fun GradientDialog(initial: GradientSpec, onDismiss: () -> Unit, onPick: (GradientSpec) -> Unit) {
    var spec by remember { mutableStateOf(initial) }
    var editIndex by remember { mutableStateOf(-1) }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = { onPick(spec) }) { Text("Use gradient") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        containerColor = Color(0xFF1C1C1F),
        title = { Text("Gradient", color = Color.White) },
        text = {
            Column {
                Box(Modifier.fillMaxWidth().height(70.dp).background(spec.brush(), RoundedCornerShape(16.dp)))
                Spacer(Modifier.height(12.dp))
                Text("Tap a color to change it", color = subText, fontSize = 12.sp)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    spec.colors.forEachIndexed { i, c -> Swatch(c, 36, Modifier.clickable { editIndex = i }) }
                    if (spec.colors.size < 4) {
                        Text("+", color = Color.White, fontSize = 22.sp, modifier = Modifier.clickable {
                            spec = spec.copy(colors = spec.colors + spec.colors.last())
                        }.padding(8.dp))
                    }
                    if (spec.colors.size > 2) {
                        Text("−", color = Color.White, fontSize = 22.sp, modifier = Modifier.clickable {
                            spec = spec.copy(colors = spec.colors.dropLast(1))
                        }.padding(8.dp))
                    }
                }
                Spacer(Modifier.height(10.dp))
                PickerSlider("Angle ${spec.angle.roundToInt()}°", spec.angle, 0f..360f) { spec = spec.copy(angle = it) }
            }
        },
    )
    if (editIndex >= 0) {
        ColorPickerDialog(spec.colors[editIndex], onDismiss = { editIndex = -1 }) { c ->
            spec = spec.copy(colors = spec.colors.toMutableList().also { it[editIndex] = c })
            editIndex = -1
        }
    }
}
