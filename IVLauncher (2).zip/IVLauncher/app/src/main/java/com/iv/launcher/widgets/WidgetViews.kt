package com.iv.launcher.widgets

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.iv.launcher.data.AppInfo
import com.iv.launcher.data.AppRepo
import com.iv.launcher.data.FillType
import com.iv.launcher.data.Media
import com.iv.launcher.data.ThemeCfg
import com.iv.launcher.data.Weather
import com.iv.launcher.data.WidgetCfg
import com.iv.launcher.data.WidgetKind
import com.iv.launcher.ui.AppGlyph
import com.iv.launcher.ui.BigClock
import com.iv.launcher.ui.ivFill
import com.iv.launcher.ui.rememberFont
import com.iv.launcher.ui.rememberNow
import com.iv.launcher.ui.toColor
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Draws one home widget of any kind at the given size. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun WidgetView(
    cfg: WidgetCfg,
    theme: ThemeCfg,
    appMap: Map<String, AppInfo>,
    width: Dp,
    height: Dp,
    onLongClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val haptics = LocalHapticFeedback.current
    val shape = RoundedCornerShape((theme.tile.cornerPercent * 0.9f).dp.coerceAtMost(30.dp))
    val textColor = cfg.textColor.toColor()
    val font = rememberFont(theme.label.font, theme.customFontVersion)

    val tapAction: () -> Unit = when (cfg.kind) {
        WidgetKind.CUSTOM -> ({ cfg.appKey?.let { appMap[it] }?.let { AppRepo.launch(context, it, null, null) } })
        WidgetKind.MUSIC -> ({ Media.open(context) })
        WidgetKind.WEATHER -> ({ openWeatherApp(context) })
        WidgetKind.CALENDAR -> ({ openPackage(context, "com.google.android.calendar") })
        WidgetKind.CLOCK -> ({ openPackage(context, "com.google.android.deskclock") })
        WidgetKind.SYSTEM -> ({})
        WidgetKind.SHORTCUT -> ({ cfg.appKey?.let { AppRepo.startShortcut(context, it, cfg.subtitle) } })
    }

    Box(
        modifier
            .size(width, height)
            .then(
                if (cfg.fill == FillType.NONE) Modifier else Modifier.ivFill(
                    fill = cfg.fill, color = cfg.color, gradient = cfg.gradient, alpha = cfg.alpha,
                    shape = shape, outline = theme.tile.outline, outlineColor = theme.tile.outlineColor,
                    outlineWidthDp = theme.tile.outlineWidthDp, shadowDp = theme.tile.shadowDp,
                )
            )
            .clip(shape)
            .combinedClickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = tapAction,
                onLongClick = { haptics.performHapticFeedback(HapticFeedbackType.LongPress); onLongClick() },
            ),
    ) {
        when (cfg.kind) {
            WidgetKind.CLOCK -> {
                val weather by Weather.now.collectAsState()
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    BigClock(cfg.clock, weather, theme.customFontVersion)
                }
            }
            WidgetKind.WEATHER -> WeatherBody(textColor, font, wide = cfg.w >= 4)
            WidgetKind.CALENDAR -> CalendarBody(textColor, font, wide = cfg.w >= 4)
            WidgetKind.MUSIC -> MusicBody(textColor, font, wide = cfg.w >= 4)
            WidgetKind.CUSTOM -> CustomBody(cfg, theme, appMap, textColor, font, width, height)
            WidgetKind.SYSTEM -> SystemBody(cfg, width, height)
            WidgetKind.SHORTCUT -> ShortcutBody(cfg, theme)
        }
    }
}

private fun openPackage(context: android.content.Context, pkg: String) {
    context.packageManager.getLaunchIntentForPackage(pkg)?.let {
        runCatching { context.startActivity(it.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }
}

private fun openWeatherApp(context: android.content.Context) {
    val i = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com/search?q=weather"))
        .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
    runCatching { context.startActivity(i) }
}

@Composable
private fun WeatherBody(color: Color, font: androidx.compose.ui.text.font.FontFamily, wide: Boolean) {
    val w by Weather.now.collectAsState()
    val err by Weather.error.collectAsState()
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        val now = w
        if (now == null) {
            Text("Weather", color = color, fontFamily = font, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Spacer(Modifier.height(6.dp))
            Text(err ?: "Loading…", color = color.copy(alpha = 0.7f), fontFamily = font, fontSize = 12.sp, maxLines = 4)
            return@Column
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(now.city, color = color, fontFamily = font, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
            Text(" ➤", color = color, fontSize = 11.sp)
        }
        Text("${now.temp}°", color = color, fontFamily = font, fontWeight = FontWeight.Light, fontSize = 44.sp)
        if (!wide) {
            Spacer(Modifier.weight(1f))
            Text(now.emoji, fontSize = 18.sp)
            Text(now.text, color = color, fontFamily = font, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text("H:${now.high}° L:${now.low}°", color = color, fontFamily = font, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        } else {
            Text("${now.emoji} ${now.text}   H:${now.high}° L:${now.low}°", color = color, fontFamily = font, fontSize = 13.sp)
            Spacer(Modifier.weight(1f))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                now.hours.take(6).forEach { h ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(h.hour, color = color.copy(alpha = 0.75f), fontSize = 11.sp, fontFamily = font)
                        Text(Weather.emoji(h.code), fontSize = 15.sp)
                        Text("${h.temp}°", color = color, fontSize = 12.sp, fontFamily = font, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

@Composable
private fun CalendarBody(color: Color, font: androidx.compose.ui.text.font.FontFamily, wide: Boolean) {
    val now = rememberNow()
    val cal = remember(now / 3_600_000) { Calendar.getInstance().apply { timeInMillis = now } }
    val today = cal.get(Calendar.DAY_OF_MONTH)
    Row(Modifier.fillMaxSize().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        if (wide) {
            Column(Modifier.weight(0.38f)) {
                Text(SimpleDateFormat("EEEE", Locale.getDefault()).format(Date(now)), color = color, fontFamily = font, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("$today", color = color, fontFamily = font, fontWeight = FontWeight.Bold, fontSize = 40.sp)
            }
        }
        Column(Modifier.weight(0.62f).fillMaxHeight(), verticalArrangement = Arrangement.SpaceEvenly) {
            Text(SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(Date(now)), color = color.copy(alpha = 0.85f), fontSize = 11.sp, fontFamily = font, fontWeight = FontWeight.SemiBold)
            val first = (cal.clone() as Calendar).apply { set(Calendar.DAY_OF_MONTH, 1) }
            val offset = (first.get(Calendar.DAY_OF_WEEK) - Calendar.SUNDAY + 7) % 7
            val days = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
            Row(Modifier.fillMaxWidth()) {
                listOf("S", "M", "T", "W", "T", "F", "S").forEach {
                    Text(it, color = color.copy(alpha = 0.6f), fontSize = 9.sp, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                }
            }
            val cells = offset + days
            val rows = (cells + 6) / 7
            for (r in 0 until rows) {
                Row(Modifier.fillMaxWidth()) {
                    for (c in 0 until 7) {
                        val d = r * 7 + c - offset + 1
                        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                            if (d in 1..days) {
                                val isToday = d == today
                                Text(
                                    "$d",
                                    color = if (isToday) Color.Black else color,
                                    fontSize = 9.5.sp,
                                    fontFamily = font,
                                    fontWeight = if (isToday) FontWeight.Bold else FontWeight.Normal,
                                    modifier = Modifier
                                        .then(if (isToday) Modifier.background(Color.White, CircleShape) else Modifier)
                                        .padding(horizontal = 3.dp),
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MusicBody(color: Color, font: androidx.compose.ui.text.font.FontFamily, wide: Boolean) {
    val m by Media.now.collectAsState()
    val now = m
    Box(Modifier.fillMaxSize()) {
        if (now?.art != null) {
            Image(
                bitmap = remember(now.art) { now.art.asImageBitmap() },
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
                alpha = 0.45f,
            )
        }
        Column(Modifier.fillMaxSize().padding(14.dp)) {
            if (now == null) {
                Text("♪", color = color, fontSize = 26.sp)
                Spacer(Modifier.weight(1f))
                Text("Nothing playing", color = color, fontFamily = font, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Text("Play music in any app. Needs notification access.", color = color.copy(alpha = 0.6f), fontSize = 11.sp)
                return@Column
            }
            Row(verticalAlignment = Alignment.Top) {
                if (now.art != null) {
                    Image(
                        bitmap = remember(now.art) { now.art.asImageBitmap() }, contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.size(if (wide) 64.dp else 46.dp).clip(RoundedCornerShape(10.dp)),
                    )
                }
            }
            Spacer(Modifier.weight(1f))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(now.title, color = color, fontFamily = font, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(now.artist, color = color.copy(alpha = 0.7f), fontFamily = font, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                if (wide) {
                    CircleBtn("⏮", 34.dp, false) { Media.previous() }
                    Spacer(Modifier.width(6.dp))
                }
                CircleBtn(if (now.playing) "❚❚" else "▶", 44.dp, true) { Media.togglePlay() }
                if (wide) {
                    Spacer(Modifier.width(6.dp))
                    CircleBtn("⏭", 34.dp, false) { Media.next() }
                }
            }
        }
    }
}

@Composable
private fun CircleBtn(symbol: String, size: Dp, filled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(size).clip(CircleShape)
            .background(if (filled) Color.White else Color.White.copy(alpha = 0.15f))
            .clickable { onClick() },
        contentAlignment = Alignment.Center,
    ) {
        Text(symbol, color = if (filled) Color.Black else Color.White, fontSize = (size.value * 0.36f).sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun CustomBody(
    cfg: WidgetCfg, theme: ThemeCfg, appMap: Map<String, AppInfo>, color: Color,
    font: androidx.compose.ui.text.font.FontFamily, width: Dp, height: Dp,
) {
    val app = cfg.appKey?.let { appMap[it] }
    val small = minOf(width, height)
    Column(
        Modifier.fillMaxSize().padding(14.dp),
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = if (cfg.title.isBlank()) Alignment.Center else Alignment.CenterStart) {
            when {
                cfg.emoji.isNotBlank() -> Text(cfg.emoji, fontSize = (small.value * 0.34f).sp)
                cfg.showIcon && app != null -> AppGlyph(app, theme, small * 0.45f)
            }
        }
        if (cfg.title.isNotBlank()) Text(cfg.title, color = color, fontFamily = font, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        if (cfg.subtitle.isNotBlank()) Text(cfg.subtitle, color = color.copy(alpha = 0.7f), fontFamily = font, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun SystemBody(cfg: WidgetCfg, width: Dp, height: Dp) {
    val context = LocalContext.current
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val v = remember(cfg.appWidgetId) { WidgetHost.view(context, cfg.appWidgetId) }
        if (v == null) {
            Text("Widget not available", color = Color.White, fontSize = 12.sp, modifier = Modifier.align(Alignment.Center))
        } else {
            AndroidView(
                factory = { v },
                modifier = Modifier.fillMaxSize(),
                update = { WidgetHost.setSize(it, width.value, height.value) },
            )
        }
    }
}

/** A pinned shortcut (Chrome website, Maps directions, a contact…) drawn like an app icon. */
@Composable
private fun ShortcutBody(cfg: WidgetCfg, theme: ThemeCfg) {
    val context = LocalContext.current
    val px = with(LocalDensity.current) { (theme.icon.sizeDp * 0.62f).dp.roundToPx() }
    val bmp by androidx.compose.runtime.produceState<android.graphics.Bitmap?>(null, cfg.appKey, cfg.subtitle) {
        value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            cfg.appKey?.let { pkg -> AppRepo.shortcut(pkg, cfg.subtitle) }?.let { AppRepo.shortcutIcon(context, it, px) }
        }
    }
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .size(theme.icon.sizeDp.dp)
                .then(
                    if (theme.icon.showTile) Modifier.ivFill(
                        theme.tile.fill, theme.tile.color, theme.tile.gradient, theme.tile.alpha,
                        com.iv.launcher.ui.tileShape(theme.tile.cornerPercent), theme.tile.outline, theme.tile.outlineColor,
                        theme.tile.outlineWidthDp, theme.tile.shadowDp,
                    ) else Modifier
                ),
            contentAlignment = Alignment.Center,
        ) {
            val b = bmp
            if (b != null) Image(
                b.asImageBitmap(), cfg.title, Modifier.size((theme.icon.sizeDp * 0.62f).dp),
                colorFilter = if (theme.icon.style == com.iv.launcher.data.IconStyle.ORIGINAL) null
                else androidx.compose.ui.graphics.ColorFilter.colorMatrix(androidx.compose.ui.graphics.ColorMatrix().apply { setToSaturation(0f) }),
            )
        }
        if (theme.label.show) {
            Spacer(Modifier.height(5.dp))
            com.iv.launcher.ui.LabelText(cfg.title, theme, Modifier.fillMaxWidth())
        }
    }
}
