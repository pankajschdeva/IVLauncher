package com.iv.launcher.helper

import android.content.Context
import android.graphics.PixelFormat
import android.graphics.Rect
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner

/** Minimal lifecycle so Compose can run inside a window owned by a service. */
class OverlayOwner : LifecycleOwner, SavedStateRegistryOwner {
    private val registry = LifecycleRegistry(this)
    private val controller = SavedStateRegistryController.create(this)
    override val lifecycle: Lifecycle get() = registry
    override val savedStateRegistry: SavedStateRegistry get() = controller.savedStateRegistry

    init {
        controller.performRestore(null)
        registry.currentState = Lifecycle.State.CREATED
    }

    fun resume() { registry.currentState = Lifecycle.State.RESUMED }
    fun destroy() { registry.currentState = Lifecycle.State.DESTROYED }
}

/**
 * One floating window (accessibility overlay: shows above apps, status bar and lock screen).
 */
class OverlayWindow(
    private val context: Context,
    private val touchable: Boolean,
    private val fullScreen: Boolean,
    private val content: @Composable () -> Unit,
) {
    private val wm = context.getSystemService(WindowManager::class.java)
    private var view: ComposeView? = null
    private var owner: OverlayOwner? = null
    val isShown get() = view != null

    val params = WindowManager.LayoutParams(
        if (fullScreen) WindowManager.LayoutParams.MATCH_PARENT else WindowManager.LayoutParams.WRAP_CONTENT,
        if (fullScreen) WindowManager.LayoutParams.MATCH_PARENT else WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED or
            (if (touchable) 0 else WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE) or
            (if (fullScreen) WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON else 0),
        PixelFormat.TRANSLUCENT,
    ).apply {
        gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
    }

    fun show() {
        if (view != null) return
        val o = OverlayOwner()
        val v = ComposeView(context).apply {
            setViewTreeLifecycleOwner(o)
            setViewTreeSavedStateRegistryOwner(o)
            setContent(content)
        }
        runCatching {
            wm.addView(v, params)
            o.resume()
            view = v
            owner = o
        }
    }

    fun hide() {
        val v = view ?: return
        runCatching { wm.removeView(v) }
        owner?.destroy()
        view = null
        owner = null
    }

    fun relayout() {
        val v = view ?: return
        runCatching { wm.updateViewLayout(v, params) }
    }
}

/** Where the front camera hole is (in px, screen coordinates). */
fun cameraCutout(context: Context): Rect? {
    val wm = context.getSystemService(WindowManager::class.java)
    val cutout = runCatching { wm.currentWindowMetrics.windowInsets.displayCutout }.getOrNull() ?: return null
    return cutout.boundingRects.minByOrNull { it.top }
}

fun screenWidth(context: Context): Int =
    context.getSystemService(WindowManager::class.java).currentWindowMetrics.bounds.width()
