package com.iv.launcher.data

import kotlinx.serialization.Serializable

/*
 * Feature settings (widgets, clock, weather, gestures, overlays, lock screen, calls).
 * Kept separate from ThemeCfg so switching a theme preset never resets them.
 */

@Serializable
enum class ClockStyle(val title: String) {
    TALL("Tall thin"), STACKED("Stacked"), OUTLINE("Outline"), GRADIENT("Gradient"),
    GLASS("Glass"), SPLIT("Split"), MINIMAL("Minimal"),
}

@Serializable
data class ClockCfg(
    val style: ClockStyle = ClockStyle.TALL,
    val font: FontChoice = FontChoice.CONDENSED,
    val weight: Int = 300,
    val sizeSp: Float = 96f,
    val heightScale: Float = 1.8f,     // "kitna bhi lamba"
    val widthScale: Float = 1f,        // "kitna bhi patla"
    val letterSpacing: Float = 0f,
    val color: Long = 0xE6FFFFFF,
    val gradient: GradientSpec = GradientSpec(listOf(0xFFFFFFFF, 0xFF8E8EA0), 90f),
    val outlineDp: Float = 2f,
    val showDate: Boolean = true,
    val showWeather: Boolean = true,
    val dateColor: Long = 0xDDFFFFFF,
    val dateSizeSp: Float = 18f,
    val use24h: Boolean = false,
)

@Serializable enum class WidgetKind { CLOCK, WEATHER, CALENDAR, MUSIC, CUSTOM, SYSTEM, SHORTCUT }

@Serializable
data class WidgetCfg(
    val id: String,
    val kind: WidgetKind,
    val w: Int,
    val h: Int,
    val appKey: String? = null,        // CUSTOM: app that opens on tap
    val emoji: String = "",
    val title: String = "",
    val subtitle: String = "",
    val fill: FillType = FillType.GLASS,
    val color: Long = 0xFF1C1C1E,
    val gradient: GradientSpec = GradientSpec(),
    val alpha: Float = 0.6f,
    val textColor: Long = 0xFFFFFFFF,
    val showIcon: Boolean = true,
    val appWidgetId: Int = -1,         // SYSTEM: Android widget id
    val clock: ClockCfg = ClockCfg(sizeSp = 76f, heightScale = 1.6f),
)

@Serializable enum class WeatherUnit { C, F }

@Serializable
data class WeatherCfg(
    val enabled: Boolean = true,
    val auto: Boolean = true,          // use phone location
    val city: String = "",
    val lat: Double? = null,
    val lon: Double? = null,
    val unit: WeatherUnit = WeatherUnit.C,
)

@Serializable
enum class GestureAction(val title: String) {
    NONE("Nothing"), LOCK("Lock screen"), NOTIFICATIONS("Notifications"), QUICK_SETTINGS("Quick settings"),
    SEARCH("Google search"), DRAWER("App drawer"), SETTINGS("IV Settings"), VOICE("IV Voice"),
}

@Serializable
data class GestureCfg(
    val singleTap: GestureAction = GestureAction.VOICE,     // one tap on empty home space
    val doubleTap: GestureAction = GestureAction.LOCK,
    val swipeDown: GestureAction = GestureAction.NOTIFICATIONS,
    val arcEnabled: Boolean = true,
    val arcHaptics: Boolean = true,
    val arcAccent: Long = 0xFFC8A6FF,
)

@Serializable
data class PillCfg(
    val enabled: Boolean = true,
    val calls: Boolean = true,
    val media: Boolean = true,
    val timers: Boolean = true,        // recordings, stopwatches, anything with a running timer
    val allOngoing: Boolean = false,   // every ongoing notification
    val blocked: Set<String> = emptySet(),
    val color: Long = 0xFF000000,
    val textColor: Long = 0xFFFFFFFF,
    val dotColor: Long = 0xFFFF3B30,
    val heightDp: Float = 34f,
    val minWidthDp: Float = 190f,
    val yOffsetDp: Float = 0f,
    val outline: Boolean = false,
)

@Serializable enum class RingStyle(val title: String) { SOLID("Solid"), GRADIENT("Gradient"), GLOW("Glow"), PULSE("Pulse"), SPIN("Spin") }

@Serializable
data class StickerCfg(
    val id: String,
    val file: String,
    val xDp: Float = 26f,
    val yDp: Float = 0f,
    val sizeDp: Float = 26f,
    val rotation: Float = 0f,
)

@Serializable
data class DecorCfg(
    val enabled: Boolean = true,
    val ring: Boolean = true,
    val ringStyle: RingStyle = RingStyle.SOLID,
    val ringColor: Long = 0xFFFF3B30,
    val ringGradient: GradientSpec = GradientSpec(listOf(0xFFFF3B30, 0xFFFFCC00, 0xFF34C759, 0xFF5AC8FA, 0xFFAF52DE), 0f),
    val ringWidthDp: Float = 2.5f,
    val ringGapDp: Float = 2.5f,
    val ringXDp: Float = 0f,
    val ringYDp: Float = 0f,
    val cutoutSizeDp: Float = 0f,     // 0 = auto-detect the camera hole
    val stickers: List<StickerCfg> = emptyList(),
    val hideLandscape: Boolean = true,
    val gifStopAfterSec: Int = 0,     // 0 = keep playing
)

@Serializable enum class LockBg(val title: String) { HOME_IMAGE("Same as IV home picture"), LOCK_IMAGE("Own lock picture"), GRADIENT("Gradient"), SOLID("Solid") }

@Serializable
data class LockCfg(
    val bg: LockBg = LockBg.GRADIENT,
    val color: Long = 0xFF9DB4CC,
    val gradient: GradientSpec = GradientSpec(listOf(0xFFA9BDD3, 0xFF8FA6BF), 90f),
    val dim: Float = 0f,
    val clock: ClockCfg = ClockCfg(sizeSp = 150f, heightScale = 2.3f, weight = 200, color = 0xCCFFFFFF, showWeather = true),
    val clockTopDp: Float = 120f,
    val infoColor: Long = 0xDDFFFFFF,
    val showBattery: Boolean = true,
    val showMusic: Boolean = true,
    val todos: List<String> = emptyList(),
    val foregroundLayer: Boolean = false,   // PNG cut-out drawn over the clock (depth effect)
    val showClockWhenUnlocked: Boolean = false,
    val version: Long = 0L,
)

@Serializable
data class CallCfg(
    val incoming: Boolean = true,
    val outgoing: Boolean = true,
    val volumeUpDeclines: Boolean = true,
    val label: String = "mobile",
    val emoji: String = "❤️",
    val sliderText: String = "slide to answer",
    val accent: Long = 0xFF34C759,
    val blurDp: Float = 30f,
    val quickReplies: List<String> = listOf(
        "Can't talk now, I'll call you back.",
        "On my way.",
        "Call you in 5 minutes.",
    ),
    val remindMinutes: List<Int> = listOf(10, 60),
)

@Serializable
data class StatusBarCfg(
    val enabled: Boolean = true,          // IV's own status bar on the home screen
    val showDate: Boolean = true,
    val showSeconds: Boolean = false,
    val showPercent: Boolean = true,
    val showNotificationIcons: Boolean = true,
    val showNetworkType: Boolean = true,
    val boldTime: Boolean = true,
    val sizeSp: Float = 15f,
)

@Serializable
data class VoiceCfg(
    val enabled: Boolean = true,
    val micButton: Boolean = true,              // mic next to the Search pill
    val volumeDownTwice: Boolean = true,        // press Volume Down twice quickly → IV Voice
    val offlineOnly: Boolean = false,           // true = never use the internet recogniser
    val confirmBeforeCall: Boolean = false,
    val aliases: Map<String, String> = emptyMap(),   // spoken word → contact name, e.g. "boss" → "Rahul Sharma"
    val wakeWord: String = "pixel",                  // optional word before a command: "Pixel, call Papa"
    val commands: List<CustomCommand> = emptyList(),
)

@Serializable
enum class CmdAction(val title: String, val needsTarget: String = "", val needsExtra: String = "") {
    CALL("Call a contact", "Contact name or number"),
    SMS("Send an SMS", "Contact name or number", "Message"),
    WHATSAPP("WhatsApp chat", "Contact name or number", "Message (optional)"),
    OPEN_APP("Open an app", "App name"),
    OPEN_URL("Open a website", "Website (e.g. youtube.com)"),
    NAVIGATE("Navigate to a place", "Place"),
    TORCH_ON("Flashlight on"),
    TORCH_OFF("Flashlight off"),
    ALARM("Set an alarm", "Time, e.g. 6:30 am"),
    TIMER("Start a timer", "Minutes"),
    MUSIC_TOGGLE("Play / pause music"),
    MUSIC_NEXT("Next song"),
    MUSIC_PREV("Previous song"),
    VOLUME_UP("Volume up"),
    VOLUME_DOWN("Volume down"),
    MUTE("Silent / mute"),
    CAMERA("Open camera"),
    SELFIE("Selfie camera"),
    LOCK("Lock the phone"),
    WIFI("Wi-Fi panel"),
    BLUETOOTH("Bluetooth settings"),
    SEARCH("Google search", "Search for…"),
}

/** A command you create: say or type [phrase] → IV does [action]. */
@Serializable
data class CustomCommand(
    val id: String,
    val phrase: String,
    val action: CmdAction,
    val target: String = "",
    val extra: String = "",
    val speaker: Boolean = false,
)

@Serializable
data class FeatureCfg(
    val weather: WeatherCfg = WeatherCfg(),
    val gestures: GestureCfg = GestureCfg(),
    val pill: PillCfg = PillCfg(),
    val decor: DecorCfg = DecorCfg(),
    val lock: LockCfg = LockCfg(),
    val call: CallCfg = CallCfg(),
    val statusBar: StatusBarCfg = StatusBarCfg(),
    val voice: VoiceCfg = VoiceCfg(),
    val batterySaver: Boolean = false,
)
