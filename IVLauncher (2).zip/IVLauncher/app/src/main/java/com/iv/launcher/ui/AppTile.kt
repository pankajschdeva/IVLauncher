package com.iv.launcher.ui

import android.graphics.Rect
import android.view.View
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.sizeIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.iv.launcher.data.AppInfo
import com.iv.launcher.data.BadgeCfg
import com.iv.launcher.data.BadgePos
import com.iv.launcher.data.BadgeStyle
import com.iv.launcher.data.FillType
import com.iv.launcher.data.IconLoader
import com.iv.launcher.data.IconStyle
import com.iv.launcher.data.Span
import com.iv.launcher.data.ThemeCfg

/**
 * One app on the home screen, dock, drawer or settings preview.
 * cellWidth is the width of one grid column; the tile grows for Wide/Big spans.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppTile(
    app: AppInfo,
    theme: ThemeCfg,
    cellWidth: Dp,
    modifier: Modifier = Modifier,
    span: Span = Span.S,
    badge: Int = 0,
    showLabel: Boolean = theme.label.show,
    onClick: (View, Rect) -> Unit = { _, _ -> },
    onLongClick: () -> Unit = {},
) {
    val view = LocalView.current
    val haptics = LocalHapticFeedback.current
    var bounds by remember { mutableStateOf(Rect()) }
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val pressAnim = theme.anim.enabled && theme.anim.press
    val scale by animateFloatAsState(
        targetValue = if (pressed && pressAnim) 0.88f else 1f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMedium * theme.anim.speed),
        label = "press",
    )

    val iconSize = theme.icon.sizeDp.dp
    val gap = (cellWidth - iconSize).coerceAtLeast(0.dp)
    val tileW = if (span == Span.S) iconSize else iconSize * 2 + gap
    val tileH = when (span) {
        Span.S, Span.W -> iconSize
        Span.B -> iconSize * 2 + gap
    }
    val shape = tileShape(theme.tile.cornerPercent)
    val glyphFraction = if (theme.icon.showTile) theme.icon.glyphScale else 1f
    val glyph = when (span) {
        Span.S, Span.W -> iconSize * glyphFraction
        Span.B -> tileH * (glyphFraction * 0.82f)
    }

    val clickModifier = Modifier.combinedClickable(
        interactionSource = interaction,
        indication = null,
        onClick = { onClick(view, bounds) },
        onLongClick = {
            haptics.performHapticFeedback(HapticFeedbackType.LongPress)
            onLongClick()
        },
    )

    Column(
        modifier = modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .then(clickModifier),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier = Modifier
                .size(tileW, tileH)
                .onGloballyPositioned { c ->
                    val r = c.boundsInWindow()
                    bounds = Rect(r.left.toInt(), r.top.toInt(), r.right.toInt(), r.bottom.toInt())
                },
        ) {
            Box(
                Modifier
                    .matchParentSize()
                    .then(
                        if (theme.icon.showTile) Modifier.ivFill(
                            fill = theme.tile.fill,
                            color = theme.tile.color,
                            gradient = theme.tile.gradient,
                            alpha = theme.tile.alpha,
                            shape = shape,
                            outline = theme.tile.outline,
                            outlineColor = theme.tile.outlineColor,
                            outlineWidthDp = theme.tile.outlineWidthDp,
                            shadowDp = theme.tile.shadowDp,
                        ) else Modifier
                    ),
            )
            if (span == Span.W) {
                Row(
                    Modifier.matchParentSize().padding(horizontal = (iconSize - glyph) / 2),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    AppGlyph(app, theme, glyph)
                    Spacer(Modifier.width(10.dp))
                    LabelText(app.label, theme, Modifier.weight(1f), align = TextAlign.Start, scale = 1.15f)
                }
            } else {
                AppGlyph(app, theme, glyph, Modifier.align(Alignment.Center))
            }
            if (badge > 0) {
                BadgeView(
                    count = badge,
                    cfg = theme.badge,
                    popEnabled = theme.anim.enabled && theme.anim.badgePop && theme.badge.pop,
                    modifier = Modifier
                        .align(if (theme.badge.position == BadgePos.TOP_END) Alignment.TopEnd else Alignment.TopStart)
                        .padding(0.dp)
                        .graphicsLayer {
                            val o = 6.dp.toPx()
                            translationX = if (theme.badge.position == BadgePos.TOP_END) o else -o
                            translationY = -o
                        }
                        .zIndex(2f),
                )
            }
        }
        if (showLabel && span != Span.W) {
            Spacer(Modifier.height(5.dp))
            LabelText(app.label, theme, Modifier.width(tileW + gap))
        }
    }
}

@Composable
fun LabelText(
    text: String,
    theme: ThemeCfg,
    modifier: Modifier = Modifier,
    align: TextAlign = TextAlign.Center,
    scale: Float = 1f,
) {
    val family = rememberFont(theme.label.font, theme.customFontVersion)
    Text(
        text = text,
        modifier = modifier,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        textAlign = align,
        style = TextStyle(
            color = theme.label.color.toColor(),
            fontSize = (theme.label.sizeSp * scale).sp,
            fontWeight = FontWeight(theme.label.weight.coerceIn(100, 900)),
            fontFamily = family,
            shadow = if (theme.label.shadow) Shadow(androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.55f), Offset(0f, 1.5f), 6f) else null,
        ),
    )
}

private val grayscale = ColorFilter.colorMatrix(ColorMatrix().apply { setToSaturation(0f) })

@Composable
fun AppGlyph(app: AppInfo, theme: ThemeCfg, size: Dp, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val px = with(LocalDensity.current) { size.roundToPx() }.coerceAtLeast(8)
    val style = theme.icon.style
    val loaded by produceState<Pair<ImageBitmap, Boolean>?>(null, app.key, style, px) {
        value = runCatching { IconLoader.load(context, app, style, px) }.getOrNull()
    }
    val pair = loaded ?: run {
        Spacer(modifier.size(size))
        return
    }
    val (bitmap, isMask) = pair
    val filter = when {
        isMask -> ColorFilter.tint(theme.icon.tint.toColor())
        style == IconStyle.ORIGINAL -> null
        else -> grayscale
    }
    Image(bitmap = bitmap, contentDescription = app.label, modifier = modifier.size(size), colorFilter = filter)
}

fun formatBadge(count: Int, compact: Boolean): String = when {
    count < 1000 -> count.toString()
    !compact -> "999+"
    count < 10_000 -> String.format("%.1fK", count / 1000f).replace(".0K", "K")
    else -> "${count / 1000}K"
}

@Composable
fun BadgeView(count: Int, cfg: BadgeCfg, popEnabled: Boolean, modifier: Modifier = Modifier) {
    if (cfg.style == BadgeStyle.OFF) return
    val pop = remember { Animatable(1f) }
    LaunchedEffect(count) {
        if (popEnabled) {
            pop.snapTo(1.35f)
            pop.animateTo(1f, spring(dampingRatio = 0.4f, stiffness = Spring.StiffnessMediumLow))
        }
    }
    val s = cfg.scale.coerceIn(0.5f, 2f)
    val m = modifier.graphicsLayer { scaleX = pop.value; scaleY = pop.value }
    if (cfg.style == BadgeStyle.DOT) {
        val bg = if (cfg.useGradient) Modifier.background(cfg.gradient.brush(), CircleShape)
        else Modifier.background(cfg.color.toColor(), CircleShape)
        val border = if (cfg.outline) Modifier.border(1.5.dp, cfg.outlineColor.toColor(), CircleShape) else Modifier
        Box(m.size((11 * s).dp).then(bg).then(border))
        return
    }
    Box(
        modifier = m
            .sizeIn(minWidth = (21 * s).dp, minHeight = (21 * s).dp)
            .then(if (cfg.useGradient) Modifier.background(cfg.gradient.brush(), RoundedCornerShape(50)) else Modifier.background(cfg.color.toColor(), RoundedCornerShape(50)))
            .then(if (cfg.outline) Modifier.border(1.5.dp, cfg.outlineColor.toColor(), RoundedCornerShape(50)) else Modifier)
            .padding(horizontal = (6 * s).dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = formatBadge(count, cfg.compact),
            color = cfg.textColor.toColor(),
            fontSize = (11.5f * s).sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
        )
    }
}

/** Shared "tile-like" container used by dock and search pill. */
fun ivPillModifier(
    fill: FillType, color: Long, gradient: com.iv.launcher.data.GradientSpec, alpha: Float,
    cornerDp: Float, outline: Boolean, outlineColor: Long,
): Modifier = Modifier.ivFill(
    fill = fill, color = color, gradient = gradient, alpha = alpha,
    shape = RoundedCornerShape(cornerDp.dp), outline = outline, outlineColor = outlineColor,
)
