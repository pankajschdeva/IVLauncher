package com.iv.launcher.ui

import android.text.format.DateFormat
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import com.iv.launcher.data.ClockCfg
import com.iv.launcher.data.ClockStyle
import com.iv.launcher.data.WeatherNow
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/** Current time, updated exactly when the minute changes. */
@Composable
fun rememberNow(): Long {
    val t by produceState(System.currentTimeMillis()) {
        while (true) {
            value = System.currentTimeMillis()
            delay(60_000 - value % 60_000 + 50)
        }
    }
    return t
}

/** Stretches the measured size too (not only the drawing), so tall clocks take real space. */
fun Modifier.stretch(sx: Float, sy: Float): Modifier = layout { measurable, constraints ->
    val p = measurable.measure(constraints.copy(minWidth = 0, minHeight = 0, maxWidth = androidx.compose.ui.unit.Constraints.Infinity))
    val w = (p.width * sx).roundToInt()
    val h = (p.height * sy).roundToInt()
    layout(w, h) {
        p.placeWithLayer(0, 0) {
            scaleX = sx; scaleY = sy
            transformOrigin = TransformOrigin(0f, 0f)
        }
    }
}

fun clockParts(context: android.content.Context, time: Long, cfg: ClockCfg): Pair<String, String> {
    val is24 = cfg.use24h || DateFormat.is24HourFormat(context)
    val d = Date(time)
    val h = SimpleDateFormat(if (is24) "HH" else "hh", Locale.getDefault()).format(d)
    val m = SimpleDateFormat("mm", Locale.getDefault()).format(d)
    return h to m
}

fun dateLine(time: Long, weather: WeatherNow?, cfg: ClockCfg): String {
    val date = SimpleDateFormat("EEE d", Locale.getDefault()).format(Date(time))
    val w = if (cfg.showWeather && weather != null) "   ${weather.emoji} ${weather.temp}°" else ""
    return if (cfg.showDate) date + w else w.trim()
}

/** The big clock in 7 styles. Used by the home clock widget and the settings preview. */
@OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
@Composable
fun BigClock(cfg: ClockCfg, weather: WeatherNow?, customFontVersion: Long, modifier: Modifier = Modifier, center: Boolean = true) {
    val context = LocalContext.current
    val now = rememberNow()
    val (hh, mm) = clockParts(context, now, cfg)
    val family = rememberFont(cfg.font, customFontVersion)
    val color = cfg.color.toColor()
    val base = TextStyle(
        fontFamily = family,
        fontWeight = FontWeight(cfg.weight.coerceIn(100, 900)),
        fontSize = cfg.sizeSp.sp,
        letterSpacing = cfg.letterSpacing.em,
        lineHeight = (cfg.sizeSp * 1.0f).sp,
        lineHeightStyle = LineHeightStyle(LineHeightStyle.Alignment.Center, LineHeightStyle.Trim.Both),
        color = color,
    )

    @Composable
    fun Digits(text: String, style: TextStyle = base) {
        when (cfg.style) {
            ClockStyle.OUTLINE -> Text(text, style = style.copy(drawStyle = Stroke(width = cfg.outlineDp * 3f)), modifier = Modifier.stretch(cfg.widthScale, cfg.heightScale))
            ClockStyle.GRADIENT -> Text(text, style = style.copy(brush = cfg.gradient.brush()), modifier = Modifier.stretch(cfg.widthScale, cfg.heightScale))
            ClockStyle.GLASS -> Box(Modifier.stretch(cfg.widthScale, cfg.heightScale)) {
                Text(text, style = style.copy(color = color.copy(alpha = 0.28f)))
                Text(text, style = style.copy(color = Color.White.copy(alpha = 0.75f), drawStyle = Stroke(width = cfg.outlineDp * 2f)))
            }
            else -> Text(text, style = style, modifier = Modifier.stretch(cfg.widthScale, cfg.heightScale))
        }
    }

    val dl = dateLine(now, weather, cfg)
    val dateText: @Composable () -> Unit = {
        if (dl.isNotBlank()) Text(
            dl, color = cfg.dateColor.toColor(), fontSize = cfg.dateSizeSp.sp, fontFamily = family,
            fontWeight = FontWeight.Medium,
        )
    }
    val align = if (center) Alignment.CenterHorizontally else Alignment.Start

    Column(modifier, horizontalAlignment = align) {
        when (cfg.style) {
            ClockStyle.STACKED -> {
                dateText()
                Spacer(Modifier.height(4.dp))
                Digits(hh)
                Digits(mm)
            }
            ClockStyle.SPLIT -> {
                dateText()
                Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.Center) {
                    Digits(hh)
                    Spacer(Modifier.width(6.dp))
                    Digits(mm, base.copy(fontSize = (cfg.sizeSp * 0.5f).sp, color = color.copy(alpha = 0.6f)))
                }
            }
            ClockStyle.MINIMAL -> {
                Text(
                    "$hh:$mm", style = base.copy(fontSize = (cfg.sizeSp * 0.42f).sp),
                    modifier = Modifier.stretch(cfg.widthScale, cfg.heightScale.coerceAtMost(1.4f)),
                )
                Spacer(Modifier.height(2.dp))
                dateText()
            }
            else -> {
                dateText()
                Spacer(Modifier.height(4.dp))
                Digits("$hh:$mm")
            }
        }
    }
}
