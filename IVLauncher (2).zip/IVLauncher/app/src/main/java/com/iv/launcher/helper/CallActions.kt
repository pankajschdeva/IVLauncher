package com.iv.launcher.helper

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.telecom.TelecomManager
import android.telephony.SmsManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.iv.launcher.badges.Live

object CallActions {

    private fun has(context: Context, p: String) = context.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    fun answer(context: Context) {
        val pi = Live.ringing.value?.answer
        if (pi != null && runCatching { pi.send() }.isSuccess) return
        if (has(context, Manifest.permission.ANSWER_PHONE_CALLS)) {
            runCatching { context.getSystemService(TelecomManager::class.java).acceptRingingCall() }
        } else toast(context, "Allow 'Answer calls' in IV Settings → Call Screen")
    }

    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    fun decline(context: Context) {
        val pi = Live.ringing.value?.decline
        if (pi != null && runCatching { pi.send() }.isSuccess) return
        if (has(context, Manifest.permission.ANSWER_PHONE_CALLS)) {
            runCatching { context.getSystemService(TelecomManager::class.java).endCall() }
        }
    }

    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    fun hangUp(context: Context) {
        val call = Live.items.value.firstOrNull { it.isCall }
        val end = call?.actions?.firstOrNull { it.title.equals("End", true) || it.title.contains("hang", true) }
        if (end != null && runCatching { end.intent.send() }.isSuccess) return
        if (has(context, Manifest.permission.ANSWER_PHONE_CALLS)) {
            runCatching { context.getSystemService(TelecomManager::class.java).endCall() }
        }
    }

    /** Decline + send a quick SMS. */
    fun reply(context: Context, text: String) {
        val number = Live.number.value
        decline(context)
        if (number.isNullOrBlank()) {
            toast(context, "Number unknown – allow Phone + Call log in IV Settings → Call Screen")
            return
        }
        if (has(context, Manifest.permission.SEND_SMS)) {
            runCatching {
                context.getSystemService(SmsManager::class.java).sendTextMessage(number, null, text, null, null)
                toast(context, "Message sent")
            }.onFailure { openSms(context, number, text) }
        } else openSms(context, number, text)
    }

    private fun openSms(context: Context, number: String, text: String) {
        runCatching {
            context.startActivity(
                Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number")).putExtra("sms_body", text)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    /** Decline + remind to call back later. */
    fun remind(context: Context, minutes: Int, name: String) {
        val number = Live.number.value.orEmpty()
        decline(context)
        val am = context.getSystemService(AlarmManager::class.java)
        val pi = PendingIntent.getBroadcast(
            context, (System.currentTimeMillis() % 100000).toInt(),
            Intent(context, ReminderReceiver::class.java).putExtra("name", name).putExtra("number", number),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        am.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + minutes * 60_000L, pi)
        toast(context, "I'll remind you in ${if (minutes >= 60) "${minutes / 60} h" else "$minutes min"}")
    }

    fun toast(context: Context, msg: String) = Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val name = intent.getStringExtra("name").orEmpty().ifBlank { "them" }
        val number = intent.getStringExtra("number").orEmpty()
        val nm = context.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("reminders", "Call reminders", NotificationManager.IMPORTANCE_HIGH))
        val tap = PendingIntent.getActivity(
            context, 1,
            Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE,
        )
        val n = NotificationCompat.Builder(context, "reminders")
            .setSmallIcon(android.R.drawable.sym_action_call)
            .setContentTitle("Call back $name")
            .setContentText(if (number.isNotBlank()) number else "Reminder from IV")
            .setContentIntent(tap)
            .setAutoCancel(true)
            .build()
        if (context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            nm.notify((System.currentTimeMillis() % 100000).toInt(), n)
        }
    }
}
