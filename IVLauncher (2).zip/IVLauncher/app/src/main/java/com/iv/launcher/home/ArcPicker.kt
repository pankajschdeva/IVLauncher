package com.iv.launcher.home

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.systemGestureExclusion
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.iv.launcher.data.AppInfo
import com.iv.launcher.data.ThemeCfg
import com.iv.launcher.ui.AppGlyph
import com.iv.launcher.ui.toColor
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Hold the bottom-right edge, slide your finger up/down along the arc, let go → that app opens.
 * The hot zone is excluded from Android's back gesture (Android allows up to 200dp per edge).
 */
@Composable
fun ArcPickerLayer(
    theme: ThemeCfg,
    apps: List<AppInfo>,
    accent: Color,
    haptics: Boolean,
    onOpen: (AppInfo) -> Unit,
) {
    if (apps.isEmpty()) return
    val density = LocalDensity.current
    val hf = LocalHapticFeedback.current
    var active by remember { mutableStateOf(false) }
    var fingerY by remember { mutableFloatStateOf(0f) }
    var selected by remember { mutableIntStateOf(-1) }
    var zoneTop by remember { mutableFloatStateOf(0f) }
    val show by animateFloatAsState(if (active) 1f else 0f, spring(dampingRatio = 0.8f), label = "arc")

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wPx = constraints.maxWidth.toFloat()
        val hPx = constraints.maxHeight.toFloat()
        val spacing = with(density) { 70.dp.toPx() }
        val n = apps.size
        val centerY = hPx * 0.5f
        val radius = hPx * 0.75f
        val cx = wPx + radius * 0.62f      // circle centre is off-screen on the right

        fun itemY(i: Int) = centerY + (i - (n - 1) / 2f) * spacing
        fun itemX(y: Float): Float {
            val dy = (y - centerY).coerceIn(-radius, radius)
            return cx - sqrt(radius * radius - dy * dy) - with(density) { 46.dp.toPx() }
        }

        if (show > 0.01f) {
            // Dim + arc + items
            Box(Modifier.fillMaxSize().graphicsLayer { alpha = show }.background(Color.Black.copy(alpha = 0.55f)))
            Canvas(Modifier.fillMaxSize().graphicsLayer { alpha = show }) {
                drawCircle(
                    color = accent.copy(alpha = 0.55f),
                    radius = radius,
                    center = Offset(cx, centerY),
                    style = Stroke(width = 1.5.dp.toPx()),
                )
                if (selected >= 0) {
                    val y = itemY(selected)
                    val x = cx - sqrt((radius * radius - (y - centerY) * (y - centerY)).coerceAtLeast(0f))
                    drawRoundRect(
                        color = accent,
                        topLeft = Offset(x - 2.dp.toPx(), y - 5.dp.toPx()),
                        size = Size(26.dp.toPx(), 10.dp.toPx()),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(5.dp.toPx()),
                    )
                }
            }
            apps.forEachIndexed { i, app ->
                val y = itemY(i)
                val x = itemX(y)
                val dist = abs(y - fingerY) / spacing
                val isSel = i == selected
                val a = (1f - dist * 0.22f).coerceIn(0.15f, 1f) * show
                val s = if (isSel) 1.12f else (1f - dist * 0.05f).coerceIn(0.8f, 1f)
                val iconSize = 50.dp
                Box(
                    Modifier
                        .offset { IntOffset((x - with(density) { iconSize.toPx() } / 2).roundToInt(), (y - with(density) { iconSize.toPx() } / 2).roundToInt()) }
                        .graphicsLayer { alpha = a; scaleX = s; scaleY = s }
                        .size(iconSize)
                        .background(if (isSel) accent.copy(alpha = 0.35f) else Color.White.copy(alpha = 0.10f), RoundedCornerShape(16.dp))
                        .then(if (isSel) Modifier.border(1.5.dp, accent, RoundedCornerShape(16.dp)) else Modifier),
                    contentAlignment = Alignment.Center,
                ) {
                    AppGlyph(app, theme.copy(icon = theme.icon.copy(showTile = false)), 30.dp)
                }
                // label on the left side of the icon
                Text(
                    app.label,
                    color = Color.White.copy(alpha = if (isSel) 1f else 0.7f),
                    fontSize = if (isSel) 15.sp else 13.sp,
                    fontWeight = if (isSel) FontWeight.SemiBold else FontWeight.Normal,
                    maxLines = 1,
                    modifier = Modifier
                        .offset { IntOffset((x - with(density) { 170.dp.toPx() }).roundToInt(), (y - with(density) { 10.dp.toPx() }).roundToInt()) }
                        .graphicsLayer { alpha = a }
                        .then(
                            if (isSel) Modifier.background(Color.White.copy(alpha = 0.12f), RoundedCornerShape(50)).padding(horizontal = 10.dp, vertical = 3.dp)
                            else Modifier
                        )
                        .size(width = 140.dp, height = 24.dp),
                )
            }
            if (selected >= 0) {
                val y = itemY(selected)
                Box(
                    Modifier
                        .offset { IntOffset((itemX(y)).roundToInt() - 40, y.roundToInt() - 40) }
                        .size(30.dp)
                        .blur(18.dp)
                        .background(accent.copy(alpha = 0.6f * show), RoundedCornerShape(50)),
                )
            }
        }

        // Hot zone: bottom-right edge
        Box(
            Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = 150.dp)
                .size(width = 26.dp, height = 200.dp)
                .systemGestureExclusion()
                .onGloballyPositioned { zoneTop = it.positionInRoot().y }
                .pointerInput(apps) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        active = true
                        fingerY = zoneTop + down.position.y
                        var last = -1
                        while (true) {
                            val event = awaitPointerEvent()
                            val ch = event.changes.firstOrNull() ?: break
                            fingerY = zoneTop + ch.position.y
                            val idx = (0 until n).minByOrNull { abs(itemY(it) - fingerY) } ?: -1
                            // need the finger within ~one spacing of an item
                            selected = if (idx >= 0 && abs(itemY(idx) - fingerY) < spacing * 0.9f) idx else -1
                            if (selected != last && selected >= 0 && haptics) hf.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            last = selected
                            if (ch.positionChange() != Offset.Zero) ch.consume()
                            if (!ch.pressed) break
                        }
                        val pick = selected
                        active = false
                        selected = -1
                        if (pick in 0 until n) onOpen(apps[pick])
                    }
                },
        )
    }
}
