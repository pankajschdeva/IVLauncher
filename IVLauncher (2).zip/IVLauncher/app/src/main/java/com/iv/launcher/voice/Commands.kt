package com.iv.launcher.voice

import android.Manifest
import android.annotation.SuppressLint
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.telecom.TelecomManager
import android.telephony.SmsManager
import android.view.KeyEvent
import com.iv.launcher.data.AppInfo
import com.iv.launcher.data.AppRepo
import com.iv.launcher.data.CmdAction
import com.iv.launcher.data.Media
import com.iv.launcher.data.Store
import com.iv.launcher.helper.IvHelperService
import java.net.URLEncoder

/** What IV understood: do [action] with [target] (and [extra]). */
data class Parsed(val action: CmdAction, val target: String = "", val extra: String = "", val speaker: Boolean = false)

data class Outcome(val ok: Boolean, val message: String, val retryOtherHearing: Boolean = false)

data class Contact(val name: String, val number: String, val mobile: Boolean, val primary: Boolean)

/**
 * Understands spoken or typed commands and runs them on the phone – no internet needed.
 * Your own commands (IV Settings → Voice & Commands) are checked first.
 */
object Commands {

    private val speakerRx = Regex("""\b(?:on|in|with|par|pe)?\s*(?:the\s+)?(?:loud\s*speaker|speaker\s*phone|speakerphone|speaker)\b""")

    /** Lower-case, no punctuation, wake words ("pixel", "hey google", "iv"…) removed from the start. */
    fun clean(raw: String): String {
        val wake = norm(Store.features.value.voice.wakeWord)
        var t = raw.lowercase().replace(Regex("""[.,!?;:"]"""), " ").replace(Regex("""\s+"""), " ").trim()
        val starters = listOf("hey", "hi", "ok", "okay", "google", "iv", "ivy", "pixel", wake).filter { it.isNotBlank() }
        var changed = true
        while (changed) {
            changed = false
            for (w in starters) if (t == w || t.startsWith("$w ")) { t = t.removePrefix(w).trim(); changed = true }
        }
        return t.replace(Regex("""\b(?:please|plz|now|jaldi|abhi)\b"""), " ").replace(Regex("""\s+"""), " ").trim()
    }

    fun parse(raw: String): Parsed? {
        var t = clean(raw)
        if (t.isBlank()) return null
        val speaker = speakerRx.containsMatchIn(t)

        // 1) Your own commands first.
        for (c in Store.features.value.voice.commands) {
            val p = clean(c.phrase)
            if (p.isBlank()) continue
            if (t == p || t.startsWith("$p ") || (p.length >= 4 && t.contains(p))) {
                // Your timers are typed in minutes; the engine works in seconds.
                val target = if (c.action == CmdAction.TIMER) ((c.target.trim().toIntOrNull() ?: 0) * 60).toString() else c.target
                return Parsed(c.action, target, c.extra, c.speaker || speaker)
            }
        }

        t = t.replace(speakerRx, " ").replace(Regex("""\s+"""), " ").trim()
        fun m(rx: String) = Regex(rx).find(t)?.groupValues

        m("""^(?:call|dial|phone|ring|video call)(?:\s+to)?\s+(.+)$""")?.let { return Parsed(CmdAction.CALL, it[1], speaker = speaker) }
        m("""^(.+?)\s+ko\s+(?:call|phone|dial)(?:\s+(?:karo|kar|lagao|laga|kar do))?$""")?.let { return Parsed(CmdAction.CALL, it[1], speaker = speaker) }
        m("""^whatsapp(?:\s+to)?\s+(.+?)(?:\s+(?:saying|that|ki)\s+(.+))?$""")?.let { return Parsed(CmdAction.WHATSAPP, it[1], it.getOrElse(2) { "" }) }
        m("""^(?:send\s+(?:a\s+)?(?:message|sms|text)\s+to|message|text|sms)\s+(.+?)(?:\s+(?:saying|that|ki)\s+(.+))?$""")?.let {
            return Parsed(CmdAction.SMS, it[1], it.getOrElse(2) { "" })
        }
        if (Regex("""\b(?:torch|flashlight|flash light|flash)\b""").containsMatchIn(t)) {
            val off = Regex("""\b(?:off|band|bandh|stop)\b""").containsMatchIn(t)
            return Parsed(if (off) CmdAction.TORCH_OFF else CmdAction.TORCH_ON)
        }
        m("""^(?:set\s+)?(?:an\s+)?alarm(?:\s+(?:for|at))?\s+(.+)$""")?.let { return Parsed(CmdAction.ALARM, it[1]) }
        m("""^wake me(?:\s+up)?(?:\s+at)?\s+(.+)$""")?.let { return Parsed(CmdAction.ALARM, it[1]) }
        m("""^(?:set\s+|start\s+)?(?:a\s+)?timer(?:\s+for)?\s+(\d+)\s*(second|sec|minute|min|hour|hr)s?$""")?.let {
            val n = it[1].toIntOrNull() ?: return null
            val sec = when { it[2].startsWith("h") -> n * 3600; it[2].startsWith("s") -> n; else -> n * 60 }
            return Parsed(CmdAction.TIMER, sec.toString())
        }
        m("""^(\d+)\s*(minute|min|second|sec)s?\s+timer$""")?.let {
            val n = it[1].toIntOrNull() ?: return null
            return Parsed(CmdAction.TIMER, (if (it[2].startsWith("s")) n else n * 60).toString())
        }
        if (Regex("""^(?:next|skip)(?:\s+(?:song|track|gaana))?$""").matches(t)) return Parsed(CmdAction.MUSIC_NEXT)
        if (Regex("""^(?:previous|prev|last|back)(?:\s+(?:song|track|gaana))?$""").matches(t)) return Parsed(CmdAction.MUSIC_PREV)
        if (Regex("""^(?:play|resume|pause|stop)(?:\s+(?:the\s+)?(?:music|song|songs|gaana|gaane))?$""").matches(t)) return Parsed(CmdAction.MUSIC_TOGGLE)
        if (Regex("""^(?:volume up|increase (?:the\s+)?volume|louder|turn it up)$""").matches(t)) return Parsed(CmdAction.VOLUME_UP)
        if (Regex("""^(?:volume down|decrease (?:the\s+)?volume|lower (?:the\s+)?volume|quieter|turn it down)$""").matches(t)) return Parsed(CmdAction.VOLUME_DOWN)
        if (Regex("""^(?:mute|silent|vibrate)(?:\s+(?:mode|phone|the phone))?$""").matches(t)) return Parsed(CmdAction.MUTE)
        if (Regex("""^lock(?:\s+(?:the|my))?(?:\s+(?:phone|screen|mobile))?$""").matches(t)) return Parsed(CmdAction.LOCK)
        if (Regex("""\bselfie\b|\bfront camera\b""").containsMatchIn(t)) return Parsed(CmdAction.SELFIE)
        if (Regex("""^(?:open\s+)?(?:the\s+)?camera$|^take (?:a\s+)?(?:photo|picture|pic)$""").matches(t)) return Parsed(CmdAction.CAMERA)
        if (Regex("""^(?:open\s+|turn on\s+|turn off\s+)?(?:wi ?fi|wifi)(?:\s+(?:settings|on|off))?$""").matches(t)) return Parsed(CmdAction.WIFI)
        if (Regex("""^(?:open\s+|turn on\s+|turn off\s+)?bluetooth(?:\s+(?:settings|on|off))?$""").matches(t)) return Parsed(CmdAction.BLUETOOTH)
        m("""^(?:navigate|directions|take me|go)\s+(?:to\s+)?(.+)$""")?.let { return Parsed(CmdAction.NAVIGATE, it[1]) }
        m("""^(?:search|google|search for)\s+(?:for\s+)?(.+)$""")?.let { return Parsed(CmdAction.SEARCH, it[1]) }
        m("""^(?:open|launch|start|kholo)\s+(.+)$""")?.let { return Parsed(CmdAction.OPEN_APP, it[1]) }
        m("""^(.+?)\s+(?:kholo|open karo|chalao)$""")?.let { return Parsed(CmdAction.OPEN_APP, it[1]) }
        return null
    }

    // ------------------------------------------------------------------ running a command

    @SuppressLint("MissingPermission")
    fun run(context: Context, p: Parsed): Outcome {
        val c = context
        fun start(i: Intent): Boolean = runCatching { c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.isSuccess
        return when (p.action) {
            CmdAction.CALL -> {
                val (name, num) = resolveNumber(c, p.target) ?: return Outcome(false, noContact(c, p.target), retryOtherHearing = true)
                if (!canCall(c)) return Outcome(false, "Allow 'Phone calls' for IV in IV Settings → Permissions")
                if (call(c, num, p.speaker)) Outcome(true, "Calling $name${if (p.speaker) " on speaker" else ""}")
                else Outcome(false, "Couldn't start the call")
            }
            CmdAction.SMS -> {
                val (name, num) = resolveNumber(c, p.target) ?: return Outcome(false, noContact(c, p.target), retryOtherHearing = true)
                if (p.extra.isNotBlank() && c.checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED &&
                    runCatching { c.getSystemService(SmsManager::class.java).sendTextMessage(num, null, p.extra, null, null) }.isSuccess
                ) Outcome(true, "Message sent to $name")
                else if (start(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$num")).putExtra("sms_body", p.extra))) Outcome(true, "Message to $name")
                else Outcome(false, "No messaging app found")
            }
            CmdAction.WHATSAPP -> {
                val (name, num) = resolveNumber(c, p.target) ?: return Outcome(false, noContact(c, p.target), retryOtherHearing = true)
                var digits = num.filter { it.isDigit() }
                if (digits.length == 10) digits = "91$digits"           // Indian mobile without country code
                if (digits.startsWith("0") && digits.length == 11) digits = "91" + digits.drop(1)
                val url = "https://wa.me/$digits" + if (p.extra.isNotBlank()) "?text=" + URLEncoder.encode(p.extra, "UTF-8") else ""
                if (start(Intent(Intent.ACTION_VIEW, Uri.parse(url)))) Outcome(true, "WhatsApp $name") else Outcome(false, "WhatsApp is not installed")
            }
            CmdAction.OPEN_APP -> {
                val app = findApp(p.target) ?: return Outcome(false, "No app called \"${p.target}\"", retryOtherHearing = true)
                AppRepo.launch(c, app, null, null); Outcome(true, "Opening ${app.label}")
            }
            CmdAction.OPEN_URL -> {
                val u = p.target.trim().let { if (it.startsWith("http")) it else "https://${it.replace(" ", "")}" }
                if (start(Intent(Intent.ACTION_VIEW, Uri.parse(u)))) Outcome(true, "Opening $u") else Outcome(false, "Couldn't open $u")
            }
            CmdAction.NAVIGATE -> {
                val q = Uri.encode(p.target)
                if (start(Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=$q"))) || start(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=$q"))))
                    Outcome(true, "Directions to ${p.target}") else Outcome(false, "No maps app found")
            }
            CmdAction.TORCH_ON, CmdAction.TORCH_OFF -> {
                val on = p.action == CmdAction.TORCH_ON
                val cm = c.getSystemService(CameraManager::class.java)
                val id = runCatching {
                    cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
                }.getOrNull()
                if (id != null && runCatching { cm.setTorchMode(id, on) }.isSuccess) Outcome(true, if (on) "Flashlight on" else "Flashlight off")
                else Outcome(false, "Flashlight not available")
            }
            CmdAction.ALARM -> {
                val (h, mi) = parseTime(p.target) ?: return Outcome(false, "Say a time like \"alarm 6:30 am\"")
                val ok = start(
                    Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, mi)
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                )
                if (ok) Outcome(true, "Alarm set for ${String.format("%02d:%02d", h, mi)}") else Outcome(false, "No clock app found")
            }
            CmdAction.TIMER -> {
                val seconds = p.target.trim().toIntOrNull() ?: 0   // always seconds here
                if (seconds <= 0) return Outcome(false, "Say \"timer 5 minutes\"")
                val ok = start(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, seconds).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                if (ok) Outcome(true, "Timer for ${if (seconds >= 60) "${seconds / 60} min" else "$seconds s"}") else Outcome(false, "No clock app found")
            }
            CmdAction.MUSIC_TOGGLE -> { if (Media.now.value != null) Media.togglePlay() else mediaKey(c, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE); Outcome(true, "Play / pause") }
            CmdAction.MUSIC_NEXT -> { if (Media.now.value != null) Media.next() else mediaKey(c, KeyEvent.KEYCODE_MEDIA_NEXT); Outcome(true, "Next song") }
            CmdAction.MUSIC_PREV -> { if (Media.now.value != null) Media.previous() else mediaKey(c, KeyEvent.KEYCODE_MEDIA_PREVIOUS); Outcome(true, "Previous song") }
            CmdAction.VOLUME_UP, CmdAction.VOLUME_DOWN -> {
                val am = c.getSystemService(AudioManager::class.java)
                repeat(2) {
                    am.adjustStreamVolume(
                        AudioManager.STREAM_MUSIC,
                        if (p.action == CmdAction.VOLUME_UP) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
                        AudioManager.FLAG_SHOW_UI,
                    )
                }
                Outcome(true, if (p.action == CmdAction.VOLUME_UP) "Volume up" else "Volume down")
            }
            CmdAction.MUTE -> {
                val am = c.getSystemService(AudioManager::class.java)
                runCatching { am.ringerMode = AudioManager.RINGER_MODE_VIBRATE }
                Outcome(true, "Phone on vibrate")
            }
            CmdAction.CAMERA -> if (start(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))) Outcome(true, "Camera") else Outcome(false, "No camera app")
            CmdAction.SELFIE -> {
                val i = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
                    .putExtra("android.intent.extras.CAMERA_FACING", 1)
                    .putExtra("android.intent.extras.LENS_FACING_FRONT", 1)
                    .putExtra("android.intent.extra.USE_FRONT_CAMERA", true)
                if (start(i)) Outcome(true, "Selfie camera") else Outcome(false, "No camera app")
            }
            CmdAction.LOCK -> {
                val ok = IvHelperService.instance?.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN) == true
                if (ok) Outcome(true, "Locked") else Outcome(false, "Turn on IV Helper to lock the phone by voice")
            }
            CmdAction.WIFI -> if (start(Intent(Settings.Panel.ACTION_WIFI))) Outcome(true, "Wi-Fi") else Outcome(false, "Couldn't open Wi-Fi")
            CmdAction.BLUETOOTH -> if (start(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))) Outcome(true, "Bluetooth") else Outcome(false, "Couldn't open Bluetooth")
            CmdAction.SEARCH -> {
                val ok = start(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, p.target))
                if (ok) Outcome(true, "Searching ${p.target}") else Outcome(false, "No search app found")
            }
        }
    }

    private fun noContact(c: Context, who: String) =
        if (!hasContacts(c)) "Allow Contacts so IV can find \"$who\"" else "No contact called \"$who\""

    private fun mediaKey(c: Context, code: Int) {
        val am = c.getSystemService(AudioManager::class.java)
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    /** "6:30 am", "7 pm", "18:45", "7" → hour, minute */
    fun parseTime(s: String): Pair<Int, Int>? {
        val t = s.lowercase().replace(".", "").replace("o'clock", "").trim()
        val r = Regex("""(\d{1,2})(?:[: ](\d{2}))?\s*(am|pm|a m|p m|morning|evening|night|baje)?""").find(t) ?: return null
        var h = r.groupValues[1].toInt()
        val mi = r.groupValues[2].toIntOrNull() ?: 0
        val ap = r.groupValues[3]
        if ((ap.startsWith("p") || ap == "evening" || ap == "night") && h < 12) h += 12
        if ((ap.startsWith("a") || ap == "morning") && h == 12) h = 0
        if (h !in 0..23 || mi !in 0..59) return null
        return h to mi
    }

    // ------------------------------------------------------------------ contacts & apps

    private val mom = setOf("mom", "mum", "mummy", "mumma", "mama", "mother", "maa", "ma", "mommy", "mammi", "amma")
    private val dad = setOf("dad", "papa", "pappa", "daddy", "father", "pa", "pitaji", "dady", "papaji")

    private fun norm(s: String) = s.lowercase().replace(Regex("[^a-z0-9 ]"), " ").replace(Regex("""\s+"""), " ").trim()

    fun hasContacts(c: Context) = c.checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
    fun canCall(c: Context) = c.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED

    /** A spoken name, alias or plain number → (display name, number). */
    fun resolveNumber(c: Context, who: String): Pair<String, String>? {
        val digits = who.filter { it.isDigit() || it == '+' }
        if (digits.count { it.isDigit() } >= 5) return who.trim() to digits
        return findContact(c, who)?.let { it.name to it.number }
    }

    fun loadContacts(context: Context): List<Contact> {
        if (!hasContacts(context)) return emptyList()
        val out = ArrayList<Contact>()
        val proj = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER,
            ContactsContract.CommonDataKinds.Phone.TYPE,
            ContactsContract.CommonDataKinds.Phone.IS_SUPER_PRIMARY,
        )
        runCatching {
            context.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, proj, null, null, null)?.use { cur ->
                while (cur.moveToNext()) {
                    val name = cur.getString(0) ?: continue
                    val num = cur.getString(1) ?: continue
                    out += Contact(
                        name, num,
                        mobile = cur.getInt(2) == ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE,
                        primary = cur.getInt(3) != 0,
                    )
                }
            }
        }
        return out
    }

    private fun lev(a: String, b: String): Int {
        val d = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = d[0]; d[0] = i
            for (j in 1..b.length) {
                val tmp = d[j]
                d[j] = minOf(d[j] + 1, d[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return d[b.length]
    }

    fun findContact(context: Context, spoken: String): Contact? {
        val q = norm(spoken)
        if (q.isBlank()) return null
        val aliases = Store.features.value.voice.aliases.mapKeys { norm(it.key) }
        val variants = buildSet {
            add(q)
            aliases[q]?.let { add(norm(it)) }
            if (q in mom) addAll(mom)
            if (q in dad) addAll(dad)
        }
        var best: Contact? = null
        var bestScore = 0
        for (c in loadContacts(context)) {
            val n = norm(c.name)
            val words = n.split(' ')
            var score = 0
            for (v in variants) {
                score = maxOf(
                    score,
                    when {
                        n == v -> 100
                        n.startsWith("$v ") -> 85
                        words.any { it == v } -> 75
                        v.length >= 4 && words.any { lev(it, v) <= 1 } -> 60
                        v.length >= 3 && n.contains(v) -> 45
                        else -> 0
                    },
                )
            }
            if (score == 0) continue
            if (c.mobile) score += 3
            if (c.primary) score += 2
            if (score > bestScore) { bestScore = score; best = c }
        }
        return best
    }

    @SuppressLint("MissingPermission")
    fun call(context: Context, number: String, speaker: Boolean): Boolean {
        if (!canCall(context)) return false
        val uri = Uri.fromParts("tel", number, null)
        val extras = Bundle().apply { putBoolean(TelecomManager.EXTRA_START_CALL_WITH_SPEAKERPHONE, speaker) }
        val tm = context.getSystemService(TelecomManager::class.java)
        if (tm != null && runCatching { tm.placeCall(uri, extras) }.isSuccess) return true
        return runCatching {
            context.startActivity(
                Intent(Intent.ACTION_CALL, uri)
                    .putExtra(TelecomManager.EXTRA_START_CALL_WITH_SPEAKERPHONE, speaker)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }.isSuccess
    }

    fun findApp(spoken: String): AppInfo? {
        val q = norm(spoken)
        val apps = AppRepo.apps.value
        return apps.firstOrNull { norm(it.label) == q }
            ?: apps.firstOrNull { norm(it.label).startsWith(q) }
            ?: apps.firstOrNull { norm(it.label).contains(q) }
            ?: apps.firstOrNull { q.length >= 4 && lev(norm(it.label), q) <= 2 }
    }
}
