package com.iv.launcher.home

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import com.iv.launcher.data.AppInfo
import com.iv.launcher.data.HomeItem
import com.iv.launcher.data.Span
import com.iv.launcher.data.Store
import com.iv.launcher.data.WidgetCfg

data class Placed(val item: HomeItem, val app: AppInfo?, val widget: WidgetCfg?, val col: Int, val row: Int, val w: Int, val h: Int)

/**
 * Fills pages left→right: each item goes into the first free spot on the current page,
 * and a new page starts when it does not fit. So pages keep growing to the right.
 */
fun packPages(items: List<HomeItem>, apps: Map<String, AppInfo>, widgets: Map<String, WidgetCfg>, cols: Int, rows: Int): List<List<Placed>> {
    val pages = mutableListOf<MutableList<Placed>>()
    var grid = Array(rows) { BooleanArray(cols) }
    var page = mutableListOf<Placed>()

    fun fits(r: Int, c: Int, w: Int, h: Int): Boolean {
        if (r + h > rows || c + w > cols) return false
        for (rr in r until r + h) for (cc in c until c + w) if (grid[rr][cc]) return false
        return true
    }

    fun findSpot(w: Int, h: Int): Pair<Int, Int>? {
        for (r in 0 until rows) for (c in 0 until cols) if (fits(r, c, w, h)) return r to c
        return null
    }

    for (item in items) {
        val widget = if (item.key.startsWith("w:")) widgets[item.key.removePrefix("w:")] ?: continue else null
        val app = if (widget == null) apps[item.key] ?: continue else null
        val w = (widget?.w ?: item.span.w).coerceIn(1, cols)
        val h = (widget?.h ?: item.span.h).coerceIn(1, rows)
        var spot = findSpot(w, h)
        if (spot == null) {
            pages += page
            page = mutableListOf()
            grid = Array(rows) { BooleanArray(cols) }
            spot = findSpot(w, h) ?: continue
        }
        val (r, c) = spot
        for (rr in r until r + h) for (cc in c until c + w) grid[rr][cc] = true
        page += Placed(item, app, widget, c, r, w, h)
    }
    if (page.isNotEmpty() || pages.isEmpty()) pages += page
    return pages
}

/** Layout edits used by the long-press menus. */
object HomeEdits {
    fun setSpan(key: String, span: Span) = Store.editLayout { l ->
        l.copy(home = l.home.map { if (it.key == key) it.copy(span = span) else it })
    }

    fun move(key: String, by: Int) = Store.editLayout { l ->
        val list = l.home.toMutableList()
        val i = list.indexOfFirst { it.key == key }
        if (i < 0) return@editLayout l
        val j = (i + by).coerceIn(0, list.lastIndex)
        val item = list.removeAt(i)
        list.add(j, item)
        l.copy(home = list)
    }

    fun addToHome(key: String) = Store.editLayout { l ->
        if (l.home.any { it.key == key }) l else l.copy(home = l.home + HomeItem(key))
    }

    fun removeFromHome(key: String) = Store.editLayout { l -> l.copy(home = l.home.filterNot { it.key == key }) }

    fun addToDock(key: String): Boolean {
        var ok = false
        Store.editLayout { l ->
            if (l.dock.contains(key) || l.dock.size >= 4) l
            else { ok = true; l.copy(dock = l.dock + key) }
        }
        return ok
    }

    fun removeFromDock(key: String) = Store.editLayout { l -> l.copy(dock = l.dock - key) }

    fun moveInDock(key: String, by: Int) = Store.editLayout { l ->
        val list = l.dock.toMutableList()
        val i = list.indexOf(key)
        if (i < 0) return@editLayout l
        val j = (i + by).coerceIn(0, list.lastIndex)
        list.removeAt(i); list.add(j, key)
        l.copy(dock = list)
    }

    fun toggleFavorite(key: String) = Store.editLayout { l ->
        l.copy(favorites = if (key in l.favorites) l.favorites - key else (l.favorites + key).take(10))
    }

    fun toggleBadge(pkg: String) = Store.editLayout { l ->
        l.copy(noBadge = if (pkg in l.noBadge) l.noBadge - pkg else l.noBadge + pkg)
    }
}

object QuickActions {
    private const val GEMINI = "com.google.android.apps.bard"
    private const val GOOGLE = "com.google.android.googlequicksearchbox"

    /** Opens Google search. Returns false if nothing could handle it. */
    fun openSearch(context: Context): Boolean {
        val tries = listOf(
            Intent(SearchManager.INTENT_ACTION_GLOBAL_SEARCH).setPackage(GOOGLE),
            Intent(SearchManager.INTENT_ACTION_GLOBAL_SEARCH),
            context.packageManager.getLaunchIntentForPackage(GOOGLE),
        )
        for (i in tries) {
            if (i == null) continue
            if (runCatching { context.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.isSuccess) return true
        }
        return false
    }

    /** Opens Gemini (the app if installed, otherwise the assistant). */
    fun openGemini(context: Context) {
        val tries = listOf(
            context.packageManager.getLaunchIntentForPackage(GEMINI),
            Intent(Intent.ACTION_ASSIST),
            Intent(Intent.ACTION_VOICE_COMMAND),
        )
        for (i in tries) {
            if (i == null) continue
            if (runCatching { context.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.isSuccess) return
        }
        Toast.makeText(context, "Gemini is not installed", Toast.LENGTH_SHORT).show()
    }
}
