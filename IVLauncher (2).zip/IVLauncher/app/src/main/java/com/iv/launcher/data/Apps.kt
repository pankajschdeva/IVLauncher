package com.iv.launcher.data

import android.app.ActivityOptions
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherActivityInfo
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.content.pm.ShortcutInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Rect
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Process
import android.os.UserHandle
import android.provider.MediaStore
import android.provider.Telephony
import android.util.LruCache
import android.view.View
import android.widget.Toast
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class AppInfo(
    val key: String,              // "package/activity"
    val label: String,
    val pkg: String,
    val component: ComponentName,
    val user: UserHandle,
    val info: LauncherActivityInfo,
)

object AppRepo {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var appContext: Context
    private lateinit var launcherApps: LauncherApps

    private val _apps = MutableStateFlow<List<AppInfo>>(emptyList())
    val apps: StateFlow<List<AppInfo>> = _apps

    fun init(context: Context) {
        appContext = context.applicationContext
        launcherApps = appContext.getSystemService(LauncherApps::class.java)
        launcherApps.registerCallback(object : LauncherApps.Callback() {
            override fun onPackageRemoved(packageName: String, user: UserHandle) = refresh(packageName)
            override fun onPackageAdded(packageName: String, user: UserHandle) = refresh(packageName)
            override fun onPackageChanged(packageName: String, user: UserHandle) = refresh(packageName)
            override fun onPackagesAvailable(packageNames: Array<out String>, user: UserHandle, replacing: Boolean) = refresh(null)
            override fun onPackagesUnavailable(packageNames: Array<out String>, user: UserHandle, replacing: Boolean) = refresh(null)
        })
        refresh(null)
    }

    private fun refresh(changedPkg: String?) {
        if (changedPkg != null) IconLoader.forget(changedPkg)
        scope.launch {
            val me = Process.myUserHandle()
            val list = launcherApps.getActivityList(null, me).map { info ->
                val cn = info.componentName
                AppInfo(
                    key = "${cn.packageName}/${cn.className}",
                    label = info.label?.toString()?.trim().orEmpty().ifEmpty { cn.packageName },
                    pkg = cn.packageName,
                    component = cn,
                    user = me,
                    info = info,
                )
            }.sortedBy { it.label.lowercase() }
            _apps.value = list
            ensureDefaultLayout(list)
        }
    }

    /** First run: fill the dock and the first home page with sensible apps. */
    private fun ensureDefaultLayout(list: List<AppInfo>) {
        if (list.isEmpty() || Store.layout.value.initialized) return
        fun firstOf(pkg: String?): AppInfo? = pkg?.let { p -> list.firstOrNull { it.pkg == p } }
        val pm = appContext.packageManager
        fun resolvePkg(intent: Intent): String? =
            pm.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
                ?.takeIf { it != "android" }

        val dock = listOfNotNull(
            firstOf(resolvePkg(Intent(Intent.ACTION_DIAL))),
            firstOf(Telephony.Sms.getDefaultSmsPackage(appContext)),
            firstOf(resolvePkg(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")))),
            firstOf(resolvePkg(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))),
        ).distinctBy { it.key }.map { it.key }

        val favourites = listOf(
            "com.whatsapp", "com.instagram.android", "com.spotify.music", "com.google.android.youtube",
            "com.snapchat.android", "com.twitter.android", "com.netflix.mediaclient",
            "com.amazon.avod.thirdpartyclient", "com.ubercab", "com.openai.chatgpt",
            "com.google.android.gm", "com.google.android.apps.photos", "com.google.android.calendar",
            "com.google.android.apps.maps", "com.google.android.deskclock", "com.android.settings",
        )
        val home = mutableListOf<HomeItem>()
        favourites.mapNotNull { firstOf(it) }.filter { it.key !in dock }.forEach { home += HomeItem(it.key) }
        if (home.size < 8) {
            list.filter { a -> a.key !in dock && home.none { it.key == a.key } && a.pkg != appContext.packageName }
                .take(12 - home.size).forEach { home += HomeItem(it.key) }
        }
        // One big tile so the mixed layout is visible from the start.
        if (home.isNotEmpty()) home[0] = home[0].copy(span = Span.B)

        Store.editLayout { if (it.initialized) it else it.copy(initialized = true, home = home, dock = dock) }
    }

    /** Puts home + dock back to the first-run layout. */
    fun resetLayout() {
        Store.editLayout { LayoutState() }
        ensureDefaultLayout(_apps.value)
    }

    fun launch(context: Context, app: AppInfo, view: View?, bounds: Rect?) {
        val animate = Store.theme.value.anim.let { it.enabled && it.openApp }
        val opts = if (animate && view != null && bounds != null)
            ActivityOptions.makeClipRevealAnimation(view, bounds.left, bounds.top, bounds.width(), bounds.height()).toBundle()
        else null
        runCatching { launcherApps.startMainActivity(app.component, app.user, bounds, opts) }
            .onFailure { Toast.makeText(context, "Can't open ${app.label}", Toast.LENGTH_SHORT).show() }
    }

    // ---------------------------------------------------------------- app shortcuts (Maps "Home", Chrome "Incognito"…)
    private val SC_FLAGS = LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC or
        LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST or LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED

    fun shortcuts(app: AppInfo): List<ShortcutInfo> = runCatching {
        if (!launcherApps.hasShortcutHostPermission()) return emptyList()
        val q = LauncherApps.ShortcutQuery().setPackage(app.pkg).setActivity(app.component).setQueryFlags(SC_FLAGS)
        launcherApps.getShortcuts(q, app.user).orEmpty()
            .filter { it.isEnabled && (it.isDynamic || it.isDeclaredInManifest) }
            .sortedBy { it.rank }.take(5)
    }.getOrDefault(emptyList())

    fun shortcut(pkg: String, id: String): ShortcutInfo? = runCatching {
        val q = LauncherApps.ShortcutQuery().setPackage(pkg).setShortcutIds(listOf(id)).setQueryFlags(SC_FLAGS)
        launcherApps.getShortcuts(q, Process.myUserHandle())?.firstOrNull()
    }.getOrNull()

    fun startShortcut(context: Context, pkg: String, id: String) {
        runCatching { launcherApps.startShortcut(pkg, id, null, null, Process.myUserHandle()) }
            .onFailure { Toast.makeText(context, "This shortcut isn't available any more", Toast.LENGTH_SHORT).show() }
    }

    fun shortcutIcon(context: Context, info: ShortcutInfo, sizePx: Int): Bitmap? = runCatching {
        val d = launcherApps.getShortcutIconDrawable(info, context.resources.displayMetrics.densityDpi) ?: return null
        val b = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, sizePx, sizePx)
        d.draw(Canvas(b))
        b
    }.getOrNull()

    fun pinRequest(intent: Intent): LauncherApps.PinItemRequest? = runCatching { launcherApps.getPinItemRequest(intent) }.getOrNull()

    fun appInfo(app: AppInfo) {
        runCatching { launcherApps.startAppDetailsActivity(app.component, app.user, null, null) }
    }

    fun uninstall(context: Context, pkg: String) {
        val intent = Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { context.startActivity(intent) }
    }
}

/** Which part of an app icon to draw. */
enum class IconLayer { FULL, FOREGROUND, MONOCHROME }

object IconLoader {
    private val cache = object : LruCache<String, ImageBitmap>(400) {}

    fun forget(pkg: String) {
        cache.snapshot().keys.filter { it.startsWith("$pkg/") }.forEach { cache.remove(it) }
    }

    /** Returns the bitmap plus whether it is an alpha mask that should be tinted. */
    suspend fun load(context: Context, app: AppInfo, style: IconStyle, sizePx: Int): Pair<ImageBitmap, Boolean> =
        withContext(Dispatchers.IO) {
            val drawable = app.info.getIcon(context.resources.displayMetrics.densityDpi)
            val adaptive = drawable as? AdaptiveIconDrawable
            val mono = if (Build.VERSION.SDK_INT >= 33) adaptive?.monochrome else null
            val layer = when {
                style == IconStyle.ORIGINAL -> IconLayer.FULL
                style == IconStyle.THEMED && mono != null -> IconLayer.MONOCHROME
                adaptive?.foreground != null -> IconLayer.FOREGROUND
                else -> IconLayer.FULL
            }
            val key = "${app.key}|$layer|$sizePx"
            val bmp = cache.get(key) ?: render(
                when (layer) {
                    IconLayer.FULL -> drawable
                    IconLayer.FOREGROUND -> adaptive!!.foreground
                    IconLayer.MONOCHROME -> mono!!
                },
                sizePx,
                layer != IconLayer.FULL,
            ).also { cache.put(key, it) }
            bmp to (layer == IconLayer.MONOCHROME)
        }

    private fun render(d: Drawable, size: Int, isAdaptiveLayer: Boolean): ImageBitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        if (isAdaptiveLayer) {
            // Adaptive layers are 108dp with the visible part in the middle 72dp → grow by 25% each side.
            val pad = size / 4
            d.setBounds(-pad, -pad, size + pad, size + pad)
        } else {
            d.setBounds(0, 0, size, size)
        }
        d.draw(canvas)
        return bmp.asImageBitmap()
    }
}
