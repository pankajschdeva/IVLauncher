package com.iv.launcher

import android.app.Application
import com.iv.launcher.data.AppRepo
import com.iv.launcher.data.Store

class IvApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Store.init(this)     // must be first: AppRepo uses the saved layout
        AppRepo.init(this)
        com.iv.launcher.widgets.WidgetHost.init(this)
    }
}
