package com.iv.launcher.data

/** Ready-made looks. Picking one replaces the look; your apps and layout stay the same. */
object Presets {

    val dark = ThemeCfg(name = "Dark")

    val amoled = ThemeCfg(
        name = "AMOLED Black",
        background = BackgroundCfg(type = BgType.SOLID, color = 0xFF000000),
        tile = TileCfg(color = 0xFF0B0B0B, outline = true, outlineColor = 0x40FFFFFF, cornerPercent = 28),
        icon = IconCfg(style = IconStyle.MONO),
        dock = DockCfg(fill = FillType.SOLID, color = 0xFF0B0B0B, alpha = 1f, outlineColor = 0x30FFFFFF),
        search = SearchCfg(color = 0xFF0B0B0B, alpha = 1f),
        drawer = DrawerCfg(color = 0xFF000000, alpha = 1f, blurDp = 0f),
    )

    val light = ThemeCfg(
        name = "Light",
        accent = 0xFF3D3D46,
        darkStatusIcons = true,
        background = BackgroundCfg(
            type = BgType.GRADIENT,
            gradient = GradientSpec(listOf(0xFFF6F6F8, 0xFFDCDCE2), 180f),
        ),
        tile = TileCfg(color = 0xFFFFFFFF, outline = true, outlineColor = 0x14000000, shadowDp = 2f),
        icon = IconCfg(style = IconStyle.THEMED, tint = 0xFF1E1E22),
        label = LabelCfg(color = 0xFF1E1E22, shadow = false),
        badge = BadgeCfg(color = 0xFF1E1E22, textColor = 0xFFFFFFFF),
        dock = DockCfg(fill = FillType.SOLID, color = 0xFFFFFFFF, alpha = 0.7f, outlineColor = 0x14000000),
        search = SearchCfg(color = 0xFFFFFFFF, alpha = 0.85f, textColor = 0xFF3A3A40, outlineColor = 0x14000000),
        drawer = DrawerCfg(color = 0xFFF2F2F5, alpha = 0.94f),
    )

    val glass = ThemeCfg(
        name = "Glass",
        background = BackgroundCfg(type = BgType.SYSTEM, dim = 0.15f),
        tile = TileCfg(
            fill = FillType.GLASS, color = 0xFFFFFFFF, alpha = 0.16f,
            outline = true, outlineColor = 0x55FFFFFF, cornerPercent = 30,
        ),
        icon = IconCfg(style = IconStyle.THEMED, tint = 0xFFFFFFFF),
        badge = BadgeCfg(color = 0xCCFFFFFF, textColor = 0xFF111111),
        dock = DockCfg(fill = FillType.GLASS, color = 0xFFFFFFFF, alpha = 0.14f, outlineColor = 0x44FFFFFF),
        search = SearchCfg(color = 0xFFFFFFFF, alpha = 0.16f, outlineColor = 0x44FFFFFF),
        drawer = DrawerCfg(color = 0xFF101014, alpha = 0.6f),
    )

    /** Soft "felt / plush" look: charcoal + cream, round chunky tiles. (Fur texture comes in Phase 4.) */
    val plush = ThemeCfg(
        name = "Plush",
        accent = 0xFFE9E1CF,
        background = BackgroundCfg(
            type = BgType.GRADIENT,
            gradient = GradientSpec(listOf(0xFF2E2E2E, 0xFF0D0D0D), 160f),
        ),
        tile = TileCfg(
            fill = FillType.PLUSH,
            gradient = GradientSpec(listOf(0xFF4A4A4A, 0xFF2B2B2B), 135f),
            cornerPercent = 50, outline = true, outlineWidthDp = 1.5f, outlineColor = 0x26FFFFFF, shadowDp = 8f,
        ),
        icon = IconCfg(style = IconStyle.THEMED, tint = 0xFFE9E1CF, glyphScale = 0.55f, sizeDp = 64),
        label = LabelCfg(font = FontChoice.POPPINS, color = 0xFFE9E1CF, weight = 500),
        badge = BadgeCfg(color = 0xFFE9E1CF, textColor = 0xFF2B2B2B),
        dock = DockCfg(fill = FillType.PLUSH, gradient = GradientSpec(listOf(0xFF3A3A3A, 0xFF242424), 135f), alpha = 0.95f, cornerDp = 40f),
        search = SearchCfg(color = 0xFF3A3A3A, alpha = 1f, textColor = 0xFFE9E1CF),
        drawer = DrawerCfg(color = 0xFF1A1A1A, alpha = 0.96f),
    )

    val gradientNight = ThemeCfg(
        name = "Gradient Night",
        accent = 0xFFC4A8FF,
        background = BackgroundCfg(
            type = BgType.GRADIENT,
            gradient = GradientSpec(listOf(0xFF1A1033, 0xFF06060C), 200f),
        ),
        tile = TileCfg(
            fill = FillType.GRADIENT,
            gradient = GradientSpec(listOf(0xFF3B2A6B, 0xFF151024), 135f),
            outline = true, outlineColor = 0x44C4A8FF, cornerPercent = 28,
        ),
        icon = IconCfg(style = IconStyle.THEMED, tint = 0xFFEDE6FF),
        label = LabelCfg(font = FontChoice.POPPINS, color = 0xFFEDE6FF),
        badge = BadgeCfg(useGradient = true, textColor = 0xFFFFFFFF),
        dock = DockCfg(fill = FillType.GLASS, color = 0xFF2A1F4A, alpha = 0.6f, outlineColor = 0x44C4A8FF),
        search = SearchCfg(color = 0xFF2A1F4A, alpha = 0.7f, outlineColor = 0x44C4A8FF),
        drawer = DrawerCfg(color = 0xFF0B0716, alpha = 0.9f),
    )

    val original = ThemeCfg(
        name = "Original Colors",
        tile = TileCfg(fill = FillType.NONE, outline = false),
        icon = IconCfg(style = IconStyle.ORIGINAL, glyphScale = 1f, showTile = false, sizeDp = 58),
        badge = BadgeCfg(color = 0xFFFF3B30, textColor = 0xFFFFFFFF),
    )

    val all = listOf(dark, amoled, light, glass, plush, gradientNight, original)
}
