package com.iv.launcher.data

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.telephony.TelephonyCallback
import android.telephony.TelephonyDisplayInfo
import android.telephony.TelephonyManager
import kotlinx.coroutines.flow.MutableStateFlow

data class StatusNow(
    val battery: Int = 0,
    val charging: Boolean = false,
    val wifi: Boolean = false,
    val wifiLevel: Int = 0,      // 0..4
    val cellLevel: Int = 0,      // 0..4
    val netType: String = "",    // 5G, 4G, LTE, 3G…
    val airplane: Boolean = false,
    val online: Boolean = false,
)

/** Battery, Wi-Fi, mobile signal and 5G/4G label for IV's own status bar. */
object StatusInfo {
    val now = MutableStateFlow(StatusNow())
    private var appContext: Context? = null
    private val main = Handler(Looper.getMainLooper())
    private var override = TelephonyDisplayInfo.OVERRIDE_NETWORK_TYPE_NONE
    private var started = false

    private val battery = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            i ?: return
            val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
            val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
            val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, 0)
            now.value = now.value.copy(
                battery = level * 100 / scale,
                charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL,
            )
        }
    }

    private val netCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
            val wifi = caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
            val ctx = appContext
            val wl = if (wifi && ctx != null) runCatching {
                ctx.getSystemService(WifiManager::class.java).calculateSignalLevel(caps.signalStrength).coerceIn(0, 4)
            }.getOrDefault(3) else 0
            now.value = now.value.copy(wifi = wifi, wifiLevel = wl, online = true)
        }
        override fun onLost(network: Network) { now.value = now.value.copy(wifi = false, online = false) }
    }

    private val displayCb = object : TelephonyCallback(), TelephonyCallback.DisplayInfoListener {
        override fun onDisplayInfoChanged(info: TelephonyDisplayInfo) {
            override = info.overrideNetworkType
            poll()
        }
    }

    private val ticker = object : Runnable {
        override fun run() { poll(); main.postDelayed(this, 5000) }
    }

    fun start(context: Context) {
        if (started) return
        started = true
        val c = context.applicationContext
        appContext = c
        runCatching { androidx.core.content.ContextCompat.registerReceiver(c, battery, IntentFilter(Intent.ACTION_BATTERY_CHANGED), androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED) }
        runCatching { c.getSystemService(ConnectivityManager::class.java).registerDefaultNetworkCallback(netCallback) }
        if (c.checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
            runCatching { c.getSystemService(TelephonyManager::class.java).registerTelephonyCallback(c.mainExecutor, displayCb) }
        }
        ticker.run()
    }

    fun stop() {
        if (!started) return
        started = false
        val c = appContext ?: return
        runCatching { c.unregisterReceiver(battery) }
        runCatching { c.getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(netCallback) }
        runCatching { c.getSystemService(TelephonyManager::class.java).unregisterTelephonyCallback(displayCb) }
        main.removeCallbacks(ticker)
    }

    private fun poll() {
        val c = appContext ?: return
        val tm = c.getSystemService(TelephonyManager::class.java)
        val level = runCatching { tm?.signalStrength?.level ?: 0 }.getOrDefault(0)
        val airplane = Settings.Global.getInt(c.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) != 0
        val type = if (c.checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
            when (override) {
                TelephonyDisplayInfo.OVERRIDE_NETWORK_TYPE_NR_NSA, TelephonyDisplayInfo.OVERRIDE_NETWORK_TYPE_NR_ADVANCED -> "5G"
                TelephonyDisplayInfo.OVERRIDE_NETWORK_TYPE_LTE_CA, TelephonyDisplayInfo.OVERRIDE_NETWORK_TYPE_LTE_ADVANCED_PRO -> "4G+"
                else -> runCatching { label(tm!!.dataNetworkType) }.getOrDefault("")
            }
        } else ""
        now.value = now.value.copy(cellLevel = level.coerceIn(0, 4), netType = type, airplane = airplane)
    }

    private fun label(t: Int) = when (t) {
        TelephonyManager.NETWORK_TYPE_NR -> "5G"
        TelephonyManager.NETWORK_TYPE_LTE -> "4G"
        TelephonyManager.NETWORK_TYPE_HSPAP -> "H+"
        TelephonyManager.NETWORK_TYPE_HSPA, TelephonyManager.NETWORK_TYPE_HSDPA, TelephonyManager.NETWORK_TYPE_HSUPA -> "H"
        TelephonyManager.NETWORK_TYPE_UMTS -> "3G"
        TelephonyManager.NETWORK_TYPE_EDGE -> "E"
        TelephonyManager.NETWORK_TYPE_GPRS -> "G"
        else -> ""
    }
}
