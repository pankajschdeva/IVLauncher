package com.iv.launcher.settings

import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.rememberDrawerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.iv.launcher.R
import com.iv.launcher.badges.BadgeService
import com.iv.launcher.data.AppRepo
import com.iv.launcher.data.BadgePos
import com.iv.launcher.data.BadgeStyle
import com.iv.launcher.data.BgType
import com.iv.launcher.data.FillType
import com.iv.launcher.data.FontChoice
import com.iv.launcher.data.IconStyle
import com.iv.launcher.data.PageAnim
import com.iv.launcher.data.Presets
import com.iv.launcher.data.Span
import com.iv.launcher.data.Store
import com.iv.launcher.data.ThemeCfg
import com.iv.launcher.ui.AppTile
import com.iv.launcher.ui.IvBackground
import com.iv.launcher.ui.Fonts
import com.iv.launcher.ui.brush
import com.iv.launcher.ui.rememberBackgroundBitmap
import com.iv.launcher.ui.rememberFont
import com.iv.launcher.ui.toColor
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class SettingsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val theme by Store.theme.collectAsState()
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = theme.accent.toColor().copy(alpha = 1f),
                    background = Color(0xFF0B0B0D),
                    surface = Color(0xFF0B0B0D),
                ),
            ) {
                SettingsScreen(theme, intent?.getStringExtra("tab"), intent?.getBooleanExtra("menu", false) == true)
            }
        }
    }
}

private val tabs = listOf(
    "Presets", "Background", "Icons", "Tiles & Borders", "Fonts & Labels", "Colors", "Badges",
    "Widgets", "Weather", "Status Bar", "Voice", "Dock & Search", "Drawer", "Arc Picker", "Gestures", "Top Pill",
    "Camera Decor", "Lock Screen", "Call Screen", "Animations", "Layout", "Permissions", "More",
)

private fun edit(block: (ThemeCfg) -> ThemeCfg) = Store.editTheme(block)

@Composable
private fun SettingsScreen(theme: ThemeCfg, startTab: String?, startWithMenu: Boolean = false) {
    val context = LocalContext.current
    val features by Store.features.collectAsState()
    var tab by rememberSaveable { mutableIntStateOf(tabs.indexOf(startTab).coerceAtLeast(0)) }
    var isDefault by remember { mutableStateOf(isDefaultHome(context)) }
    var hasBadges by remember { mutableStateOf(BadgeService.hasAccess(context)) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        isDefault = isDefaultHome(context)
        hasBadges = BadgeService.hasAccess(context)
    }
    val roleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        isDefault = isDefaultHome(context)
        if (!isDefault) openHomeSettings(context)
    }

    val drawerState = rememberDrawerState(if (startWithMenu) DrawerValue.Open else DrawerValue.Closed)
    val menuScope = rememberCoroutineScope()
    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = Color(0xFF111114)) {
                FeatureHub(theme, features) { t ->
                    tab = tabs.indexOf(t).coerceAtLeast(0)
                    menuScope.launch { drawerState.close() }
                }
            }
        },
    ) {
    Column(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF0B0B0D))
            .statusBarsPadding(),
    ) {
        // Title: "☰  IV Launcher"
        Row(Modifier.padding(start = 8.dp, end = 20.dp, top = 8.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { menuScope.launch { drawerState.open() } }) {
                Icon(Icons.Filled.Menu, contentDescription = "All features", tint = Color.White)
            }
            Text("IV", color = theme.accent.toColor().copy(alpha = 1f), fontSize = 32.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.width(8.dp))
            Text("Launcher", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Light)
        }
        Text(
            "Everything here changes your home screen instantly.",
            color = Color(0xFF9A9AA2), fontSize = 13.sp,
            modifier = Modifier.padding(horizontal = 20.dp),
        )

        if (!isDefault) {
            Banner("IV Launcher is not your Home app yet", "Tap to make it your home screen") {
                val rm = context.getSystemService(RoleManager::class.java)
                if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME)) {
                    roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_HOME))
                } else openHomeSettings(context)
            }
        } else if (!hasBadges && theme.badge.style != BadgeStyle.OFF) {
            Banner("Turn on notification numbers", "Allow notification access so icons can show counts") {
                openBadgeAccess(context)
            }
        }

        Preview(theme)

        ScrollableTabRow(
            selectedTabIndex = tab,
            edgePadding = 12.dp,
            containerColor = Color(0xFF0B0B0D),
            contentColor = Color.White,
            divider = {},
        ) {
            tabs.forEachIndexed { i, t ->
                Tab(selected = tab == i, onClick = { tab = i }, text = {
                    Text(t, fontWeight = if (tab == i) FontWeight.Bold else FontWeight.Normal)
                })
            }
        }

        Column(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding()
                .padding(vertical = 8.dp),
        ) {
            when (tabs[tab]) {
                "Presets" -> PresetsTab(theme)
                "Background" -> BackgroundTab(theme)
                "Icons" -> IconsTab(theme)
                "Tiles & Borders" -> TilesTab(theme)
                "Fonts & Labels" -> FontsTab(theme)
                "Colors" -> ColorsTab(theme)
                "Badges" -> BadgesTab(theme, hasBadges)
                "Widgets" -> WidgetsTab(theme)
                "Weather" -> WeatherTab(features)
                "Status Bar" -> StatusBarTab(features)
                "Voice" -> VoiceTab(features)
                "Arc Picker" -> ArcTab(features)
                "Gestures" -> GesturesTab(features)
                "Top Pill" -> PillTab(features)
                "Camera Decor" -> DecorTab(features)
                "Lock Screen" -> LockTab(features, theme)
                "Call Screen" -> CallTab(features)
                "Permissions" -> PermissionsTab()
                "Dock & Search" -> DockTab(theme)
                "Drawer" -> DrawerTab(theme)
                "Animations" -> AnimTab(theme)
                "Layout" -> LayoutTab(theme)
                "More" -> MoreTab(theme, isDefault) {
                    val rm = context.getSystemService(RoleManager::class.java)
                    if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME) && !isDefault) {
                        roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_HOME))
                    } else openHomeSettings(context)
                }
            }
            Spacer(Modifier.height(30.dp))
        }
    }
    }
}

@Composable
private fun Banner(title: String, subtitle: String, onClick: () -> Unit) {
    Column(
        Modifier
            .padding(horizontal = 14.dp, vertical = 8.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.18f))
            .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f), RoundedCornerShape(18.dp))
            .clickable { onClick() }
            .padding(14.dp),
    ) {
        Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
        Text(subtitle, color = Color(0xFFCCCCD2), fontSize = 13.sp)
    }
}

/** Small live preview: your background + 4 real apps with sample badges. */
@Composable
private fun Preview(theme: ThemeCfg) {
    val apps by AppRepo.apps.collectAsState()
    val bmp = rememberBackgroundBitmap(theme)
    val sample = remember(apps) {
        val prefer = listOf("com.whatsapp", "com.instagram.android", "com.google.android.youtube", "com.spotify.music")
        (prefer.mapNotNull { p -> apps.firstOrNull { it.pkg == p } } + apps).distinctBy { it.key }.take(4)
    }
    val counts = listOf(129, 5, 0, 28)
    Box(
        Modifier
            .padding(horizontal = 14.dp, vertical = 8.dp)
            .fillMaxWidth()
            .height(132.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(Color(0xFF222228)),
    ) {
        IvBackground(theme, bmp)
        BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            val cell = maxWidth / 4
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                sample.forEachIndexed { i, app ->
                    AppTile(app = app, theme = theme, cellWidth = cell, badge = counts[i], modifier = Modifier.width(cell))
                }
            }
        }
        if (sample.isEmpty()) Text("Loading apps…", color = Color.White, modifier = Modifier.align(Alignment.Center))
    }
}

// ------------------------------------------------------------------ tabs

@Composable
private fun PresetsTab(theme: ThemeCfg) {
    Section("Theme presets", "Pick a starting look, then fine-tune it in the other tabs. Your apps stay where they are.") {
        Presets.all.forEach { p ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { Store.applyPreset(p) }
                    .padding(horizontal = 18.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier
                        .size(width = 56.dp, height = 40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            when (p.background.type) {
                                BgType.GRADIENT -> p.background.gradient.brush()
                                BgType.SOLID -> androidx.compose.ui.graphics.SolidColor(p.background.color.toColor())
                                else -> androidx.compose.ui.graphics.SolidColor(Color(0xFF3A3A44))
                            }
                        ),
                    contentAlignment = Alignment.Center,
                ) {
                    Box(
                        Modifier
                            .size(20.dp)
                            .clip(RoundedCornerShape(p.tile.cornerPercent))
                            .background(
                                if (p.tile.fill == FillType.GRADIENT) p.tile.gradient.brush()
                                else androidx.compose.ui.graphics.SolidColor(
                                    if (p.tile.fill == FillType.NONE) Color.Transparent
                                    else p.tile.color.toColor().copy(alpha = p.tile.alpha.coerceAtLeast(0.3f))
                                )
                            )
                            .border(1.dp, p.tile.outlineColor.toColor(), RoundedCornerShape(p.tile.cornerPercent)),
                    )
                }
                Spacer(Modifier.width(14.dp))
                Text(p.name, color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f))
                if (theme.name == p.name) Text("✓", color = MaterialTheme.colorScheme.primary, fontSize = 18.sp)
            }
        }
    }
}

@Composable
private fun BackgroundTab(theme: ThemeCfg) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val bg = theme.background
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            if (!Store.saveBackground(context, uri)) toast(context, "Couldn't open that picture")
        }
    }
    Section("Background type", "System = your normal Android wallpaper. Image = a picture chosen here (needed for blur).") {
        ChoiceRow("Type", BgType.entries, bg.type, { it.name.lowercase().replaceFirstChar { c -> c.uppercase() } }) { t ->
            if (t == BgType.IMAGE && !Store.backgroundFile.exists()) {
                picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            } else edit { it.copy(background = it.background.copy(type = t)) }
        }
        ButtonRow("Choose picture from gallery", "Saved inside IV, works with blur") {
            picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }
        ButtonRow("Change system wallpaper", "Opens Android's wallpaper picker") {
            runCatching {
                context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper"))
            }
        }
    }
    if (bg.type == BgType.SOLID) Section("Solid color") {
        ColorRow("Color", bg.color) { c -> edit { it.copy(background = it.background.copy(color = c)) } }
    }
    if (bg.type == BgType.GRADIENT) Section("Gradient") {
        GradientRow("Gradient", bg.gradient) { g -> edit { it.copy(background = it.background.copy(gradient = g)) } }
    }
    Section("Effects") {
        SliderRow("Blur (picture only)", bg.blurDp, 0f..40f, { "${it.roundToInt()} dp" }) { v ->
            edit { it.copy(background = it.background.copy(blurDp = v)) }
        }
        SliderRow("Darken", bg.dim, 0f..0.85f, { "${(it * 100).roundToInt()}%" }) { v ->
            edit { it.copy(background = it.background.copy(dim = v)) }
        }
        SwitchRow("Dark status bar icons", theme.darkStatusIcons, "Turn on for light backgrounds") { v ->
            edit { it.copy(darkStatusIcons = v) }
        }
    }
}

@Composable
private fun IconsTab(theme: ThemeCfg) {
    val i = theme.icon
    Section("Icon style", "Mono = black & white like your screenshots. Themed = one color (uses Android 13+ themed icons when the app has one).") {
        ChoiceRow("Style", IconStyle.entries, i.style, {
            when (it) { IconStyle.ORIGINAL -> "Original colors"; IconStyle.MONO -> "Mono (B&W)"; IconStyle.THEMED -> "Themed color" }
        }) { s -> edit { it.copy(icon = it.icon.copy(style = s)) } }
        if (i.style == IconStyle.THEMED) {
            ColorRow("Icon color", i.tint) { c -> edit { it.copy(icon = it.icon.copy(tint = c)) } }
        }
    }
    Section("Size") {
        SliderRow("Icon size", i.sizeDp.toFloat(), 40f..84f, { "${it.roundToInt()} dp" }) { v ->
            edit { it.copy(icon = it.icon.copy(sizeDp = v.roundToInt())) }
        }
        SliderRow("Symbol size inside tile", i.glyphScale, 0.35f..1f, { "${(it * 100).roundToInt()}%" }) { v ->
            edit { it.copy(icon = it.icon.copy(glyphScale = v)) }
        }
    }
    Section("Tile behind icon") {
        SwitchRow("Show tile / background", i.showTile, "Off = icon only, no box behind it") { v ->
            edit { it.copy(icon = it.icon.copy(showTile = v)) }
        }
    }
    Section("Big & wide icons", "Long-press any app on the home screen → choose ${Span.entries.joinToString(" / ") { it.title }}.") {}
}

@Composable
private fun TilesTab(theme: ThemeCfg) {
    val t = theme.tile
    Section("Fill") {
        ChoiceRow("Fill type", FillType.entries, t.fill, {
            when (it) { FillType.NONE -> "None"; FillType.SOLID -> "Solid"; FillType.GRADIENT -> "Gradient"; FillType.GLASS -> "Glass"; FillType.PLUSH -> "Plush (felt)" }
        }) { f -> edit { it.copy(tile = it.tile.copy(fill = f)) } }
        if (t.fill == FillType.SOLID || t.fill == FillType.GLASS) {
            ColorRow("Tile color", t.color) { c -> edit { it.copy(tile = it.tile.copy(color = c)) } }
        }
        if (t.fill == FillType.GRADIENT || t.fill == FillType.PLUSH) {
            GradientRow("Tile gradient", t.gradient) { g -> edit { it.copy(tile = it.tile.copy(gradient = g)) } }
        }
        SliderRow("Opacity", t.alpha, 0f..1f, { "${(it * 100).roundToInt()}%" }) { v ->
            edit { it.copy(tile = it.tile.copy(alpha = v)) }
        }
    }
    Section("Shape") {
        SliderRow("Corner roundness", t.cornerPercent.toFloat(), 0f..50f, { if (it >= 49.5f) "Circle" else "${it.roundToInt()}%" }) { v ->
            edit { it.copy(tile = it.tile.copy(cornerPercent = v.roundToInt())) }
        }
        SliderRow("Shadow", t.shadowDp, 0f..16f, { "${it.roundToInt()} dp" }) { v ->
            edit { it.copy(tile = it.tile.copy(shadowDp = v)) }
        }
    }
    Section("Border / outline") {
        SwitchRow("Outline", t.outline) { v -> edit { it.copy(tile = it.tile.copy(outline = v)) } }
        if (t.outline) {
            SliderRow("Outline width", t.outlineWidthDp, 0.5f..4f, { String.format("%.1f dp", it) }) { v ->
                edit { it.copy(tile = it.tile.copy(outlineWidthDp = v)) }
            }
            ColorRow("Outline color", t.outlineColor) { c -> edit { it.copy(tile = it.tile.copy(outlineColor = c)) } }
        }
    }
}

@Composable
private fun FontsTab(theme: ThemeCfg) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val l = theme.label
    val fontPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) scope.launch {
            if (Store.saveCustomFont(context, uri)) toast(context, "Font added") else toast(context, "That file is not a font")
        }
    }
    Section("App names") {
        SwitchRow("Show app names", l.show) { v -> edit { it.copy(label = it.label.copy(show = v)) } }
    }
    Section("Font", "Want Oswald, Bebas or any other font? Download its .ttf on your phone and use 'Add my own font'.") {
        FontChoice.entries.filter { it != FontChoice.CUSTOM || theme.customFontVersion > 0 }.forEach { f ->
            val family = rememberFont(f, theme.customFontVersion)
            Row(
                Modifier.fillMaxWidth().clickable { edit { it.copy(label = it.label.copy(font = f)) } }
                    .padding(horizontal = 18.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(Fonts.label[f] ?: f.name, color = Color.White, fontSize = 17.sp, fontFamily = family, modifier = Modifier.weight(1f))
                Text("Aa 0941", color = Color(0xFF9A9AA2), fontSize = 15.sp, fontFamily = family)
                if (l.font == f) Text("  ✓", color = MaterialTheme.colorScheme.primary, fontSize = 17.sp)
            }
        }
        ButtonRow("Add my own font (.ttf / .otf)") {
            fontPicker.launch(arrayOf("font/ttf", "font/otf", "font/sfnt", "application/x-font-ttf", "application/x-font-otf", "application/octet-stream"))
        }
    }
    Section("Size & weight") {
        SliderRow("Font size", l.sizeSp, 8f..20f, { String.format("%.1f sp", it) }) { v ->
            edit { it.copy(label = it.label.copy(sizeSp = v)) }
        }
        SliderRow("Font weight", l.weight.toFloat(), 100f..900f, { weightName(it.roundToInt()) }, steps = 7) { v ->
            edit { it.copy(label = it.label.copy(weight = (v / 100f).roundToInt() * 100)) }
        }
        ColorRow("Text color", l.color) { c -> edit { it.copy(label = it.label.copy(color = c)) } }
        SwitchRow("Text shadow", l.shadow, "Makes names readable on bright wallpapers") { v ->
            edit { it.copy(label = it.label.copy(shadow = v)) }
        }
    }
}

private fun weightName(w: Int) = when (w) {
    100 -> "Thin"; 200 -> "Extra light"; 300 -> "Light"; 400 -> "Regular"; 500 -> "Medium"
    600 -> "Semi bold"; 700 -> "Bold"; 800 -> "Extra bold"; else -> "Black"
}

/** Every color in one place. */
@Composable
private fun ColorsTab(theme: ThemeCfg) {
    Section("Main", "All colors of the launcher in one place.") {
        ColorRow("Accent (settings, highlights)", theme.accent) { c -> edit { it.copy(accent = c) } }
        ColorRow("App name text", theme.label.color) { c -> edit { it.copy(label = it.label.copy(color = c)) } }
        ColorRow("Themed icon color", theme.icon.tint) { c -> edit { it.copy(icon = it.icon.copy(tint = c)) } }
    }
    Section("Tiles") {
        ColorRow("Tile color", theme.tile.color) { c -> edit { it.copy(tile = it.tile.copy(color = c)) } }
        GradientRow("Tile gradient", theme.tile.gradient) { g -> edit { it.copy(tile = it.tile.copy(gradient = g)) } }
        ColorRow("Tile outline", theme.tile.outlineColor) { c -> edit { it.copy(tile = it.tile.copy(outlineColor = c)) } }
    }
    Section("Background") {
        ColorRow("Solid background", theme.background.color) { c -> edit { it.copy(background = it.background.copy(color = c)) } }
        GradientRow("Background gradient", theme.background.gradient) { g -> edit { it.copy(background = it.background.copy(gradient = g)) } }
    }
    Section("Badges") {
        ColorRow("Badge color", theme.badge.color) { c -> edit { it.copy(badge = it.badge.copy(color = c)) } }
        ColorRow("Badge number", theme.badge.textColor) { c -> edit { it.copy(badge = it.badge.copy(textColor = c)) } }
        GradientRow("Badge gradient", theme.badge.gradient) { g -> edit { it.copy(badge = it.badge.copy(gradient = g)) } }
    }
    Section("Dock, search & drawer") {
        ColorRow("Dock", theme.dock.color) { c -> edit { it.copy(dock = it.dock.copy(color = c)) } }
        GradientRow("Dock gradient", theme.dock.gradient) { g -> edit { it.copy(dock = it.dock.copy(gradient = g)) } }
        ColorRow("Search bar", theme.search.color) { c -> edit { it.copy(search = it.search.copy(color = c)) } }
        ColorRow("Search text", theme.search.textColor) { c -> edit { it.copy(search = it.search.copy(textColor = c)) } }
        ColorRow("Drawer background", theme.drawer.color) { c -> edit { it.copy(drawer = it.drawer.copy(color = c)) } }
    }
}

@Composable
private fun BadgesTab(theme: ThemeCfg, hasAccess: Boolean) {
    val context = LocalContext.current
    val b = theme.badge
    Section(
        "Notification numbers",
        "The number = messages in that app's notifications. Clearing a notification removes its number.",
    ) {
        ButtonRow(
            "Notification access",
            if (hasAccess) "Allowed ✓" else "Needed for numbers – tap to allow",
        ) { openBadgeAccess(context) }
        if (!hasAccess) {
            Text(
                "If Android says \"Restricted setting\": open Settings → Apps → IV Settings → ⋮ (top right) → " +
                    "\"Allow restricted settings\", then try again. This happens only for apps installed from an APK file.",
                color = Color(0xFFFFC56B), fontSize = 12.5.sp,
                modifier = Modifier.padding(horizontal = 18.dp, vertical = 6.dp),
            )
        }
        ChoiceRow("Style", BadgeStyle.entries, b.style, {
            when (it) { BadgeStyle.NUMBER -> "Number"; BadgeStyle.DOT -> "Dot only"; BadgeStyle.OFF -> "Off" }
        }) { s -> edit { it.copy(badge = it.badge.copy(style = s)) } }
    }
    if (b.style != BadgeStyle.OFF) {
        Section("Look") {
            SwitchRow("Use gradient", b.useGradient) { v -> edit { it.copy(badge = it.badge.copy(useGradient = v)) } }
            if (b.useGradient) GradientRow("Gradient", b.gradient) { g -> edit { it.copy(badge = it.badge.copy(gradient = g)) } }
            else ColorRow("Badge color", b.color) { c -> edit { it.copy(badge = it.badge.copy(color = c)) } }
            ColorRow("Number color", b.textColor) { c -> edit { it.copy(badge = it.badge.copy(textColor = c)) } }
            SliderRow("Size", b.scale, 0.6f..1.6f, { "${(it * 100).roundToInt()}%" }) { v -> edit { it.copy(badge = it.badge.copy(scale = v)) } }
            ChoiceRow("Position", BadgePos.entries, b.position, { if (it == BadgePos.TOP_END) "Top right" else "Top left" }) { p ->
                edit { it.copy(badge = it.badge.copy(position = p)) }
            }
            SwitchRow("Short big numbers", b.compact, "On: 3.4K   Off: 999+") { v -> edit { it.copy(badge = it.badge.copy(compact = v)) } }
            SwitchRow("Outline", b.outline) { v -> edit { it.copy(badge = it.badge.copy(outline = v)) } }
            if (b.outline) ColorRow("Outline color", b.outlineColor) { c -> edit { it.copy(badge = it.badge.copy(outlineColor = c)) } }
            SwitchRow("Pop animation on new message", b.pop) { v -> edit { it.copy(badge = it.badge.copy(pop = v)) } }
        }
        Section("Per app", "Long-press any app → \"Hide badge for this app\".") {}
    }
}

@Composable
private fun DockTab(theme: ThemeCfg) {
    val d = theme.dock
    val s = theme.search
    Section("Dock (4 fixed apps at the bottom)", "Long-press an app → Add to dock / Remove from dock / Move left-right.") {
        SwitchRow("Show dock", d.show) { v -> edit { it.copy(dock = it.dock.copy(show = v)) } }
        ChoiceRow("Fill", FillType.entries, d.fill, { it.name.lowercase().replaceFirstChar { c -> c.uppercase() } }) { f ->
            edit { it.copy(dock = it.dock.copy(fill = f)) }
        }
        SliderRow("Opacity", d.alpha, 0f..1f, { "${(it * 100).roundToInt()}%" }) { v -> edit { it.copy(dock = it.dock.copy(alpha = v)) } }
        SliderRow("Corner roundness", d.cornerDp, 0f..48f, { "${it.roundToInt()} dp" }) { v -> edit { it.copy(dock = it.dock.copy(cornerDp = v)) } }
        SwitchRow("Outline", d.outline) { v -> edit { it.copy(dock = it.dock.copy(outline = v)) } }
        SwitchRow("App names in dock", d.showLabels) { v -> edit { it.copy(dock = it.dock.copy(showLabels = v)) } }
    }
    Section("Search bar & Gemini", "Search opens Google. ✦ opens Gemini. For Gemini Live, add the Gemini widget: Widgets tab → Android widget.") {
        SwitchRow("Show search bar", s.show) { v -> edit { it.copy(search = it.search.copy(show = v)) } }
        SwitchRow("Gemini button", s.showGemini) { v -> edit { it.copy(search = it.search.copy(showGemini = v)) } }
        SwitchRow("Full width", s.wide, "Off = small pill like your screenshot") { v -> edit { it.copy(search = it.search.copy(wide = v)) } }
        SliderRow("Opacity", s.alpha, 0f..1f, { "${(it * 100).roundToInt()}%" }) { v -> edit { it.copy(search = it.search.copy(alpha = v)) } }
        SwitchRow("Outline", s.outline) { v -> edit { it.copy(search = it.search.copy(outline = v)) } }
    }
}

@Composable
private fun DrawerTab(theme: ThemeCfg) {
    val d = theme.drawer
    Section("App drawer (swipe up)", "Uses the same icon style as your home screen.") {
        SliderRow("Columns", d.columns.toFloat(), 3f..7f, { it.roundToInt().toString() }, steps = 3) { v ->
            edit { it.copy(drawer = it.drawer.copy(columns = v.roundToInt())) }
        }
        SwitchRow("Search box", d.showSearch) { v -> edit { it.copy(drawer = it.drawer.copy(showSearch = v)) } }
        SwitchRow("App names", d.showLabels) { v -> edit { it.copy(drawer = it.drawer.copy(showLabels = v)) } }
        ColorRow("Background color", d.color) { c -> edit { it.copy(drawer = it.drawer.copy(color = c)) } }
        SliderRow("Background opacity", d.alpha, 0f..1f, { "${(it * 100).roundToInt()}%" }) { v ->
            edit { it.copy(drawer = it.drawer.copy(alpha = v)) }
        }
        SliderRow("Blur", d.blurDp, 0f..40f, { "${it.roundToInt()} dp" }) { v -> edit { it.copy(drawer = it.drawer.copy(blurDp = v)) } }
        Text(
            "Blur works when Background type is \"Image\" (picture chosen in IV). Android doesn't let launchers read the system wallpaper to blur it.",
            color = Color(0xFF9A9AA2), fontSize = 12.5.sp, modifier = Modifier.padding(horizontal = 18.dp, vertical = 6.dp),
        )
    }
}

@Composable
private fun AnimTab(theme: ThemeCfg) {
    val a = theme.anim
    Section("All animations") {
        SwitchRow("Animations", a.enabled, "Master switch – off makes everything instant") { v -> edit { it.copy(anim = it.anim.copy(enabled = v)) } }
        SliderRow("Speed", a.speed, 0.5f..2f, { String.format("%.1f×", it) }) { v -> edit { it.copy(anim = it.anim.copy(speed = v)) } }
    }
    if (a.enabled) Section("Turn on / off one by one") {
        ChoiceRow("Page swipe effect", PageAnim.entries, a.page, { it.name.lowercase().replaceFirstChar { c -> c.uppercase() } }) { p ->
            edit { it.copy(anim = it.anim.copy(page = p)) }
        }
        SwitchRow("Icon press bounce", a.press) { v -> edit { it.copy(anim = it.anim.copy(press = v)) } }
        SwitchRow("Drawer slide", a.drawer) { v -> edit { it.copy(anim = it.anim.copy(drawer = v)) } }
        SwitchRow("Open-app zoom", a.openApp) { v -> edit { it.copy(anim = it.anim.copy(openApp = v)) } }
        SwitchRow("Badge pop", a.badgePop) { v -> edit { it.copy(anim = it.anim.copy(badgePop = v)) } }
    }
}

@Composable
private fun LayoutTab(theme: ThemeCfg) {
    val l = theme.layout
    Section("Home grid") {
        SliderRow("Columns", l.columns.toFloat(), 3f..6f, { it.roundToInt().toString() }, steps = 2) { v ->
            edit { it.copy(layout = it.layout.copy(columns = v.roundToInt())) }
        }
        SliderRow("Side space", l.sidePaddingDp, 4f..40f, { "${it.roundToInt()} dp" }) { v -> edit { it.copy(layout = it.layout.copy(sidePaddingDp = v)) } }
        SliderRow("Space between rows", l.rowGapDp, 0f..40f, { "${it.roundToInt()} dp" }) { v -> edit { it.copy(layout = it.layout.copy(rowGapDp = v)) } }
        SliderRow("Top space", l.topPaddingDp, 0f..200f, { "${it.roundToInt()} dp" }) { v -> edit { it.copy(layout = it.layout.copy(topPaddingDp = v)) } }
        SwitchRow("Page dots", l.showPageDots) { v -> edit { it.copy(layout = it.layout.copy(showPageDots = v)) } }
    }
    Section("Pages", "Pages are made automatically: when one is full, the next apps go to a new page on the right.") {}
}

@Composable
private fun MoreTab(theme: ThemeCfg, isDefault: Boolean, onSetDefault: () -> Unit) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    Section("Home app") {
        ButtonRow(
            if (isDefault) "IV is your Home app ✓" else "Make IV my Home app",
            "To go back to Pixel Launcher: Settings → Apps → Default apps → Home app",
        ) { onSetDefault() }
    }
    Section("Share your theme") {
        ButtonRow("Copy theme", "Copies your look as text – paste it to a friend") {
            clipboard.setText(AnnotatedString(Store.exportTheme()))
            toast(context, "Theme copied")
        }
        ButtonRow("Paste theme", "Use a theme text you copied") {
            val text = clipboard.getText()?.text.orEmpty()
            toast(context, if (Store.importTheme(text)) "Theme applied" else "Clipboard has no IV theme")
        }
    }
    Section("Reset") {
        ButtonRow("Reset look to Dark preset") { Store.applyPreset(Presets.dark) }
        ButtonRow("Reset home layout", "Puts default apps back on home and dock") {
            AppRepo.resetLayout(); toast(context, "Layout reset")
        }
    }
    Section("Uninstall", "Safe anytime: Android switches back to Pixel Launcher automatically.") {
        ButtonRow("Uninstall IV Launcher") {
            runCatching {
                context.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${context.packageName}")))
            }
        }
    }
    Text(
        "${context.getString(R.string.app_name)} · v1.0 · theme \"${theme.name}\"",
        color = Color(0xFF6E6E76), fontSize = 12.sp,
        modifier = Modifier.padding(20.dp),
    )
}

// ------------------------------------------------------------------ helpers

private fun toast(context: Context, msg: String) = Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()

private fun isDefaultHome(context: Context): Boolean {
    val rm = context.getSystemService(RoleManager::class.java)
    return rm?.isRoleHeld(RoleManager.ROLE_HOME) == true
}

private fun openHomeSettings(context: Context) {
    runCatching { context.startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
        .onFailure { runCatching { context.startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)) } }
}

private fun openBadgeAccess(context: Context) {
    val detail = Intent(Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS)
        .putExtra(Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME, BadgeService.component(context).flattenToString())
    runCatching { context.startActivity(detail) }
        .onFailure { runCatching { context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) } }
}
