package com.iv.launcher.home

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.iv.launcher.badges.BadgeService
import com.iv.launcher.data.AppInfo
import com.iv.launcher.data.AppRepo
import com.iv.launcher.data.LayoutState
import com.iv.launcher.data.PageAnim
import com.iv.launcher.data.Span
import com.iv.launcher.data.Store
import com.iv.launcher.data.ThemeCfg
import com.iv.launcher.drawer.AppDrawer
import com.iv.launcher.data.GestureAction
import com.iv.launcher.data.Weather
import com.iv.launcher.data.WidgetCfg
import com.iv.launcher.helper.IvHelperService
import com.iv.launcher.widgets.WidgetView
import com.iv.launcher.widgets.Widgets
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.runtime.mutableFloatStateOf
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.iv.launcher.settings.SettingsActivity
import com.iv.launcher.ui.ActionMenu
import com.iv.launcher.ui.AppTile
import com.iv.launcher.ui.IvBackground
import com.iv.launcher.ui.IvStatusBar
import com.iv.launcher.ui.LabelText
import com.iv.launcher.ui.MenuAction
import com.iv.launcher.ui.ivPillModifier
import com.iv.launcher.ui.rememberBackgroundBitmap
import com.iv.launcher.ui.rememberFont
import com.iv.launcher.ui.toColor
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.launch
import kotlin.math.abs

/** What a long-press menu is about. */
sealed interface MenuTarget {
    data class HomeApp(val app: AppInfo, val span: Span) : MenuTarget
    data class DockApp(val app: AppInfo) : MenuTarget
    data class DrawerApp(val app: AppInfo) : MenuTarget
    data class Widget(val cfg: WidgetCfg) : MenuTarget
    data object Empty : MenuTarget
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeRoot(homePressed: SharedFlow<Unit>) {
    val context = LocalContext.current
    val theme by Store.theme.collectAsState()
    val layout by Store.layout.collectAsState()
    val apps by AppRepo.apps.collectAsState()
    val badges by BadgeService.counts.collectAsState()
    val appMap = remember(apps) { apps.associateBy { it.key } }
    val bgBitmap = rememberBackgroundBitmap(theme)
    val scope = rememberCoroutineScope()
    var menu by remember { mutableStateOf<MenuTarget?>(null) }
    val features by Store.features.collectAsState()
    var downDrag by remember { mutableFloatStateOf(0f) }
    val swipeDownPx = with(LocalDensity.current) { 70.dp.toPx() }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { scope.launch { Weather.refresh(context) } }

    fun badgeFor(app: AppInfo): Int = if (app.pkg in layout.noBadge) 0 else badges[app.pkg] ?: 0

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val heightPx = constraints.maxHeight.toFloat().coerceAtLeast(1f)
        val drawer = remember { Animatable(heightPx) }   // heightPx = closed, 0 = open
        val animOn = theme.anim.enabled && theme.anim.drawer
        val spec = spring<Float>(dampingRatio = 0.86f, stiffness = Spring.StiffnessMediumLow * theme.anim.speed.coerceIn(0.3f, 3f))

        fun settleDrawer(velocity: Float) {
            val open = if (abs(velocity) > 1200f) velocity < 0 else drawer.value < heightPx * 0.65f
            scope.launch {
                val target = if (open) 0f else heightPx
                if (animOn) drawer.animateTo(target, spec, initialVelocity = velocity) else drawer.snapTo(target)
            }
        }
        fun closeDrawer() { scope.launch { if (animOn) drawer.animateTo(heightPx, spec) else drawer.snapTo(heightPx) } }
        fun openDrawer() { scope.launch { if (animOn) drawer.animateTo(0f, spec) else drawer.snapTo(0f) } }
        fun dragDrawer(dy: Float) { scope.launch { drawer.snapTo((drawer.value + dy).coerceIn(0f, heightPx)) } }

        val drawerOpen by remember(heightPx) { derivedStateOf { drawer.value < heightPx - 1f } }
        val drawerVisible by remember(heightPx) { derivedStateOf { drawer.value < heightPx } }
        var goFirstPage by remember { mutableIntStateOf(0) }

        fun gesture(action: GestureAction) {
            if (!IvHelperService.perform(context, action) { openDrawer() }) {
                toast(context, "Turn on \"IV Helper\" for this gesture (IV Settings → Permissions)")
                IvHelperService.openSettings(context)
            }
        }

        // Screen height changed (first layout, rotation): keep a closed drawer fully closed.
        LaunchedEffect(heightPx) { if (drawer.value != 0f) drawer.snapTo(heightPx) }

        LaunchedEffect(Unit) {
            homePressed.collect {
                menu = null
                if (drawer.value < heightPx - 1f) closeDrawer() else goFirstPage++
            }
        }
        BackHandler(enabled = true) { /* Back on the home screen does nothing (like Pixel). */ }
        BackHandler(enabled = menu != null) { menu = null }
        BackHandler(enabled = menu == null && drawerOpen) { closeDrawer() }

        IvBackground(theme, bgBitmap)

        // ---------- Home ----------
        Column(
            Modifier
                .fillMaxSize()
                .graphicsLayer {
                    val p = 1f - drawer.value / heightPx   // 0 closed → 1 open
                    alpha = 1f - p * 0.9f
                    val s = 1f - p * 0.06f
                    scaleX = s; scaleY = s
                }
                .draggable(
                    orientation = Orientation.Vertical,
                    state = rememberDraggableState { dy ->
                        if (dy < 0 || drawerOpen) dragDrawer(dy) else downDrag += dy
                    },
                    onDragStopped = { v ->
                        if (downDrag > swipeDownPx && !drawerOpen) gesture(features.gestures.swipeDown)
                        downDrag = 0f
                        settleDrawer(v)
                    },
                )
                .systemBarsPadding(),
        ) {
            if (features.statusBar.enabled) {
                val notifApps = remember(badges, apps, layout.noBadge) {
                    badges.filter { it.value > 0 && it.key !in layout.noBadge }.keys
                        .mapNotNull { pkg -> apps.firstOrNull { it.pkg == pkg } }
                }
                IvStatusBar(theme, features.statusBar, notifApps)
            }
            HomePages(
                theme = theme,
                layout = layout,
                appMap = appMap,
                badgeFor = ::badgeFor,
                goFirstPage = goFirstPage,
                onMenu = { menu = it },
                onDoubleTap = { gesture(features.gestures.doubleTap) },
                onSingleTap = { if (features.gestures.singleTap != GestureAction.VOICE || features.voice.enabled) gesture(features.gestures.singleTap) },
                modifier = Modifier.weight(1f),
            )
            if (theme.search.show) {
                SearchRow(
                    theme,
                    showMic = features.voice.enabled && features.voice.micButton,
                    onSearch = { if (!QuickActions.openSearch(context)) openDrawer() },
                    onGemini = { QuickActions.openGemini(context) },
                    onVoice = { com.iv.launcher.voice.VoiceActivity.open(context) },
                )
                Spacer(Modifier.height(12.dp))
            }
            if (theme.dock.show) {
                Dock(theme, layout, appMap, ::badgeFor, onMenu = { menu = it })
            }
            Spacer(Modifier.height(10.dp))
        }

        // ---------- Drawer ----------
        if (drawerVisible) {
            AppDrawer(
                theme = theme,
                apps = apps,
                badgeFor = ::badgeFor,
                bgBitmap = bgBitmap,
                offsetPx = { drawer.value },
                heightPx = heightPx,
                onDrag = { dragDrawer(it) },
                onSettle = { settleDrawer(it) },
                onLaunch = { app, v, r ->
                    AppRepo.launch(context, app, v, r)
                    // Close the drawer behind the opening app, so home is clean when you come back.
                    scope.launch { delay(450); drawer.snapTo(heightPx) }
                },
                onLongPress = { menu = MenuTarget.DrawerApp(it) },
            )
        }

        // ---------- Arc picker (hold bottom-right edge) ----------
        if (features.gestures.arcEnabled && !drawerOpen && menu == null) {
            val favs = remember(layout.favorites, appMap) {
                layout.favorites.mapNotNull { appMap[it] }.ifEmpty { layout.dock.mapNotNull { appMap[it] } }
            }
            ArcPickerLayer(
                theme = theme,
                apps = favs,
                accent = features.gestures.arcAccent.toColor(),
                haptics = features.gestures.arcHaptics,
                onOpen = { AppRepo.launch(context, it, null, null) },
            )
        }

        // ---------- Long-press menu ----------
        val current = menu
        ActionMenu(
            visible = current != null,
            title = when (current) {
                is MenuTarget.HomeApp -> current.app.label
                is MenuTarget.DockApp -> current.app.label
                is MenuTarget.DrawerApp -> current.app.label
                is MenuTarget.Widget -> current.cfg.title.ifBlank { current.cfg.kind.name.lowercase().replaceFirstChar { it.uppercase() } + " widget" }
                MenuTarget.Empty -> "IV Launcher"
                else -> ""
            },
            actions = current?.let { menuActions(context, it, layout, ::openDrawer) { menu = null } } ?: emptyList(),
            accent = theme.accent.toColor(),
            onDismiss = { menu = null },
        )
    }
}

private fun menuActions(
    context: Context,
    target: MenuTarget,
    layout: LayoutState,
    openDrawer: () -> Unit,
    close: () -> Unit,
): List<MenuAction> {
    fun a(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector?, danger: Boolean = false, block: () -> Unit) =
        MenuAction(title, icon, danger = danger) { block(); close() }

    fun common(app: AppInfo) = AppRepo.shortcuts(app).map { sc ->
        MenuAction((sc.shortLabel ?: sc.longLabel ?: "Shortcut").toString(), Icons.Filled.KeyboardArrowRight) {
            AppRepo.startShortcut(context, sc.`package`, sc.id); close()
        }
    } + listOf(
        a(if (app.key in layout.favorites) "Remove from arc picker" else "Add to arc picker", Icons.Filled.Favorite) {
            HomeEdits.toggleFavorite(app.key)
        },
        a(if (app.pkg in layout.noBadge) "Show badge for this app" else "Hide badge for this app", Icons.Filled.Notifications) {
            HomeEdits.toggleBadge(app.pkg)
        },
        a("App info", Icons.Filled.Info) { AppRepo.appInfo(app) },
        a("Uninstall", Icons.Filled.Delete, danger = true) { AppRepo.uninstall(context, app.pkg) },
    )

    return when (target) {
        is MenuTarget.HomeApp -> {
            val app = target.app
            Span.entries.map { s ->
                MenuAction(s.title, chip = true, selected = target.span == s) { HomeEdits.setSpan(app.key, s); close() }
            } + listOf(
                a("Move earlier", Icons.Filled.KeyboardArrowLeft) { HomeEdits.move(app.key, -1) },
                a("Move later", Icons.Filled.KeyboardArrowRight) { HomeEdits.move(app.key, 1) },
                if (app.key in layout.dock) a("Remove from dock", Icons.Filled.Close) { HomeEdits.removeFromDock(app.key) }
                else a("Add to dock", Icons.Filled.Star) {
                    if (!HomeEdits.addToDock(app.key)) toast(context, "Dock is full (4 apps). Remove one first.")
                },
                a("Remove from home", Icons.Filled.Close) { HomeEdits.removeFromHome(app.key) },
            ) + common(app)
        }
        is MenuTarget.DockApp -> {
            val app = target.app
            listOf(
                a("Move left", Icons.Filled.KeyboardArrowLeft) { HomeEdits.moveInDock(app.key, -1) },
                a("Move right", Icons.Filled.KeyboardArrowRight) { HomeEdits.moveInDock(app.key, 1) },
                a("Remove from dock", Icons.Filled.Close) { HomeEdits.removeFromDock(app.key) },
            ) + common(app)
        }
        is MenuTarget.DrawerApp -> {
            val app = target.app
            listOfNotNull(
                if (layout.home.none { it.key == app.key }) a("Add to home screen", Icons.Filled.Add) {
                    HomeEdits.addToHome(app.key); toast(context, "Added to home")
                } else a("Remove from home", Icons.Filled.Close) { HomeEdits.removeFromHome(app.key) },
                if (app.key !in layout.dock) a("Add to dock", Icons.Filled.Star) {
                    if (!HomeEdits.addToDock(app.key)) toast(context, "Dock is full (4 apps). Remove one first.")
                } else null,
            ) + common(app)
        }
        is MenuTarget.Widget -> {
            val w = target.cfg
            Widgets.sizes.map { (cw, ch) ->
                MenuAction("$cw×$ch", chip = true, selected = w.w == cw && w.h == ch) { Widgets.update(w.id) { it.copy(w = cw, h = ch) }; close() }
            } + listOf(
                a("Move earlier", Icons.Filled.KeyboardArrowLeft) { HomeEdits.move("w:${w.id}", -1) },
                a("Move later", Icons.Filled.KeyboardArrowRight) { HomeEdits.move("w:${w.id}", 1) },
                a("Edit widget (IV Settings → Widgets)", Icons.Filled.Edit) {
                    context.startActivity(
                        Intent(context, SettingsActivity::class.java).putExtra("tab", "Widgets").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                },
                a("Remove widget", Icons.Filled.Delete, danger = true) { Widgets.remove(w.id) },
            )
        }
        MenuTarget.Empty -> listOf(
            a("IV Settings (theme & everything)", Icons.Filled.Settings) {
                context.startActivity(Intent(context, SettingsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            },
            a("All features & battery", Icons.Filled.Settings) {
                context.startActivity(
                    Intent(context, SettingsActivity::class.java).putExtra("menu", true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            },
            a("Add apps to home", Icons.Filled.Add) { openDrawer() },
            a("Add widget (clock, weather, music, Gemini…)", Icons.Filled.Add) {
                context.startActivity(
                    Intent(context, SettingsActivity::class.java).putExtra("tab", "Widgets").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            },
            a("Change system wallpaper", Icons.Filled.Home) {
                runCatching {
                    context.startActivity(
                        Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper")
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
            },
        )
    }
}

private fun toast(context: Context, msg: String) = Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun HomePages(
    theme: ThemeCfg,
    layout: LayoutState,
    appMap: Map<String, AppInfo>,
    badgeFor: (AppInfo) -> Int,
    goFirstPage: Int,
    onMenu: (MenuTarget) -> Unit,
    onDoubleTap: () -> Unit,
    onSingleTap: () -> Unit,
    modifier: Modifier,
) {
    val context = LocalContext.current
    val density = LocalDensity.current
    BoxWithConstraints(modifier.fillMaxWidth()) {
        val cfg = theme.layout
        val cols = cfg.columns.coerceIn(3, 6)
        val side = cfg.sidePaddingDp.dp
        val cellW = (maxWidth - side * 2) / cols
        val labelH: Dp = if (theme.label.show) with(density) { (theme.label.sizeSp * 1.45f).sp.toDp() } + 5.dp else 0.dp
        val cellH = theme.icon.sizeDp.dp + labelH + cfg.rowGapDp.dp
        val top = cfg.topPaddingDp.dp
        val dotsH = if (cfg.showPageDots) 18.dp else 0.dp
        val rows = ((maxHeight - top - dotsH) / cellH).toInt().coerceAtLeast(1)

        val widgetMap = remember(layout.widgets) { layout.widgets.associateBy { it.id } }
        val pages = remember(layout.home, appMap, widgetMap, cols, rows) { packPages(layout.home, appMap, widgetMap, cols, rows) }
        val pageCount = pages.size.coerceAtLeast(1)
        val realPager = rememberPagerState { pageCount }
        LaunchedEffect(goFirstPage) { if (goFirstPage > 0) realPager.animateScrollToPage(0) }

        Column(Modifier.fillMaxSize()) {
            HorizontalPager(
                state = realPager,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                beyondViewportPageCount = 1,
            ) { pageIndex ->
                val placed = pages.getOrElse(pageIndex) { emptyList() }
                Box(
                    Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            if (!theme.anim.enabled) return@graphicsLayer
                            val offset = ((realPager.currentPage - pageIndex) + realPager.currentPageOffsetFraction)
                            val o = abs(offset).coerceIn(0f, 1f)
                            when (theme.anim.page) {
                                PageAnim.NONE -> Unit
                                PageAnim.FADE -> alpha = 1f - o
                                PageAnim.SCALE -> {
                                    val s = 1f - o * 0.12f
                                    scaleX = s; scaleY = s; alpha = 1f - o * 0.5f
                                }
                                PageAnim.DEPTH -> {
                                    rotationY = offset * -18f
                                    cameraDistance = 12f * density.density
                                    alpha = 1f - o * 0.4f
                                }
                            }
                        }
                        .pointerInput(Unit) {
                            detectTapGestures(
                                onLongPress = { onMenu(MenuTarget.Empty) },
                                onDoubleTap = { onDoubleTap() },
                                onTap = { onSingleTap() },
                            )
                        },
                ) {
                    placed.forEach { p ->
                        val app = p.app
                        val widget = p.widget
                        if (widget != null) {
                            val gapW = (cellW - theme.icon.sizeDp.dp).coerceAtLeast(0.dp)
                            WidgetView(
                                cfg = widget,
                                theme = theme,
                                appMap = appMap,
                                width = cellW * p.w - gapW,
                                height = cellH * p.h - cfg.rowGapDp.dp,
                                onLongClick = { onMenu(MenuTarget.Widget(widget)) },
                                modifier = Modifier.offset(x = side + cellW * p.col + gapW / 2, y = top + cellH * p.row),
                            )
                        } else if (app != null) {
                            AppTile(
                                app = app,
                                theme = theme,
                                cellWidth = cellW,
                                span = p.item.span,
                                badge = badgeFor(app),
                                onClick = { v, r -> AppRepo.launch(context, app, v, r) },
                                onLongClick = { onMenu(MenuTarget.HomeApp(app, p.item.span)) },
                                modifier = Modifier
                                    .offset(x = side + cellW * p.col, y = top + cellH * p.row)
                                    .width(cellW * p.w),
                            )
                        }
                    }
                    if (placed.isEmpty()) {
                        Text(
                            "Swipe up for all apps.\nLong-press an app there → Add to home screen.",
                            color = theme.label.color.toColor().copy(alpha = 0.7f),
                            fontSize = 14.sp,
                            modifier = Modifier.align(Alignment.Center).padding(32.dp),
                        )
                    }
                }
            }
            if (cfg.showPageDots) {
                Row(
                    Modifier.fillMaxWidth().height(dotsH),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (pageCount > 1) repeat(pageCount) { i ->
                        val selected = realPager.currentPage == i
                        Box(
                            Modifier
                                .padding(horizontal = 3.dp)
                                .size(if (selected) 7.dp else 6.dp)
                                .background(theme.label.color.toColor().copy(alpha = if (selected) 0.95f else 0.35f), CircleShape),
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SearchRow(theme: ThemeCfg, showMic: Boolean, onSearch: () -> Unit, onGemini: () -> Unit, onVoice: () -> Unit) {
    val s = theme.search
    val font = rememberFont(theme.label.font, theme.customFontVersion)
    val pill = ivPillModifier(
        fill = com.iv.launcher.data.FillType.SOLID, color = s.color,
        gradient = com.iv.launcher.data.GradientSpec(), alpha = s.alpha,
        cornerDp = 50f, outline = s.outline, outlineColor = s.outlineColor,
    )
    Row(
        Modifier.fillMaxWidth().padding(horizontal = theme.layout.sidePaddingDp.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Row(
            (if (s.wide) Modifier.weight(1f) else Modifier)
                .height(40.dp)
                .then(pill)
                .clickable { onSearch() }
                .padding(horizontal = 18.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
        ) {
            Icon(Icons.Filled.Search, null, tint = s.textColor.toColor(), modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text(s.text, color = s.textColor.toColor(), fontSize = 15.sp, fontFamily = font, fontWeight = FontWeight.Medium)
        }
        if (showMic) {
            Spacer(Modifier.width(10.dp))
            Box(
                Modifier.size(40.dp).then(pill).clickable { onVoice() },
                contentAlignment = Alignment.Center,
            ) { MicGlyph(s.textColor.toColor()) }
        }
        if (s.showGemini) {
            Spacer(Modifier.width(10.dp))
            Box(
                Modifier.size(40.dp).then(pill).clickable { onGemini() },
                contentAlignment = Alignment.Center,
            ) {
                Text("✦", color = s.textColor.toColor(), fontSize = 18.sp)
            }
        }
    }
}

@Composable
private fun Dock(
    theme: ThemeCfg,
    layout: LayoutState,
    appMap: Map<String, AppInfo>,
    badgeFor: (AppInfo) -> Int,
    onMenu: (MenuTarget) -> Unit,
) {
    val context = LocalContext.current
    val d = theme.dock
    val dockApps = layout.dock.mapNotNull { appMap[it] }.take(4)
    BoxWithConstraints(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = (theme.layout.sidePaddingDp * 0.6f).dp),
    ) {
        val inner = maxWidth - 24.dp
        val cell = inner / 4
        Row(
            Modifier
                .fillMaxWidth()
                .then(ivPillModifier(d.fill, d.color, d.gradient, d.alpha, d.cornerDp, d.outline, d.outlineColor))
                .padding(horizontal = 12.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (dockApps.isEmpty()) {
                LabelText("Long-press an app → Add to dock", theme, Modifier.padding(vertical = 18.dp))
            }
            dockApps.forEach { app ->
                AppTile(
                    app = app,
                    theme = theme,
                    cellWidth = cell,
                    badge = badgeFor(app),
                    showLabel = d.showLabels && theme.label.show,
                    onClick = { v, r -> AppRepo.launch(context, app, v, r) },
                    onLongClick = { onMenu(MenuTarget.DockApp(app)) },
                    modifier = Modifier.width(cell),
                )
            }
        }
    }
}

/** Small microphone drawn in code (no icon font needed). */
@Composable
private fun MicGlyph(c: Color) {
    androidx.compose.foundation.Canvas(Modifier.size(18.dp)) {
        val w = size.width
        val h = size.height
        val stroke = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.8.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round)
        drawRoundRect(
            color = c,
            topLeft = androidx.compose.ui.geometry.Offset(w * 0.36f, 0f),
            size = androidx.compose.ui.geometry.Size(w * 0.28f, h * 0.6f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * 0.14f),
        )
        drawArc(
            color = c, startAngle = 0f, sweepAngle = 180f, useCenter = false,
            topLeft = androidx.compose.ui.geometry.Offset(w * 0.2f, h * 0.2f),
            size = androidx.compose.ui.geometry.Size(w * 0.6f, h * 0.55f), style = stroke,
        )
        drawLine(c, androidx.compose.ui.geometry.Offset(w / 2, h * 0.75f), androidx.compose.ui.geometry.Offset(w / 2, h * 0.95f), strokeWidth = 1.8.dp.toPx())
    }
}
