package com.iv.launcher.drawer

import android.graphics.Bitmap
import android.graphics.Rect
import android.view.View
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.blur
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.iv.launcher.data.AppInfo
import com.iv.launcher.data.ThemeCfg
import com.iv.launcher.ui.AppTile
import com.iv.launcher.ui.rememberFont
import com.iv.launcher.ui.toColor

/**
 * The all-apps drawer. It slides up from the bottom; offsetPx() is 0 when fully open
 * and heightPx when closed. Dragging down while the list is at the top closes it.
 */
@Composable
fun AppDrawer(
    theme: ThemeCfg,
    apps: List<AppInfo>,
    badgeFor: (AppInfo) -> Int,
    bgBitmap: Bitmap?,
    offsetPx: () -> Float,
    heightPx: Float,
    onDrag: (Float) -> Unit,
    onSettle: (Float) -> Unit,
    onLaunch: (AppInfo, View, Rect) -> Unit,
    onLongPress: (AppInfo) -> Unit,
) {
    val d = theme.drawer
    var query by rememberSaveable { mutableStateOf("") }
    val focus = LocalFocusManager.current
    val gridState = rememberLazyGridState()
    val view = LocalView.current

    // Clear the search when the drawer gets closed.
    LaunchedEffect(Unit) {
        snapshotFlow { offsetPx() >= heightPx - 1f }.collect { closed ->
            if (closed) { query = ""; focus.clearFocus(); gridState.scrollToItem(0) }
        }
    }

    val shown = remember(apps, query) {
        val q = query.trim()
        if (q.isEmpty()) apps else apps.filter { it.label.contains(q, ignoreCase = true) || it.pkg.contains(q, true) }
    }

    // Pull-down-to-close when the grid is already at the top.
    val connection = remember(heightPx) {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                // Drawer partly pulled down and user scrolls up again → move the drawer first.
                if (available.y < 0 && offsetPx() > 0f) { onDrag(available.y); return Offset(0f, available.y) }
                return Offset.Zero
            }
            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                if (available.y > 0 && source == NestedScrollSource.Drag) { onDrag(available.y); return Offset(0f, available.y) }
                return Offset.Zero
            }
            override suspend fun onPreFling(available: Velocity): Velocity {
                if (offsetPx() > 0f) { onSettle(available.y); return available }
                return Velocity.Zero
            }
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer {
                translationY = offsetPx()
                alpha = (1f - offsetPx() / heightPx * 0.6f).coerceIn(0f, 1f)
            }
            // Swallow taps on empty parts so they don't reach the home screen underneath.
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {},
    ) {
        // Background: blurred copy of the IV wallpaper (if one is set) + tint.
        if (bgBitmap != null && d.blurDp > 0f) {
            Image(
                bitmap = remember(bgBitmap) { bgBitmap.asImageBitmap() },
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize().blur(d.blurDp.dp, BlurredEdgeTreatment.Rectangle),
            )
        }
        Box(Modifier.fillMaxSize().background(d.color.toColor().copy(alpha = d.alpha)))

        Column(Modifier.fillMaxSize().statusBarsPadding().imePadding()) {
            // Handle + search: dragging here moves the drawer.
            Column(
                Modifier
                    .fillMaxWidth()
                    .draggable(
                        orientation = Orientation.Vertical,
                        state = rememberDraggableState { onDrag(it) },
                        onDragStopped = { onSettle(it) },
                    )
                    .padding(top = 10.dp, bottom = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Box(
                    Modifier
                        .size(width = 38.dp, height = 4.dp)
                        .background(theme.label.color.toColor().copy(alpha = 0.35f), RoundedCornerShape(50)),
                )
                if (d.showSearch) {
                    Spacer(Modifier.height(14.dp))
                    SearchField(
                        value = query,
                        onChange = { query = it },
                        theme = theme,
                        onGo = { shown.firstOrNull()?.let { onLaunch(it, view, Rect()) } },
                    )
                }
            }

            BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
                val cols = d.columns.coerceIn(3, 7)
                val side = 12.dp
                val cell = (maxWidth - side * 2) / cols
                LazyVerticalGrid(
                    columns = GridCells.Fixed(cols),
                    state = gridState,
                    contentPadding = PaddingValues(start = side, end = side, top = 8.dp, bottom = 40.dp),
                    modifier = Modifier.fillMaxSize().nestedScroll(connection).navigationBarsPadding(),
                ) {
                    items(shown, key = { it.key }) { app ->
                        Box(Modifier.padding(vertical = 10.dp), contentAlignment = Alignment.Center) {
                            AppTile(
                                app = app,
                                theme = theme,
                                cellWidth = cell,
                                badge = badgeFor(app),
                                showLabel = d.showLabels && theme.label.show,
                                onClick = { v, r -> onLaunch(app, v, r) },
                                onLongClick = { onLongPress(app) },
                            )
                        }
                    }
                    if (shown.isEmpty()) {
                        item {
                            Text(
                                "No apps found",
                                color = theme.label.color.toColor().copy(alpha = 0.6f),
                                modifier = Modifier.padding(24.dp),
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SearchField(value: String, onChange: (String) -> Unit, theme: ThemeCfg, onGo: () -> Unit) {
    val s = theme.search
    val font = rememberFont(theme.label.font, theme.customFontVersion)
    Row(
        Modifier
            .padding(horizontal = 18.dp)
            .fillMaxWidth()
            .height(46.dp)
            .background(s.color.toColor().copy(alpha = s.alpha.coerceAtLeast(0.35f)), RoundedCornerShape(50))
            .then(if (s.outline) Modifier.border(1.dp, s.outlineColor.toColor(), RoundedCornerShape(50)) else Modifier)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Search, null, tint = s.textColor.toColor().copy(alpha = 0.8f), modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(10.dp))
        Box(Modifier.weight(1f)) {
            if (value.isEmpty()) {
                Text("Search apps", color = s.textColor.toColor().copy(alpha = 0.5f), fontSize = 16.sp, fontFamily = font)
            }
            BasicTextField(
                value = value,
                onValueChange = onChange,
                singleLine = true,
                textStyle = TextStyle(color = s.textColor.toColor(), fontSize = 16.sp, fontFamily = font),
                cursorBrush = SolidColor(theme.accent.toColor()),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { onGo() }),
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}
