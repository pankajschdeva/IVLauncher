package com.iv.launcher.lock

import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.text.format.DateFormat
import android.util.TypedValue
import android.view.SurfaceHolder
import androidx.core.content.res.ResourcesCompat
import com.iv.launcher.R
import com.iv.launcher.data.ClockCfg
import com.iv.launcher.data.ClockStyle
import com.iv.launcher.data.FontChoice
import com.iv.launcher.data.GradientSpec
import com.iv.launcher.data.LockBg
import com.iv.launcher.data.Media
import com.iv.launcher.data.Store
import com.iv.launcher.data.Weather
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/**
 * IV Lock Screen: a live wallpaper that draws your tall clock, date, weather and info on the lock screen.
 * When the phone is unlocked it shows only the background (unless "clock on home too" is on).
 */
class LockWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = LockEngine()

    inner class LockEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private var visible = false
        private var scope: CoroutineScope? = null
        private var bgKey = ""
        private var bg: Bitmap? = null
        private var fgKey = -1L
        private var fg: Bitmap? = null
        private val tick = object : Runnable {
            override fun run() {
                draw()
                val now = System.currentTimeMillis()
                handler.postDelayed(this, 60_000 - now % 60_000 + 50)
            }
        }
        private val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) { handler.postDelayed({ draw() }, 80) }
        }

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            val f = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_ON); addAction(Intent.ACTION_SCREEN_OFF); addAction(Intent.ACTION_USER_PRESENT)
                addAction(Intent.ACTION_BATTERY_CHANGED)
            }
            runCatching { registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED) }
            val s = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
            scope = s
            s.launch {
                combine(Store.features, Store.theme, Weather.now, Media.now) { _, _, _, _ -> Unit }.collect { draw() }
            }
            s.launch { Weather.refresh(this@LockWallpaperService) }
        }

        override fun onVisibilityChanged(v: Boolean) {
            visible = v
            handler.removeCallbacks(tick)
            if (v) tick.run()
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            draw()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visible = false
            handler.removeCallbacks(tick)
            super.onSurfaceDestroyed(holder)
        }

        override fun onDestroy() {
            handler.removeCallbacks(tick)
            runCatching { unregisterReceiver(receiver) }
            scope?.cancel()
            super.onDestroy()
        }

        private fun draw() {
            val holder = surfaceHolder ?: return
            val c = runCatching { holder.lockCanvas() }.getOrNull() ?: return
            try { paint(c) } catch (_: Throwable) { } finally { runCatching { holder.unlockCanvasAndPost(c) } }
        }

        private fun sp(v: Float) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, resources.displayMetrics)
        private fun dp(v: Float) = v * resources.displayMetrics.density

        private fun paint(c: Canvas) {
            val f = Store.features.value.lock
            val theme = Store.theme.value
            val w = c.width.toFloat()
            val h = c.height.toFloat()

            // ---- background
            when (f.bg) {
                LockBg.SOLID -> c.drawColor(f.color.toInt())
                LockBg.GRADIENT -> c.drawRect(0f, 0f, w, h, Paint().apply { shader = gradient(f.gradient, w, h) })
                LockBg.HOME_IMAGE, LockBg.LOCK_IMAGE -> {
                    val key = if (f.bg == LockBg.HOME_IMAGE) "home${theme.background.imageVersion}" else "lock${f.version}"
                    if (key != bgKey) {
                        bgKey = key
                        bg = if (f.bg == LockBg.HOME_IMAGE) Store.loadBackground()
                        else Store.lockImageFile.takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.absolutePath) }
                    }
                    val b = bg
                    if (b != null) drawCover(c, b, w, h) else c.drawColor(Color.rgb(40, 44, 52))
                }
            }
            if (f.dim > 0f) c.drawColor(Color.argb((f.dim * 255).toInt(), 0, 0, 0))

            val km = getSystemService(KeyguardManager::class.java)
            val locked = isPreview || km?.isKeyguardLocked == true
            if (!locked && !f.showClockWhenUnlocked) return

            // ---- clock
            val now = System.currentTimeMillis()
            val clock = f.clock
            val top = dp(f.clockTopDp)
            val info = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = f.infoColor.toInt()
                typeface = typeface(FontChoice.SYSTEM, 500, theme.customFontVersion)
                textSize = sp(clock.dateSizeSp)
                textAlign = Paint.Align.CENTER
            }
            val weather = Weather.now.value
            val date = SimpleDateFormat("EEE d", Locale.getDefault()).format(Date(now))
            val line = buildString {
                if (clock.showDate) append(date)
                if (clock.showWeather && weather != null) append("   ${weather.emoji} ${weather.temp}°")
            }
            if (line.isNotBlank()) c.drawText(line, w / 2, top - dp(10f), info)
            val clockH = drawClock(c, clock, w / 2, top, now, theme.customFontVersion)

            // ---- depth layer (your PNG cut-out goes over the clock)
            if (f.foregroundLayer) {
                val file = Store.lockForegroundFile
                if (file.exists()) {
                    if (fgKey != f.version) { fgKey = f.version; fg = BitmapFactory.decodeFile(file.absolutePath) }
                    fg?.let { drawCover(c, it, w, h) }
                }
            }

            if (!locked) return
            // ---- bottom info (left: battery + music, right: to-dos)
            val small = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = f.infoColor.toInt()
                typeface = typeface(FontChoice.SYSTEM, 400, theme.customFontVersion)
                textSize = sp(14f)
            }
            var yL = max(top + clockH + dp(40f), h - dp(250f))
            val left = dp(32f)
            if (f.showBattery) {
                c.drawText("🔋 ${battery()}%", left, yL, small); yL += dp(24f)
            }
            if (f.showMusic) Media.now.value?.let { m ->
                c.drawText(ellipsize("♪ ${m.title}", small, w / 2 - left - dp(8f)), left, yL, small); yL += dp(20f)
                c.drawText(ellipsize(m.artist, small, w / 2 - left - dp(8f)), left, yL, small.apply { alpha = 170 })
                small.alpha = 255
            }
            var yR = max(top + clockH + dp(40f), h - dp(250f))
            f.todos.take(4).forEach { t ->
                c.drawText(ellipsize("○  $t", small, w / 2 - dp(36f)), w / 2 + dp(4f), yR, small); yR += dp(22f)
            }
        }

        private fun battery(): Int {
            val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return 0
            val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
            val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
            return level * 100 / scale
        }

        private fun ellipsize(s: String, p: Paint, maxW: Float): String {
            if (p.measureText(s) <= maxW) return s
            var t = s
            while (t.length > 1 && p.measureText("$t…") > maxW) t = t.dropLast(1)
            return "$t…"
        }

        private fun drawCover(c: Canvas, b: Bitmap, w: Float, h: Float) {
            val scale = max(w / b.width, h / b.height)
            val bw = b.width * scale
            val bh = b.height * scale
            val dst = RectF((w - bw) / 2, (h - bh) / 2, (w + bw) / 2, (h + bh) / 2)
            c.drawBitmap(b, null, dst, Paint(Paint.FILTER_BITMAP_FLAG))
        }

        private fun gradient(g: GradientSpec, w: Float, h: Float): Shader {
            val rad = Math.toRadians(g.angle.toDouble())
            val dx = cos(rad).toFloat(); val dy = sin(rad).toFloat()
            val half = (kotlin.math.abs(dx) * w + kotlin.math.abs(dy) * h) / 2
            val cols = g.colors.ifEmpty { listOf(0xFF000000) }.map { it.toInt() }.let { if (it.size == 1) it + it else it }.toIntArray()
            return LinearGradient(w / 2 - dx * half, h / 2 - dy * half, w / 2 + dx * half, h / 2 + dy * half, cols, null, Shader.TileMode.CLAMP)
        }

        private val fontCache = HashMap<Triple<FontChoice, Int, Long>, Typeface>()

        private fun typeface(choice: FontChoice, weight: Int, customVersion: Long): Typeface {
            val key = Triple(choice, weight, customVersion)
            fontCache[key]?.let { return it }
            val ctx = this@LockWallpaperService
            val base: Typeface = runCatching {
                when (choice) {
                    FontChoice.SYSTEM -> Typeface.DEFAULT
                    FontChoice.POPPINS -> ResourcesCompat.getFont(ctx, R.font.poppins_regular)
                    FontChoice.INTER -> ResourcesCompat.getFont(ctx, R.font.inter_regular)
                    FontChoice.LORA -> ResourcesCompat.getFont(ctx, R.font.lora)
                    FontChoice.CONDENSED -> Typeface.create("sans-serif-condensed", Typeface.NORMAL)
                    FontChoice.SERIF -> Typeface.SERIF
                    FontChoice.MONO -> Typeface.MONOSPACE
                    FontChoice.CUSTOM -> if (Store.customFontFile.exists()) Typeface.createFromFile(Store.customFontFile) else Typeface.DEFAULT
                }
            }.getOrNull() ?: Typeface.DEFAULT
            val tf = Typeface.create(base, weight.coerceIn(100, 900), false)
            fontCache[key] = tf
            return tf
        }

        /** Draws the clock centred at cx, starting at y=top. Returns its height. */
        private fun drawClock(c: Canvas, cfg: ClockCfg, cx: Float, top: Float, now: Long, customVersion: Long): Float {
            val is24 = cfg.use24h || DateFormat.is24HourFormat(this@LockWallpaperService)
            val d = Date(now)
            val hh = SimpleDateFormat(if (is24) "HH" else "hh", Locale.getDefault()).format(d)
            val mm = SimpleDateFormat("mm", Locale.getDefault()).format(d)
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                typeface = typeface(cfg.font, cfg.weight, customVersion)
                textSize = sp(cfg.sizeSp)
                color = cfg.color.toInt()
                letterSpacing = cfg.letterSpacing
            }

            fun drawLine(text: String, x: Float, y: Float, size: Float, align: Paint.Align, alphaMul: Float = 1f): Float {
                p.textSize = size
                p.textAlign = align
                val r = Rect()
                p.getTextBounds(text, 0, text.length, r)
                c.save()
                c.translate(x, y)
                c.scale(cfg.widthScale, cfg.heightScale)
                val baseY = -r.top.toFloat()
                when (cfg.style) {
                    ClockStyle.OUTLINE -> {
                        p.style = Paint.Style.STROKE; p.strokeWidth = dp(cfg.outlineDp)
                        c.drawText(text, 0f, baseY, p)
                    }
                    ClockStyle.GRADIENT -> {
                        val cols = cfg.gradient.colors.map { it.toInt() }.let { if (it.size == 1) it + it else it }.toIntArray()
                        p.shader = LinearGradient(0f, 0f, 0f, r.height().toFloat(), cols, null, Shader.TileMode.CLAMP)
                        c.drawText(text, 0f, baseY, p)
                        p.shader = null
                    }
                    ClockStyle.GLASS -> {
                        p.style = Paint.Style.FILL
                        val base = p.color
                        p.color = Color.argb(80, Color.red(base), Color.green(base), Color.blue(base))
                        c.drawText(text, 0f, baseY, p)
                        p.style = Paint.Style.STROKE; p.strokeWidth = dp(cfg.outlineDp * 0.8f); p.color = Color.argb(200, 255, 255, 255)
                        c.drawText(text, 0f, baseY, p)
                        p.color = base
                    }
                    else -> {
                        p.style = Paint.Style.FILL
                        val base = p.color
                        if (alphaMul < 1f) p.alpha = (Color.alpha(base) * alphaMul).toInt()
                        c.drawText(text, 0f, baseY, p)
                        p.color = base
                    }
                }
                p.style = Paint.Style.FILL
                c.restore()
                return r.height() * cfg.heightScale
            }

            val size = sp(cfg.sizeSp)
            return when (cfg.style) {
                ClockStyle.STACKED -> {
                    val h1 = drawLine(hh, cx, top, size, Paint.Align.CENTER)
                    val gap = dp(10f)
                    h1 + gap + drawLine(mm, cx, top + h1 + gap, size, Paint.Align.CENTER)
                }
                ClockStyle.SPLIT -> {
                    val h1 = drawLine(hh, cx - dp(4f), top, size, Paint.Align.RIGHT)
                    val small = size * 0.5f
                    p.textSize = small
                    val r = Rect(); p.getTextBounds(mm, 0, mm.length, r)
                    drawLine(mm, cx + dp(4f), top + h1 - r.height() * cfg.heightScale, small, Paint.Align.LEFT, 0.6f)
                    h1
                }
                ClockStyle.MINIMAL -> drawLine("$hh:$mm", cx, top, size * 0.42f, Paint.Align.CENTER)
                else -> drawLine("$hh:$mm", cx, top, size, Paint.Align.CENTER)
            }
        }
    }
}
