package com.iv.launcher.data

import kotlinx.serialization.Serializable

/*
 * Everything the user can customise lives in ThemeCfg (the look) and LayoutState (what is where).
 * Both are stored as JSON, so new options can be added later without breaking old saves.
 * Colours are ARGB stored as Long (e.g. 0xFFFFFFFF).
 */

@Serializable enum class IconStyle { ORIGINAL, MONO, THEMED }
@Serializable enum class FillType { NONE, SOLID, GRADIENT, GLASS, PLUSH }
@Serializable enum class BgType { SYSTEM, SOLID, GRADIENT, IMAGE }
@Serializable enum class BadgeStyle { NUMBER, DOT, OFF }
@Serializable enum class BadgePos { TOP_END, TOP_START }
@Serializable enum class PageAnim { NONE, FADE, SCALE, DEPTH }
@Serializable enum class FontChoice { SYSTEM, POPPINS, INTER, LORA, CONDENSED, SERIF, MONO, CUSTOM }

@Serializable
data class GradientSpec(
    val colors: List<Long> = listOf(0xFF3A3A40, 0xFF0E0E10),
    val angle: Float = 135f,
)

@Serializable
data class BackgroundCfg(
    val type: BgType = BgType.SYSTEM,
    val color: Long = 0xFF000000,
    val gradient: GradientSpec = GradientSpec(listOf(0xFF1B1B22, 0xFF000000), 180f),
    val blurDp: Float = 0f,        // blur of the chosen image (0..40)
    val dim: Float = 0f,           // dark overlay on top of the background (0..0.85)
    val imageVersion: Long = 0L,   // bumps when a new image is chosen
)

@Serializable
data class TileCfg(
    val fill: FillType = FillType.SOLID,
    val color: Long = 0xFF1C1C1E,
    val gradient: GradientSpec = GradientSpec(),
    val alpha: Float = 1f,
    val cornerPercent: Int = 26,   // 0 = square, 50 = circle
    val outline: Boolean = true,
    val outlineWidthDp: Float = 1f,
    val outlineColor: Long = 0x33FFFFFF,
    val shadowDp: Float = 0f,
)

@Serializable
data class IconCfg(
    val style: IconStyle = IconStyle.MONO,
    val tint: Long = 0xFFF2F2F2,   // used by THEMED
    val sizeDp: Int = 62,          // tile size of a small icon
    val glyphScale: Float = 0.62f, // icon size inside the tile
    val showTile: Boolean = true,
)

@Serializable
data class LabelCfg(
    val show: Boolean = true,
    val font: FontChoice = FontChoice.SYSTEM,
    val sizeSp: Float = 12f,
    val weight: Int = 500,
    val color: Long = 0xFFFFFFFF,
    val shadow: Boolean = true,
)

@Serializable
data class BadgeCfg(
    val style: BadgeStyle = BadgeStyle.NUMBER,
    val color: Long = 0xFFF2F2F2,
    val useGradient: Boolean = false,
    val gradient: GradientSpec = GradientSpec(listOf(0xFFFF5F6D, 0xFFFFC371), 0f),
    val textColor: Long = 0xFF111111,
    val scale: Float = 1f,
    val position: BadgePos = BadgePos.TOP_END,
    val compact: Boolean = false,   // true: 3.4K, false: 999+
    val outline: Boolean = false,
    val outlineColor: Long = 0xFF000000,
    val pop: Boolean = true,
)

@Serializable
data class DockCfg(
    val show: Boolean = true,
    val fill: FillType = FillType.GLASS,
    val color: Long = 0xFF1C1C1E,
    val gradient: GradientSpec = GradientSpec(),
    val alpha: Float = 0.55f,
    val cornerDp: Float = 36f,
    val outline: Boolean = true,
    val outlineColor: Long = 0x22FFFFFF,
    val showLabels: Boolean = false,
)

@Serializable
data class SearchCfg(
    val show: Boolean = true,
    val showGemini: Boolean = true,
    val text: String = "Search",
    val color: Long = 0xFF1C1C1E,
    val alpha: Float = 0.7f,
    val textColor: Long = 0xFFEDEDED,
    val outline: Boolean = true,
    val outlineColor: Long = 0x33FFFFFF,
    val wide: Boolean = false,      // false: small pill like iOS, true: full width bar
)

@Serializable
data class DrawerCfg(
    val color: Long = 0xFF000000,
    val alpha: Float = 0.82f,
    val blurDp: Float = 18f,        // works when background is an image chosen in IV
    val columns: Int = 4,
    val showSearch: Boolean = true,
    val showLabels: Boolean = true,
)

@Serializable
data class AnimCfg(
    val enabled: Boolean = true,
    val page: PageAnim = PageAnim.SCALE,
    val press: Boolean = true,
    val drawer: Boolean = true,
    val badgePop: Boolean = true,
    val openApp: Boolean = true,
    val speed: Float = 1f,          // 0.5 = slow, 2 = fast
)

@Serializable
data class LayoutCfg(
    val columns: Int = 4,
    val sidePaddingDp: Float = 20f,
    val rowGapDp: Float = 12f,
    val showPageDots: Boolean = true,
    val topPaddingDp: Float = 24f,
)

@Serializable
data class ThemeCfg(
    val name: String = "Dark",
    val accent: Long = 0xFFB9A7FF,
    val darkStatusIcons: Boolean = false,   // true for light themes
    val background: BackgroundCfg = BackgroundCfg(),
    val tile: TileCfg = TileCfg(),
    val icon: IconCfg = IconCfg(),
    val label: LabelCfg = LabelCfg(),
    val badge: BadgeCfg = BadgeCfg(),
    val dock: DockCfg = DockCfg(),
    val search: SearchCfg = SearchCfg(),
    val drawer: DrawerCfg = DrawerCfg(),
    val anim: AnimCfg = AnimCfg(),
    val layout: LayoutCfg = LayoutCfg(),
    val customFontVersion: Long = 0L,
)

/** Size of an item on the home grid, in cells. */
@Serializable
enum class Span(val w: Int, val h: Int, val title: String) {
    S(1, 1, "Small"),
    W(2, 1, "Wide 2×1"),
    B(2, 2, "Big 2×2"),
}

@Serializable
data class HomeItem(val key: String, val span: Span = Span.S)

@Serializable
data class LayoutState(
    val initialized: Boolean = false,
    val home: List<HomeItem> = emptyList(),
    val dock: List<String> = emptyList(),
    val noBadge: Set<String> = emptySet(),   // package names with badges turned off
    val widgets: List<WidgetCfg> = emptyList(),   // home items with key "w:<id>"
    val favorites: List<String> = emptyList(),    // apps in the arc picker
)
