package com.iv.launcher.data

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import java.io.File

/** Single place that holds and saves the theme + layout. Shared by home and settings (same process). */
object Store {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true; coerceInputValues = true }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var prefs: SharedPreferences
    private lateinit var filesDir: File

    private val _theme = MutableStateFlow(ThemeCfg())
    val theme: StateFlow<ThemeCfg> = _theme

    private val _layout = MutableStateFlow(LayoutState())
    val layout: StateFlow<LayoutState> = _layout

    private val _features = MutableStateFlow(FeatureCfg())
    val features: StateFlow<FeatureCfg> = _features

    val backgroundFile: File get() = File(filesDir, "background.jpg")
    val customFontFile: File get() = File(filesDir, "custom_font.ttf")

    @OptIn(FlowPreview::class)
    fun init(context: Context) {
        prefs = context.getSharedPreferences("iv_launcher", Context.MODE_PRIVATE)
        filesDir = context.filesDir
        _theme.value = runCatching {
            prefs.getString("theme", null)?.let { json.decodeFromString(ThemeCfg.serializer(), it) }
        }.getOrNull() ?: ThemeCfg()
        _layout.value = runCatching {
            prefs.getString("layout", null)?.let { json.decodeFromString(LayoutState.serializer(), it) }
        }.getOrNull() ?: LayoutState()
        _features.value = runCatching {
            prefs.getString("features", null)?.let { json.decodeFromString(FeatureCfg.serializer(), it) }
        }.getOrNull() ?: FeatureCfg()

        // Save shortly after the last change (sliders send many changes per second).
        _theme.drop(1).debounce(300).onEach {
            prefs.edit().putString("theme", json.encodeToString(ThemeCfg.serializer(), it)).apply()
        }.launchIn(scope)
        _layout.drop(1).debounce(300).onEach {
            prefs.edit().putString("layout", json.encodeToString(LayoutState.serializer(), it)).apply()
        }.launchIn(scope)
        _features.drop(1).debounce(300).onEach {
            prefs.edit().putString("features", json.encodeToString(FeatureCfg.serializer(), it)).apply()
        }.launchIn(scope)
    }

    fun editFeatures(block: (FeatureCfg) -> FeatureCfg) = _features.update(block)

    fun file(name: String): File = File(filesDir, name)
    val lockImageFile: File get() = File(filesDir, "lock.jpg")
    val lockForegroundFile: File get() = File(filesDir, "lock_fg.png")
    val stickerDir: File get() = File(filesDir, "stickers").apply { mkdirs() }

    /** Saves a picture (downscaled). PNG keeps transparency (for the depth cut-out). */
    suspend fun saveImage(context: Context, uri: Uri, target: File, png: Boolean = false, max: Int = 2400): Boolean =
        withContext(Dispatchers.IO) {
            runCatching {
                val src = ImageDecoder.createSource(context.contentResolver, uri)
                val bmp = ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
                    val w = info.size.width
                    val h = info.size.height
                    val scale = minOf(1f, max.toFloat() / maxOf(w, h))
                    decoder.setTargetSize((w * scale).toInt().coerceAtLeast(1), (h * scale).toInt().coerceAtLeast(1))
                    decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                }
                target.outputStream().use {
                    bmp.compress(if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, 92, it)
                }
                true
            }.getOrDefault(false)
        }

    /** Copies a sticker as-is (keeps GIF / WebP animation). Returns the file name. */
    suspend fun saveSticker(context: Context, uri: Uri): String? = withContext(Dispatchers.IO) {
        runCatching {
            val name = "s_${System.currentTimeMillis()}"
            context.contentResolver.openInputStream(uri)!!.use { input ->
                File(stickerDir, name).outputStream().use { input.copyTo(it) }
            }
            name
        }.getOrNull()
    }

    fun editTheme(block: (ThemeCfg) -> ThemeCfg) = _theme.update(block)
    fun editLayout(block: (LayoutState) -> LayoutState) = _layout.update(block)

    fun applyPreset(preset: ThemeCfg) = _theme.update { old ->
        // Keep things that belong to the user rather than the look.
        preset.copy(
            background = if (preset.background.type == BgType.SYSTEM && old.background.type == BgType.IMAGE)
                old.background else preset.background,
            layout = old.layout,
            customFontVersion = old.customFontVersion,
            label = if (old.label.font == FontChoice.CUSTOM) preset.label.copy(font = FontChoice.CUSTOM) else preset.label,
        )
    }

    fun exportTheme(): String = json.encodeToString(ThemeCfg.serializer(), _theme.value)

    /** Returns false if the text is not a valid IV theme. */
    fun importTheme(text: String): Boolean = runCatching {
        val t = json.decodeFromString(ThemeCfg.serializer(), text.trim())
        _theme.value = t.copy(customFontVersion = _theme.value.customFontVersion)
    }.isSuccess

    /** Copies the picked picture into the app (downscaled) so it never disappears. */
    suspend fun saveBackground(context: Context, uri: Uri): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val src = ImageDecoder.createSource(context.contentResolver, uri)
            val bmp = ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
                val max = 2400
                val w = info.size.width
                val h = info.size.height
                val scale = minOf(1f, max.toFloat() / maxOf(w, h))
                decoder.setTargetSize((w * scale).toInt().coerceAtLeast(1), (h * scale).toInt().coerceAtLeast(1))
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            }
            backgroundFile.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            editTheme {
                it.copy(background = it.background.copy(type = BgType.IMAGE, imageVersion = System.currentTimeMillis()))
            }
            true
        }.getOrDefault(false)
    }

    fun loadBackground(): Bitmap? =
        if (backgroundFile.exists()) BitmapFactory.decodeFile(backgroundFile.absolutePath) else null

    suspend fun saveCustomFont(context: Context, uri: Uri): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            context.contentResolver.openInputStream(uri)!!.use { input ->
                customFontFile.outputStream().use { input.copyTo(it) }
            }
            // Check it is a real font before switching to it.
            android.graphics.Typeface.createFromFile(customFontFile)
            editTheme {
                it.copy(
                    customFontVersion = System.currentTimeMillis(),
                    label = it.label.copy(font = FontChoice.CUSTOM),
                )
            }
            true
        }.getOrDefault(false)
    }
}
