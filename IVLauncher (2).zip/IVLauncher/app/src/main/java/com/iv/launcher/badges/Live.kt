package com.iv.launcher.badges

import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.service.notification.StatusBarNotification
import androidx.core.os.BundleCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class LiveAction(val title: String, val intent: PendingIntent)

/** An ongoing thing shown in the top pill (call, recording, timer, any ongoing notification). */
data class LiveItem(
    val key: String,
    val pkg: String,
    val title: String,
    val text: String,
    val smallIcon: Bitmap?,
    val largeIcon: Bitmap?,
    val chronoBase: Long?,          // wall-clock ms the timer counts from (or to, if countDown)
    val countDown: Boolean,
    val actions: List<LiveAction>,
    val content: PendingIntent?,
    val isCall: Boolean,
)

/** A ringing call (from the phone app's call notification, or WhatsApp etc.). */
data class RingingCall(
    val key: String,
    val pkg: String,
    val name: String,
    val photo: Bitmap?,
    val answer: PendingIntent?,
    val decline: PendingIntent?,
)

object Live {
    val items = MutableStateFlow<List<LiveItem>>(emptyList())
    val ringing = MutableStateFlow<RingingCall?>(null)

    /** Phone number of the current call (needs Phone + Call log permission). */
    val number = MutableStateFlow<String?>(null)
    /** true while an outgoing call is active. */
    val outgoing = MutableStateFlow(false)
    val callStartedAt = MutableStateFlow(0L)
    val outgoingDismissed = MutableStateFlow(false)
    /** true while the SIM call is ringing (from the phone state, works even without notification access). */
    val phoneRinging = MutableStateFlow(false)

    private val iconCache = HashMap<String, Bitmap?>()

    fun parse(context: Context, active: Array<StatusBarNotification>) {
        val list = ArrayList<LiveItem>()
        var ring: RingingCall? = null
        for (sbn in active) {
            if (sbn.packageName == context.packageName) continue
            val n = sbn.notification
            val ex = n.extras ?: Bundle()
            val isCall = n.category == Notification.CATEGORY_CALL
            val answer = pi(ex, Notification.EXTRA_ANSWER_INTENT)
            val decline = pi(ex, Notification.EXTRA_DECLINE_INTENT)
            val hangUp = pi(ex, Notification.EXTRA_HANG_UP_INTENT)
            val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
            val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
            val ongoing = (n.flags and Notification.FLAG_ONGOING_EVENT) != 0 ||
                (n.flags and Notification.FLAG_FOREGROUND_SERVICE) != 0

            // A call that is ringing: answer + decline buttons exist.
            val actionTitles = n.actions?.map { it.title?.toString()?.lowercase().orEmpty() }.orEmpty()
            val looksRinging = isCall && (answer != null || actionTitles.any { it.contains("answer") })
            if (looksRinging && hangUp == null) {
                ring = RingingCall(
                    key = sbn.key,
                    pkg = sbn.packageName,
                    name = title.ifBlank { "Unknown" },
                    photo = drawableBitmap(context, n.getLargeIcon()?.loadDrawable(context), 256),
                    answer = answer ?: n.actions?.firstOrNull { it.title?.toString()?.lowercase()?.contains("answer") == true }?.actionIntent,
                    decline = decline ?: n.actions?.firstOrNull {
                        val t = it.title?.toString()?.lowercase().orEmpty(); t.contains("decline") || t.contains("reject")
                    }?.actionIntent,
                )
                continue
            }
            if (!ongoing && !isCall) continue
            val chrono = ex.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER) || isCall
            val actions = buildList {
                if (hangUp != null) add(LiveAction("End", hangUp))
                n.actions?.forEach { a -> if (a.actionIntent != null && a.actionIntent != hangUp) add(LiveAction(a.title?.toString().orEmpty(), a.actionIntent)) }
            }.take(4)
            list += LiveItem(
                key = sbn.key,
                pkg = sbn.packageName,
                title = title,
                text = text,
                smallIcon = iconCache.getOrPut(sbn.packageName + "#" + (n.smallIcon?.let { ic -> runCatching { ic.resId }.getOrDefault(0) } ?: 0)) {
                    drawableBitmap(context, n.smallIcon?.loadDrawable(context), 64)
                },
                largeIcon = drawableBitmap(context, n.getLargeIcon()?.loadDrawable(context), 96),
                chronoBase = if (chrono && n.`when` > 0) n.`when` else null,
                countDown = ex.getBoolean(Notification.EXTRA_CHRONOMETER_COUNT_DOWN),
                actions = actions,
                content = n.contentIntent,
                isCall = isCall,
            )
        }
        items.value = list
        ringing.value = ring
    }

    private fun pi(ex: Bundle, key: String): PendingIntent? =
        runCatching { BundleCompat.getParcelable(ex, key, PendingIntent::class.java) }.getOrNull()

    fun drawableBitmap(context: Context, d: Drawable?, size: Int): Bitmap? {
        d ?: return null
        return runCatching {
            val b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            d.setBounds(0, 0, size, size)
            d.draw(Canvas(b))
            b
        }.getOrNull()
    }

    fun clear() {
        items.value = emptyList()
        ringing.value = null
    }

    val ringingFlow: StateFlow<RingingCall?> get() = ringing
}
