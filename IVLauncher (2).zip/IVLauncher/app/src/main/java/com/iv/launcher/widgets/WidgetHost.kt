package com.iv.launcher.widgets

import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.content.Context
import android.os.Bundle
import android.util.SizeF
import com.iv.launcher.data.FillType
import com.iv.launcher.data.HomeItem
import com.iv.launcher.data.Store
import com.iv.launcher.data.WidgetCfg
import com.iv.launcher.data.WidgetKind

/** Hosts real Android widgets (Gemini, Google search, Spotify, …) inside IV. */
object WidgetHost {
    private const val HOST_ID = 4711
    private lateinit var appContext: Context
    val host: AppWidgetHost by lazy { AppWidgetHost(appContext, HOST_ID) }
    val manager: AppWidgetManager by lazy { AppWidgetManager.getInstance(appContext) }
    private val views = HashMap<Int, AppWidgetHostView>()

    fun init(context: Context) { appContext = context.applicationContext }

    fun start() = runCatching { host.startListening() }
    fun stop() = runCatching { host.stopListening() }

    fun view(context: Context, id: Int): AppWidgetHostView? {
        views[id]?.let { v ->
            (v.parent as? android.view.ViewGroup)?.removeView(v)
            return v
        }
        val info = manager.getAppWidgetInfo(id) ?: return null
        return host.createView(context.applicationContext, id, info).also { views[id] = it }
    }

    fun setSize(view: AppWidgetHostView, wDp: Float, hDp: Float) {
        runCatching { view.updateAppWidgetSize(Bundle(), listOf(SizeF(wDp, hDp))) }
    }

    fun delete(id: Int) {
        views.remove(id)
        runCatching { host.deleteAppWidgetId(id) }
    }
}

object Widgets {
    fun newId() = System.currentTimeMillis().toString(36)

    fun add(cfg: WidgetCfg) = Store.editLayout { l ->
        // New widgets go on the first page, at the top.
        l.copy(widgets = l.widgets + cfg, home = listOf(HomeItem("w:${cfg.id}")) + l.home)
    }

    fun update(id: String, block: (WidgetCfg) -> WidgetCfg) = Store.editLayout { l ->
        l.copy(widgets = l.widgets.map { if (it.id == id) block(it) else it })
    }

    fun remove(id: String) {
        val w = Store.layout.value.widgets.firstOrNull { it.id == id }
        if (w?.kind == WidgetKind.SYSTEM && w.appWidgetId >= 0) WidgetHost.delete(w.appWidgetId)
        Store.editLayout { l -> l.copy(widgets = l.widgets.filterNot { it.id == id }, home = l.home.filterNot { it.key == "w:$id" }) }
    }

    fun preset(kind: WidgetKind): WidgetCfg = when (kind) {
        WidgetKind.CLOCK -> WidgetCfg(newId(), kind, 4, 2, fill = FillType.NONE)
        WidgetKind.WEATHER -> WidgetCfg(newId(), kind, 2, 2)
        WidgetKind.CALENDAR -> WidgetCfg(newId(), kind, 4, 2)
        WidgetKind.MUSIC -> WidgetCfg(newId(), kind, 2, 2)
        WidgetKind.CUSTOM -> WidgetCfg(newId(), kind, 2, 2, emoji = "✨", title = "My widget")
        WidgetKind.SYSTEM -> WidgetCfg(newId(), kind, 4, 1, fill = FillType.NONE)
        WidgetKind.SHORTCUT -> WidgetCfg(newId(), kind, 1, 1, fill = FillType.NONE)
    }

    fun systemLabel(context: Context, id: Int): String? =
        WidgetHost.manager.getAppWidgetInfo(id)?.loadLabel(context.packageManager)

    val sizes = listOf(1 to 1, 2 to 1, 2 to 2, 4 to 1, 4 to 2, 4 to 3, 4 to 4)
}
