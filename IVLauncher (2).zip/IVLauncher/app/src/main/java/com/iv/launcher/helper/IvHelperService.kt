package com.iv.launcher.helper

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.provider.Settings
import android.telephony.PhoneStateListener
import android.telephony.TelephonyManager
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityManager
import android.accessibilityservice.AccessibilityServiceInfo
import androidx.compose.runtime.getValue
import com.iv.launcher.badges.Live
import com.iv.launcher.data.GestureAction
import com.iv.launcher.data.Media
import com.iv.launcher.data.Store
import com.iv.launcher.home.QuickActions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * "IV Helper": an accessibility service that powers the things a normal launcher can't do:
 * lock screen on double-tap, open notifications, the top pill, camera decor and the call screen.
 * It reads no screen content (canRetrieveWindowContent = false).
 */
class IvHelperService : AccessibilityService() {

    private var scope: CoroutineScope? = null
    private var pill: OverlayWindow? = null
    private var decor: OverlayWindow? = null
    private var call: OverlayWindow? = null
    private val landscape = MutableStateFlow(false)
    private val callMode = MutableStateFlow(CallMode.NONE)
    private var phoneListener: PhoneStateListener? = null

    override fun onServiceConnected() {
        instance = this
        running.value = true
        landscape.value = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val s = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
        scope = s
        setupPill(s)
        setupDecor(s)
        setupCall(s)
        listenPhone()
    }

    // ------------------------------------------------------------ top pill
    private fun setupPill(s: CoroutineScope) {
        val w = OverlayWindow(this, touchable = true, fullScreen = false) {
            PillContent(onOpenApp = {})
        }
        pill = w
        s.launch {
            combine(Store.features, Live.items, Media.now) { f, items, media -> PillState.compute(f.pill, items, media) }
                .collect { entries ->
                    PillState.entries.value = entries
                    val show = entries.isNotEmpty() && callMode.value == CallMode.NONE
                    if (show) { positionAtCamera(w, 0); w.show() } else w.hide()
                }
        }
    }

    // ------------------------------------------------------------ camera decor
    private fun setupDecor(s: CoroutineScope) {
        val cut = cameraCutout(this)
        val diameter = cut?.let { minOf(it.width(), it.height()).toFloat() } ?: (28 * resources.displayMetrics.density)
        val w = OverlayWindow(this, touchable = false, fullScreen = false) { DecorContent(diameter) }
        decor = w
        s.launch {
            combine(Store.features.map { it.decor.enabled to it.decor.hideLandscape }.distinctUntilChanged(), landscape) { (on, hideL), land ->
                on && !(hideL && land)
            }.collect { show ->
                if (show) {
                    val dp = resources.displayMetrics.density
                    positionAtCamera(w, (DECOR_H.value * dp / 2).toInt())
                    w.show()
                } else w.hide()
            }
        }
    }

    /** Centres a window on the camera hole. yHalf = half of the window height (0 = top aligned with hole centre). */
    private fun positionAtCamera(w: OverlayWindow, yHalf: Int) {
        val cut = cameraCutout(this)
        val sw = screenWidth(this)
        if (cut != null) {
            w.params.x = cut.centerX() - sw / 2
            w.params.y = if (yHalf > 0) cut.centerY() - yHalf else (cut.centerY() - (Store.features.value.pill.heightDp * resources.displayMetrics.density / 2)).toInt()
        } else {
            w.params.x = 0
            w.params.y = (8 * resources.displayMetrics.density).toInt()
        }
        w.relayout()
    }

    // ------------------------------------------------------------ call screen
    private fun setupCall(s: CoroutineScope) {
        val w = OverlayWindow(this, touchable = true, fullScreen = true) {
            val mode by androidx.compose.runtime.produceState(CallMode.NONE) { callMode.collect { value = it } }
            if (mode != CallMode.NONE) CallContent(mode)
        }
        call = w
        s.launch {
            combine(Store.features, Live.ringing, Live.outgoing, Live.outgoingDismissed) { f, ring, out, dismissed ->
                when {
                    f.call.incoming && ring != null -> CallMode.INCOMING
                    f.call.outgoing && out && !dismissed -> CallMode.OUTGOING
                    else -> CallMode.NONE
                }
            }.distinctUntilChanged().collect { m ->
                callMode.value = m
                if (m != CallMode.NONE) { w.show(); pill?.hide() } else w.hide()
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun listenPhone() {
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) return
        val tm = getSystemService(TelephonyManager::class.java) ?: return
        var wasRinging = false
        val l = object : PhoneStateListener() {
            @Deprecated("Deprecated in Java")
            override fun onCallStateChanged(state: Int, phoneNumber: String?) {
                if (!phoneNumber.isNullOrBlank()) Live.number.value = phoneNumber
                when (state) {
                    TelephonyManager.CALL_STATE_RINGING -> { wasRinging = true; Live.phoneRinging.value = true; Live.outgoing.value = false }
                    TelephonyManager.CALL_STATE_OFFHOOK -> {
                        Live.phoneRinging.value = false
                        if (!wasRinging) { Live.outgoing.value = true; Live.outgoingDismissed.value = false }
                        Live.callStartedAt.value = System.currentTimeMillis()
                    }
                    TelephonyManager.CALL_STATE_IDLE -> {
                        wasRinging = false
                        Live.phoneRinging.value = false
                        Live.outgoing.value = false
                        Live.outgoingDismissed.value = false
                        Live.callStartedAt.value = 0L
                        Live.number.value = null
                    }
                }
            }
        }
        runCatching { tm.listen(l, PhoneStateListener.LISTEN_CALL_STATE) }.onSuccess { phoneListener = l }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        landscape.value = newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE
    }

    // ------------------------------------------------------------ hardware keys
    private val keyHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var lastVolDown = 0L
    private val singleVolDown = Runnable {
        // It was a single press → do the normal volume-down.
        runCatching {
            getSystemService(android.media.AudioManager::class.java)
                .adjustSuggestedStreamVolume(android.media.AudioManager.ADJUST_LOWER, android.media.AudioManager.USE_DEFAULT_STREAM_TYPE, android.media.AudioManager.FLAG_SHOW_UI)
        }
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val f = Store.features.value
        val ringing = Live.ringing.value != null || Live.phoneRinging.value
        when (event.keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> {
                // Volume Up while the phone rings = decline the call.
                if (ringing && f.call.volumeUpDeclines) {
                    if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) com.iv.launcher.helper.CallActions.decline(this)
                    return true
                }
            }
            KeyEvent.KEYCODE_VOLUME_DOWN -> {
                // Volume Down twice quickly (not during a call) = IV Voice.
                val inCall = ringing || Live.callStartedAt.value != 0L
                if (f.voice.enabled && f.voice.volumeDownTwice && !inCall) {
                    if (event.action == KeyEvent.ACTION_DOWN) {
                        if (event.repeatCount > 0) { keyHandler.removeCallbacks(singleVolDown); singleVolDown.run(); return true }
                        val now = event.eventTime
                        if (now - lastVolDown < 400) {
                            keyHandler.removeCallbacks(singleVolDown)
                            lastVolDown = 0L
                            com.iv.launcher.voice.VoiceActivity.open(this)
                        } else {
                            lastVolDown = now
                            keyHandler.postDelayed(singleVolDown, 400)
                        }
                    }
                    return true
                }
            }
        }
        return super.onKeyEvent(event)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        cleanup()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    private fun cleanup() {
        pill?.hide(); decor?.hide(); call?.hide()
        phoneListener?.let { l -> runCatching { getSystemService(TelephonyManager::class.java)?.listen(l, PhoneStateListener.LISTEN_NONE) } }
        phoneListener = null
        scope?.cancel()
        scope = null
        if (instance === this) instance = null
        running.value = false
    }

    companion object {
        var instance: IvHelperService? = null
            private set
        val running = MutableStateFlow(false)

        fun isEnabled(context: Context): Boolean {
            val am = context.getSystemService(AccessibilityManager::class.java) ?: return false
            val me = ComponentName(context, IvHelperService::class.java).flattenToString()
            return am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
                .any { it.id.equals(me, true) || it.resolveInfo?.serviceInfo?.name == IvHelperService::class.java.name }
        }

        fun openSettings(context: Context) {
            runCatching {
                context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }

        /** Runs a gesture action. Returns false if IV Helper is needed but off. */
        fun perform(context: Context, action: GestureAction, openDrawer: () -> Unit): Boolean {
            val svc = instance
            return when (action) {
                GestureAction.NONE -> true
                GestureAction.LOCK -> svc?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN) ?: false
                GestureAction.NOTIFICATIONS -> svc?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS) ?: false
                GestureAction.QUICK_SETTINGS -> svc?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS) ?: false
                GestureAction.SEARCH -> { QuickActions.openSearch(context); true }
                GestureAction.DRAWER -> { openDrawer(); true }
                GestureAction.VOICE -> { com.iv.launcher.voice.VoiceActivity.open(context); true }
                GestureAction.SETTINGS -> {
                    context.startActivity(Intent(context, com.iv.launcher.settings.SettingsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    true
                }
            }
        }
    }
}
