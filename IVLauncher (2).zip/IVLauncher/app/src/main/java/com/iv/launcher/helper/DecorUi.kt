package com.iv.launcher.helper

import android.graphics.ImageDecoder
import android.graphics.drawable.AnimatedImageDrawable
import android.widget.ImageView
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.iv.launcher.data.RingStyle
import com.iv.launcher.data.StickerCfg
import com.iv.launcher.data.Store
import com.iv.launcher.ui.toColor
import java.io.File

/** Size of the decor window (the camera hole is in its centre). */
val DECOR_W: Dp = 320.dp
val DECOR_H: Dp = 170.dp

@Composable
fun DecorContent(cutoutDiameterPx: Float) {
    val features by Store.features.collectAsState()
    val d = features.decor
    // Animated rings redraw ~60 times a second; Battery Saver (or a static style) skips that entirely.
    val animated = !features.batterySaver && (d.ringStyle == RingStyle.SPIN || d.ringStyle == RingStyle.PULSE)
    var spin = 0f
    var pulse = 1f
    if (animated) {
        val t = rememberInfiniteTransition(label = "decor")
        spin = t.animateFloat(0f, 360f, infiniteRepeatable(tween(4000, easing = LinearEasing)), label = "spin").value
        pulse = t.animateFloat(0.55f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "pulse").value
    }

    Box(Modifier.size(DECOR_W, DECOR_H), contentAlignment = Alignment.Center) {
        if (d.ring) {
            Canvas(Modifier.fillMaxSize()) {
                val holeR = if (d.cutoutSizeDp > 0f) d.cutoutSizeDp.dp.toPx() / 2f else cutoutDiameterPx / 2f
                val w = d.ringWidthDp.dp.toPx()
                val r = holeR + d.ringGapDp.dp.toPx() + w / 2f
                val c = Offset(size.width / 2f + d.ringXDp.dp.toPx(), size.height / 2f + d.ringYDp.dp.toPx())
                val color = d.ringColor.toColor()
                val sweep = Brush.sweepGradient(d.ringGradient.colors.map { it.toColor() }.ifEmpty { listOf(color, color) }, c)
                when (d.ringStyle) {
                    RingStyle.SOLID -> drawCircle(color, r, c, style = Stroke(w))
                    RingStyle.GRADIENT -> drawCircle(sweep, r, c, style = Stroke(w))
                    RingStyle.GLOW -> {
                        for (i in 4 downTo 1) drawCircle(color.copy(alpha = 0.08f * i), r, c, style = Stroke(w + i * 3.dp.toPx()))
                        drawCircle(color, r, c, style = Stroke(w))
                    }
                    RingStyle.PULSE -> {
                        drawCircle(color.copy(alpha = 0.25f * pulse), r, c, style = Stroke(w + 6.dp.toPx() * pulse))
                        drawCircle(color.copy(alpha = pulse), r, c, style = Stroke(w))
                    }
                    RingStyle.SPIN -> rotate(spin, c) { drawCircle(sweep, r, c, style = Stroke(w)) }
                }
            }
        }
        val stopAfter = if (features.batterySaver) 5 else d.gifStopAfterSec
        d.stickers.forEach { s -> Sticker(s, stopAfter) }
    }
}

@Composable
private fun Sticker(s: StickerCfg, stopAfterSec: Int) {
    val file = File(Store.stickerDir, s.file)
    if (!file.exists()) return
    val holder = androidx.compose.runtime.remember(s.file) { arrayOfNulls<AnimatedImageDrawable>(1) }
    AndroidView(
        factory = { ctx ->
            ImageView(ctx).apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                val dr = runCatching { ImageDecoder.decodeDrawable(ImageDecoder.createSource(file)) }.getOrNull()
                setImageDrawable(dr)
                (dr as? AnimatedImageDrawable)?.let { a ->
                    holder[0] = a
                    a.start()
                    if (stopAfterSec > 0) postDelayed({ a.stop() }, stopAfterSec * 1000L)
                }
            }
        },
        modifier = Modifier
            .offset(s.xDp.dp, s.yDp.dp)
            .size(s.sizeDp.dp)
            .graphicsLayer { rotationZ = s.rotation },
    )
    DisposableEffect(s.file) { onDispose { holder[0]?.stop() } }
}
