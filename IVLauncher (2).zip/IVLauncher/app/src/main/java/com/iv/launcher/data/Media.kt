package com.iv.launcher.data

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class MediaNow(
    val pkg: String,
    val title: String,
    val artist: String,
    val art: Bitmap?,
    val playing: Boolean,
)

/**
 * Whatever is playing right now (Spotify, YT Music, YouTube Premium…).
 * Works because the badge notification access also allows reading media sessions.
 */
object Media {
    private val _now = MutableStateFlow<MediaNow?>(null)
    val now: StateFlow<MediaNow?> = _now

    private var manager: MediaSessionManager? = null
    private var controller: MediaController? = null
    private val main = Handler(Looper.getMainLooper())

    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = publish()
        override fun onPlaybackStateChanged(state: PlaybackState?) {
            publish()
            // A session that started playing may now be the better one.
            pickBest()
        }
        override fun onSessionDestroyed() { pickBest() }
    }

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { pickBest(it) }

    fun attach(context: Context, listener: ComponentName) {
        listenerComponent = listener
        runCatching {
            val m = context.getSystemService(MediaSessionManager::class.java) ?: return
            manager = m
            m.addOnActiveSessionsChangedListener(sessionsListener, listener, main)
            pickBest(m.getActiveSessions(listener))
        }
    }

    fun detach() {
        runCatching { manager?.removeOnActiveSessionsChangedListener(sessionsListener) }
        controller?.unregisterCallback(callback)
        controller = null
        _now.value = null
    }

    private var listenerComponent: ComponentName? = null

    private fun pickBest(list: List<MediaController>? = null) {
        val sessions = list ?: runCatching { manager?.getActiveSessions(listenerComponent) }.getOrNull() ?: emptyList()
        val best = sessions.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: sessions.firstOrNull()
        if (best?.sessionToken != controller?.sessionToken) {
            controller?.unregisterCallback(callback)
            controller = best
            best?.registerCallback(callback, main)
        }
        publish()
    }

    private fun publish() {
        val c = controller
        val md = c?.metadata
        if (c == null || md == null) { _now.value = null; return }
        val title = md.getString(MediaMetadata.METADATA_KEY_TITLE) ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE).orEmpty()
        if (title.isBlank()) { _now.value = null; return }
        _now.value = MediaNow(
            pkg = c.packageName,
            title = title,
            artist = md.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE).orEmpty(),
            art = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
                ?: md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON),
            playing = c.playbackState?.state == PlaybackState.STATE_PLAYING,
        )
    }

    fun togglePlay() {
        val c = controller ?: return
        if (c.playbackState?.state == PlaybackState.STATE_PLAYING) c.transportControls.pause() else c.transportControls.play()
    }
    fun next() { controller?.transportControls?.skipToNext() }
    fun previous() { controller?.transportControls?.skipToPrevious() }

    fun open(context: Context) {
        val c = controller ?: return
        runCatching { c.sessionActivity?.send() }.onFailure {
            context.packageManager.getLaunchIntentForPackage(c.packageName)?.let {
                context.startActivity(it.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
    }
}
