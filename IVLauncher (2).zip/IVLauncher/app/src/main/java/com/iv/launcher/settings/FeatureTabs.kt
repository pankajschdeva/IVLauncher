package com.iv.launcher.settings

import android.Manifest
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.iv.launcher.badges.BadgeService
import com.iv.launcher.data.AppInfo
import com.iv.launcher.data.AppRepo
import com.iv.launcher.data.ClockCfg
import com.iv.launcher.data.ClockStyle
import com.iv.launcher.data.FeatureCfg
import com.iv.launcher.data.FillType
import com.iv.launcher.data.FontChoice
import com.iv.launcher.data.GestureAction
import com.iv.launcher.data.LockBg
import com.iv.launcher.data.RingStyle
import com.iv.launcher.data.StickerCfg
import com.iv.launcher.data.Store
import com.iv.launcher.data.ThemeCfg
import com.iv.launcher.data.Weather
import com.iv.launcher.data.WeatherUnit
import com.iv.launcher.data.WidgetCfg
import com.iv.launcher.data.WidgetKind
import com.iv.launcher.helper.IvHelperService
import com.iv.launcher.lock.LockWallpaperService
import com.iv.launcher.ui.BigClock
import com.iv.launcher.ui.Fonts
import com.iv.launcher.ui.brush
import com.iv.launcher.widgets.WidgetPickerActivity
import com.iv.launcher.widgets.Widgets
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

private fun feat(block: (FeatureCfg) -> FeatureCfg) = Store.editFeatures(block)
private fun say(c: Context, m: String) = Toast.makeText(c, m, Toast.LENGTH_SHORT).show()
private val hintColor = Color(0xFF9A9AA2)
private val warnColor = Color(0xFFFFC56B)

@Composable
private fun Hint(text: String, warn: Boolean = false) =
    Text(text, color = if (warn) warnColor else hintColor, fontSize = 12.5.sp, modifier = Modifier.padding(horizontal = 18.dp, vertical = 6.dp))

@Composable
private fun TextRow(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) }, singleLine = true,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
    )
}

/** Hold and drag inside this pad to move something on the real screen. */
@Composable
private fun DragPad(label: String, onMove: (dxDp: Float, dyDp: Float) -> Unit) {
    val density = LocalDensity.current.density
    Box(
        Modifier
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .fillMaxWidth()
            .height(90.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(Color.White.copy(alpha = 0.06f))
            .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(18.dp))
            .pointerInput(Unit) {
                detectDragGestures { change, drag ->
                    change.consume()
                    onMove(drag.x / density * 0.35f, drag.y / density * 0.35f)
                }
            },
        contentAlignment = Alignment.Center,
    ) { Text("✋  $label", color = hintColor, fontSize = 13.sp) }
}

@Composable
private fun Nudge(onMove: (Float, Float) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
        listOf("◀" to (-1f to 0f), "▲" to (0f to -1f), "▼" to (0f to 1f), "▶" to (1f to 0f)).forEach { (t, d) ->
            Text(
                t, color = Color.White, fontSize = 18.sp,
                modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(Color.White.copy(alpha = 0.08f))
                    .clickable { onMove(d.first, d.second) }.padding(horizontal = 18.dp, vertical = 8.dp),
            )
        }
    }
}

@Composable
private fun AppPickerDialog(title: String, onDismiss: () -> Unit, onPick: (AppInfo) -> Unit) {
    val apps by AppRepo.apps.collectAsState()
    var q by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        containerColor = Color(0xFF1C1C1F),
        title = { Text(title, color = Color.White) },
        text = {
            Column {
                OutlinedTextField(q, { q = it }, singleLine = true, label = { Text("Search") }, modifier = Modifier.fillMaxWidth())
                LazyColumn(Modifier.heightIn(max = 380.dp)) {
                    items(apps.filter { q.isBlank() || it.label.contains(q, true) }, key = { it.key }) { a ->
                        Text(a.label, color = Color.White, fontSize = 15.sp, modifier = Modifier.fillMaxWidth().clickable { onPick(a) }.padding(vertical = 11.dp))
                    }
                }
            }
        },
    )
}

// ===================================================================== Clock editor

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ClockEditor(cfg: ClockCfg, theme: ThemeCfg, previewBg: List<Long> = listOf(0xFF6F8FB0, 0xFF2C3A4A), onChange: (ClockCfg) -> Unit) {
    val weather by Weather.now.collectAsState()
    Box(
        Modifier.padding(horizontal = 16.dp, vertical = 6.dp).fillMaxWidth().heightIn(min = 140.dp)
            .clip(RoundedCornerShape(20.dp)).background(com.iv.launcher.data.GradientSpec(previewBg, 90f).brush()).padding(12.dp),
        contentAlignment = Alignment.Center,
    ) {
        BigClock(cfg.copy(sizeSp = cfg.sizeSp.coerceAtMost(120f)), weather, theme.customFontVersion)
    }
    ChoiceRow("Clock style", ClockStyle.entries, cfg.style, { it.title }) { onChange(cfg.copy(style = it)) }
    ChoiceRow("Font", FontChoice.entries.filter { it != FontChoice.CUSTOM || theme.customFontVersion > 0 }, cfg.font, { Fonts.label[it] ?: it.name }) {
        onChange(cfg.copy(font = it))
    }
    SliderRow("Size", cfg.sizeSp, 30f..240f, { "${it.roundToInt()} sp" }) { onChange(cfg.copy(sizeSp = it)) }
    SliderRow("Height (taller)", cfg.heightScale, 0.6f..4f, { String.format("%.1f×", it) }) { onChange(cfg.copy(heightScale = it)) }
    SliderRow("Width (thinner ↔ wider)", cfg.widthScale, 0.3f..2f, { String.format("%.2f×", it) }) { onChange(cfg.copy(widthScale = it)) }
    SliderRow("Thickness (weight)", cfg.weight.toFloat(), 100f..900f, { it.roundToInt().toString() }, steps = 7) {
        onChange(cfg.copy(weight = (it / 100f).roundToInt() * 100))
    }
    SliderRow("Letter spacing", cfg.letterSpacing, -0.1f..0.4f, { String.format("%.2f", it) }) { onChange(cfg.copy(letterSpacing = it)) }
    if (cfg.style == ClockStyle.OUTLINE || cfg.style == ClockStyle.GLASS) {
        SliderRow("Outline width", cfg.outlineDp, 0.5f..8f, { String.format("%.1f", it) }) { onChange(cfg.copy(outlineDp = it)) }
    }
    if (cfg.style == ClockStyle.GRADIENT) GradientRow("Clock gradient", cfg.gradient) { onChange(cfg.copy(gradient = it)) }
    else ColorRow("Clock color", cfg.color) { onChange(cfg.copy(color = it)) }
    SwitchRow("Show day & date (Mon 5)", cfg.showDate) { onChange(cfg.copy(showDate = it)) }
    SwitchRow("Show weather next to date", cfg.showWeather) { onChange(cfg.copy(showWeather = it)) }
    SliderRow("Date size", cfg.dateSizeSp, 10f..32f, { "${it.roundToInt()} sp" }) { onChange(cfg.copy(dateSizeSp = it)) }
    ColorRow("Date color", cfg.dateColor) { onChange(cfg.copy(dateColor = it)) }
    SwitchRow("24-hour time", cfg.use24h, "Off = follows your phone setting") { onChange(cfg.copy(use24h = it)) }
}

// ===================================================================== Widgets

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun WidgetsTab(theme: ThemeCfg) {
    val context = LocalContext.current
    val layout by Store.layout.collectAsState()
    var openId by remember { mutableStateOf<String?>(null) }
    var pickAppFor by remember { mutableStateOf<String?>(null) }

    Section("Add a widget", "New widgets appear at the top of your first home page. Long-press a widget on home to resize or move it.") {
        ButtonRow("🕘  Tall clock", "7 styles, as tall / thin as you want") { Widgets.add(Widgets.preset(WidgetKind.CLOCK)) ; say(context, "Clock added") }
        ButtonRow("⛅  Weather", "City, temperature, H/L (4×2 shows hourly)") { Widgets.add(Widgets.preset(WidgetKind.WEATHER)); say(context, "Weather added") }
        ButtonRow("📅  Calendar", "Month view with today highlighted") { Widgets.add(Widgets.preset(WidgetKind.CALENDAR)); say(context, "Calendar added") }
        ButtonRow("🎵  Music", "Controls whatever is playing") { Widgets.add(Widgets.preset(WidgetKind.MUSIC)); say(context, "Music added") }
        ButtonRow("✨  Custom app widget", "Any app: big emoji / icon, your text, your colors") {
            val w = Widgets.preset(WidgetKind.CUSTOM); Widgets.add(w); openId = w.id; pickAppFor = w.id
        }
        ButtonRow("🧩  Android widget", "Gemini (with Live), Google search, Spotify, Photos…") {
            context.startActivity(Intent(context, WidgetPickerActivity::class.java))
        }
    }

    if (layout.widgets.isNotEmpty()) Section("Your widgets", "Tap one to edit it.") {
        layout.widgets.forEach { w ->
            val name = when (w.kind) {
                WidgetKind.CUSTOM -> "✨ " + (w.title.ifBlank { "Custom" })
                WidgetKind.SYSTEM -> "🧩 " + (runCatching { Widgets.systemLabel(context, w.appWidgetId) }.getOrNull() ?: "Android widget")
                else -> w.kind.name.lowercase().replaceFirstChar { it.uppercase() }
            }
            ButtonRow(name, "${w.w}×${w.h}", value = if (openId == w.id) "▲" else "▼") { openId = if (openId == w.id) null else w.id }
            if (openId == w.id) WidgetEditor(w, theme, onPickApp = { pickAppFor = w.id })
        }
    }

    pickAppFor?.let { id ->
        AppPickerDialog("Which app opens on tap?", onDismiss = { pickAppFor = null }) { app ->
            Widgets.update(id) { it.copy(appKey = app.key, title = if (it.title == "My widget" || it.title.isBlank()) app.label else it.title) }
            pickAppFor = null
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun WidgetEditor(w: WidgetCfg, theme: ThemeCfg, onPickApp: () -> Unit) {
    fun up(block: (WidgetCfg) -> WidgetCfg) = Widgets.update(w.id, block)
    Column(Modifier.padding(start = 8.dp).background(Color.White.copy(alpha = 0.03f), RoundedCornerShape(16.dp))) {
        ChoiceRow("Size", Widgets.sizes, w.w to w.h, { "${it.first}×${it.second}" }) { (cw, ch) -> up { it.copy(w = cw, h = ch) } }
        if (w.kind == WidgetKind.CUSTOM) {
            ButtonRow("App to open", value = w.appKey?.substringBefore('/')?.substringAfterLast('.') ?: "choose") { onPickApp() }
            TextRow("Emoji (big, optional)", w.emoji) { v -> up { it.copy(emoji = v.take(8)) } }
            FlowRow(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("👻", "📸", "💬", "🎧", "🔥", "✨", "❤️", "🎮", "🍿", "🚗", "💸", "🤖", "📚", "🏋️", "🌙", "⭐").forEach { e ->
                    Text(e, fontSize = 24.sp, modifier = Modifier.clickable { up { it.copy(emoji = e) } }.padding(4.dp))
                }
            }
            TextRow("Title", w.title) { v -> up { it.copy(title = v) } }
            TextRow("Subtitle", w.subtitle) { v -> up { it.copy(subtitle = v) } }
            SwitchRow("Show app icon (when no emoji)", w.showIcon) { v -> up { it.copy(showIcon = v) } }
        }
        if (w.kind == WidgetKind.CLOCK) {
            ClockEditor(w.clock, theme) { c -> up { it.copy(clock = c) } }
        }
        if (w.kind != WidgetKind.SYSTEM) {
            ChoiceRow("Background", FillType.entries, w.fill, { it.name.lowercase().replaceFirstChar { c -> c.uppercase() } }) { f -> up { it.copy(fill = f) } }
            if (w.fill == FillType.GRADIENT || w.fill == FillType.PLUSH) GradientRow("Gradient", w.gradient) { g -> up { it.copy(gradient = g) } }
            else if (w.fill != FillType.NONE) ColorRow("Color", w.color) { c -> up { it.copy(color = c) } }
            if (w.fill != FillType.NONE) SliderRow("Opacity", w.alpha, 0f..1f, { "${(it * 100).roundToInt()}%" }) { v -> up { it.copy(alpha = v) } }
            ColorRow("Text color", w.textColor) { c -> up { it.copy(textColor = c) } }
        }
        ButtonRow("Remove this widget") { Widgets.remove(w.id) }
    }
}

// ===================================================================== Weather

@Composable
fun WeatherTab(f: FeatureCfg) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val now by Weather.now.collectAsState()
    val err by Weather.error.collectAsState()
    var city by remember { mutableStateOf(f.weather.city) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        scope.launch { Weather.refresh(context, force = true) }
    }
    Section("Weather", "Free weather from Open-Meteo. Shows in the weather widget, next to the clock, and on the lock screen.") {
        Text(
            now?.let { "${it.emoji}  ${it.city}  ${it.temp}°  ${it.text}   H:${it.high}° L:${it.low}°" } ?: (err ?: "No weather yet"),
            color = Color.White, fontSize = 15.sp, modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp),
        )
        SwitchRow("Use my location", f.weather.auto, "Off = use the city below") { v -> feat { it.copy(weather = it.weather.copy(auto = v)) } }
        if (f.weather.auto && !Weather.hasLocationPermission(context)) {
            ButtonRow("Allow location", "Approximate location is enough") { perm.launch(Manifest.permission.ACCESS_COARSE_LOCATION) }
        }
        TextRow("City (e.g. Bhubaneswar)", city) { city = it }
        ButtonRow("Use this city") {
            scope.launch {
                val g = withContext(Dispatchers.IO) { runCatching { Weather.geocode(city) }.getOrNull() }
                if (g == null) say(context, "City not found") else {
                    feat { it.copy(weather = it.weather.copy(auto = false, city = city.trim(), lat = g.first, lon = g.second)) }
                    Weather.refresh(context, force = true)
                }
            }
        }
        ChoiceRow("Units", WeatherUnit.entries, f.weather.unit, { if (it == WeatherUnit.C) "°C" else "°F" }) { u ->
            feat { it.copy(weather = it.weather.copy(unit = u)) }
            scope.launch { Weather.refresh(context, force = true) }
        }
        ButtonRow("Refresh now") { scope.launch { Weather.refresh(context, force = true) } }
    }
}

// ===================================================================== Arc picker + gestures

@Composable
fun ArcTab(f: FeatureCfg) {
    val layout by Store.layout.collectAsState()
    val apps by AppRepo.apps.collectAsState()
    var picking by remember { mutableStateOf(false) }
    Section("Arc picker", "Hold the bottom-right edge of the home screen, slide up/down, let go on an app to open it.") {
        SwitchRow("Arc picker", f.gestures.arcEnabled) { v -> feat { it.copy(gestures = it.gestures.copy(arcEnabled = v)) } }
        SwitchRow("Vibrate on each app", f.gestures.arcHaptics) { v -> feat { it.copy(gestures = it.gestures.copy(arcHaptics = v)) } }
        ColorRow("Highlight color", f.gestures.arcAccent) { c -> feat { it.copy(gestures = it.gestures.copy(arcAccent = c)) } }
        Hint("Works on the IV home screen. Inside other apps, Android keeps that edge for its Back gesture.")
    }
    Section("Apps in the arc (max 10)", if (layout.favorites.isEmpty()) "Empty = your dock apps are used." else null) {
        layout.favorites.forEachIndexed { i, key ->
            val label = apps.firstOrNull { it.key == key }?.label ?: key
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(label, color = Color.White, fontSize = 15.sp, modifier = Modifier.weight(1f))
                Text("▲", color = Color.White, modifier = Modifier.clickable { moveFav(i, -1) }.padding(8.dp))
                Text("▼", color = Color.White, modifier = Modifier.clickable { moveFav(i, 1) }.padding(8.dp))
                Text("✕", color = Color(0xFFFF6B6B), modifier = Modifier.clickable { com.iv.launcher.home.HomeEdits.toggleFavorite(key) }.padding(8.dp))
            }
        }
        ButtonRow("Add app") { picking = true }
    }
    if (picking) AppPickerDialog("Add to arc picker", onDismiss = { picking = false }) { a ->
        if (a.key !in layout.favorites) com.iv.launcher.home.HomeEdits.toggleFavorite(a.key)
        picking = false
    }
}

private fun moveFav(i: Int, by: Int) = Store.editLayout { l ->
    val list = l.favorites.toMutableList()
    val j = (i + by).coerceIn(0, list.lastIndex)
    if (i !in list.indices) return@editLayout l
    val k = list.removeAt(i); list.add(j, k)
    l.copy(favorites = list)
}

@Composable
fun GesturesTab(f: FeatureCfg) {
    val context = LocalContext.current
    val helperOn by IvHelperService.running.collectAsState()
    Section("Home screen gestures") {
        ChoiceRow("Single tap on empty space", GestureAction.entries, f.gestures.singleTap, { it.title }) { a ->
            feat { it.copy(gestures = it.gestures.copy(singleTap = a)) }
        }
        ChoiceRow("Double-tap empty space", GestureAction.entries, f.gestures.doubleTap, { it.title }) { a ->
            feat { it.copy(gestures = it.gestures.copy(doubleTap = a)) }
        }
        ChoiceRow("Swipe down", GestureAction.entries, f.gestures.swipeDown, { it.title }) { a ->
            feat { it.copy(gestures = it.gestures.copy(swipeDown = a)) }
        }
        if (!helperOn) {
            Hint("Lock screen / Notifications / Quick settings need \"IV Helper\" turned on.", warn = true)
            ButtonRow("Turn on IV Helper") { IvHelperService.openSettings(context) }
        }
    }
}

// ===================================================================== Top pill

@Composable
fun PillTab(f: FeatureCfg) {
    val context = LocalContext.current
    val helperOn by IvHelperService.running.collectAsState()
    val p = f.pill
    var picking by remember { mutableStateOf(false) }
    fun up(block: (com.iv.launcher.data.PillCfg) -> com.iv.launcher.data.PillCfg) = feat { it.copy(pill = block(it.pill)) }
    Section("Top pill", "A small black bar around the camera that shows calls, recordings, timers and music. Tap it to open the big card with buttons.") {
        SwitchRow("Top pill", p.enabled) { v -> up { it.copy(enabled = v) } }
        if (!helperOn) {
            Hint("Needs IV Helper (accessibility) + Notification access.", warn = true)
            ButtonRow("Turn on IV Helper") { IvHelperService.openSettings(context) }
        }
        SwitchRow("Calls", p.calls) { v -> up { it.copy(calls = v) } }
        SwitchRow("Music", p.media) { v -> up { it.copy(media = v) } }
        SwitchRow("Recordings, timers & stopwatches", p.timers, "Anything with a running timer (Snapchat, recorder, clock…)") { v -> up { it.copy(timers = v) } }
        SwitchRow("Every ongoing notification", p.allOngoing) { v -> up { it.copy(allOngoing = v) } }
    }
    Section("Look") {
        ColorRow("Pill color", p.color) { c -> up { it.copy(color = c) } }
        ColorRow("Text color", p.textColor) { c -> up { it.copy(textColor = c) } }
        ColorRow("Recording dot", p.dotColor) { c -> up { it.copy(dotColor = c) } }
        SliderRow("Height", p.heightDp, 24f..56f, { "${it.roundToInt()} dp" }) { v -> up { it.copy(heightDp = v) } }
        SliderRow("Width", p.minWidthDp, 120f..340f, { "${it.roundToInt()} dp" }) { v -> up { it.copy(minWidthDp = v) } }
        SliderRow("Move down", p.yOffsetDp, 0f..40f, { "${it.roundToInt()} dp" }) { v -> up { it.copy(yOffsetDp = v) } }
        SwitchRow("Thin outline", p.outline) { v -> up { it.copy(outline = v) } }
    }
    Section("Hide for these apps") {
        p.blocked.forEach { pkg ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp)) {
                Text(pkg, color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text("✕", color = Color(0xFFFF6B6B), modifier = Modifier.clickable { up { it.copy(blocked = it.blocked - pkg) } })
            }
        }
        ButtonRow("Add app") { picking = true }
    }
    if (picking) AppPickerDialog("Hide pill for…", onDismiss = { picking = false }) { a ->
        up { it.copy(blocked = it.blocked + a.pkg) }; picking = false
    }
}

// ===================================================================== Camera decor

@Composable
fun DecorTab(f: FeatureCfg) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val helperOn by IvHelperService.running.collectAsState()
    val d = f.decor
    fun up(block: (com.iv.launcher.data.DecorCfg) -> com.iv.launcher.data.DecorCfg) = feat { it.copy(decor = block(it.decor)) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            val name = Store.saveSticker(context, uri)
            if (name == null) say(context, "Couldn't add that picture")
            else up { it.copy(stickers = it.stickers + StickerCfg(id = name, file = name)) }
        }
    }
    Section("Camera decor", "Ring, stickers and GIFs around the front camera. Changes show live on your screen – watch the camera while you adjust.") {
        SwitchRow("Camera decor", d.enabled) { v -> up { it.copy(enabled = v) } }
        if (!helperOn) {
            Hint("Needs IV Helper (accessibility) so it can draw above the status bar.", warn = true)
            ButtonRow("Turn on IV Helper") { IvHelperService.openSettings(context) }
        }
        SwitchRow("Hide in landscape (videos, games)", d.hideLandscape) { v -> up { it.copy(hideLandscape = v) } }
    }
    Section("Ring around the camera") {
        SwitchRow("Ring", d.ring) { v -> up { it.copy(ring = v) } }
        if (d.ring) {
            ChoiceRow("Style", RingStyle.entries, d.ringStyle, { it.title }) { s -> up { it.copy(ringStyle = s) } }
            if (d.ringStyle == RingStyle.GRADIENT || d.ringStyle == RingStyle.SPIN) GradientRow("Ring colors", d.ringGradient) { g -> up { it.copy(ringGradient = g) } }
            else ColorRow("Ring color", d.ringColor) { c -> up { it.copy(ringColor = c) } }
            SliderRow("Thickness", d.ringWidthDp, 0.5f..10f, { String.format("%.1f dp", it) }) { v -> up { it.copy(ringWidthDp = v) } }
            SliderRow("Gap from camera", d.ringGapDp, 0f..20f, { String.format("%.1f dp", it) }) { v -> up { it.copy(ringGapDp = v) } }
            SliderRow("Camera hole size", d.cutoutSizeDp, 0f..60f, { if (it < 1f) "Auto" else "${it.roundToInt()} dp" }) { v -> up { it.copy(cutoutSizeDp = v) } }
            DragPad("Drag to move the ring") { dx, dy -> up { it.copy(ringXDp = (it.ringXDp + dx).coerceIn(-60f, 60f), ringYDp = (it.ringYDp + dy).coerceIn(-40f, 40f)) } }
            Nudge { dx, dy -> up { it.copy(ringXDp = it.ringXDp + dx * 0.5f, ringYDp = it.ringYDp + dy * 0.5f) } }
            ButtonRow("Center the ring again") { up { it.copy(ringXDp = 0f, ringYDp = 0f) } }
        }
    }
    Section("Stickers & GIFs", "Add any picture or GIF from your phone (PNG with transparent background looks best).") {
        ButtonRow("Add sticker / GIF") { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
        SliderRow("Stop GIFs after", d.gifStopAfterSec.toFloat(), 0f..60f, { if (it < 1f) "Never" else "${it.roundToInt()} s" }) { v ->
            up { it.copy(gifStopAfterSec = v.roundToInt()) }
        }
        d.stickers.forEachIndexed { i, s ->
            fun us(block: (StickerCfg) -> StickerCfg) = up { cfg -> cfg.copy(stickers = cfg.stickers.map { if (it.id == s.id) block(it) else it }) }
            Text("Sticker ${i + 1}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp))
            SliderRow("Size", s.sizeDp, 8f..120f, { "${it.roundToInt()} dp" }) { v -> us { it.copy(sizeDp = v) } }
            SliderRow("Rotation", s.rotation, -180f..180f, { "${it.roundToInt()}°" }) { v -> us { it.copy(rotation = v) } }
            DragPad("Drag to move sticker ${i + 1}") { dx, dy -> us { it.copy(xDp = (it.xDp + dx).coerceIn(-150f, 150f), yDp = (it.yDp + dy).coerceIn(-80f, 80f)) } }
            Nudge { dx, dy -> us { it.copy(xDp = it.xDp + dx, yDp = it.yDp + dy) } }
            ButtonRow("Remove sticker ${i + 1}") {
                runCatching { java.io.File(Store.stickerDir, s.file).delete() }
                up { cfg -> cfg.copy(stickers = cfg.stickers.filterNot { it.id == s.id }) }
            }
        }
    }
}

// ===================================================================== Lock screen

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LockTab(f: FeatureCfg, theme: ThemeCfg) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val l = f.lock
    var todo by remember { mutableStateOf("") }
    fun up(block: (com.iv.launcher.data.LockCfg) -> com.iv.launcher.data.LockCfg) = feat { it.copy(lock = block(it.lock)) }
    val lockPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            if (Store.saveImage(context, uri, Store.lockImageFile)) up { it.copy(bg = LockBg.LOCK_IMAGE, version = System.currentTimeMillis()) }
        }
    }
    val fgPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            if (Store.saveImage(context, uri, Store.lockForegroundFile, png = true)) up { it.copy(foregroundLayer = true, version = System.currentTimeMillis()) }
        }
    }
    Section("IV lock screen", "Works as a live wallpaper: your clock, date, weather and info are drawn on the lock screen.") {
        ButtonRow("Apply IV lock screen", "Opens Android's wallpaper preview → tap Set wallpaper") {
            val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
                .putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, ComponentName(context, LockWallpaperService::class.java))
            runCatching { context.startActivity(i) }.onFailure {
                runCatching { context.startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER)) }
            }
        }
        Hint("Tip: Pixel also shows its own small clock. Settings → Display → Lock screen → turn off \"Double-line clock\" so yours stands out.")
        SwitchRow("Show the clock on home screen too", l.showClockWhenUnlocked, "Off = home shows only the background") { v -> up { it.copy(showClockWhenUnlocked = v) } }
    }
    Section("Background") {
        ChoiceRow("Source", LockBg.entries, l.bg, { it.title }) { b ->
            if (b == LockBg.LOCK_IMAGE && !Store.lockImageFile.exists()) lockPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            else up { it.copy(bg = b) }
        }
        if (l.bg == LockBg.LOCK_IMAGE) ButtonRow("Choose lock picture") { lockPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
        if (l.bg == LockBg.GRADIENT) GradientRow("Gradient", l.gradient) { g -> up { it.copy(gradient = g) } }
        if (l.bg == LockBg.SOLID) ColorRow("Color (sky blue = 9DB4CC)", l.color) { c -> up { it.copy(color = c) } }
        SliderRow("Darken", l.dim, 0f..0.8f, { "${(it * 100).roundToInt()}%" }) { v -> up { it.copy(dim = v) } }
    }
    Section("Depth effect", "Put a cut-out PNG (person / object with transparent background) over the clock, like the iPhone look.") {
        SwitchRow("Depth layer", l.foregroundLayer) { v -> up { it.copy(foregroundLayer = v) } }
        ButtonRow("Choose cut-out PNG") { fgPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
    }
    Section("Clock") {
        SliderRow("Clock position from top", l.clockTopDp, 40f..500f, { "${it.roundToInt()} dp" }) { v -> up { it.copy(clockTopDp = v) } }
        ClockEditor(l.clock, theme, previewBg = l.gradient.colors) { c -> up { it.copy(clock = c) } }
    }
    Section("Info at the bottom") {
        ColorRow("Info color", l.infoColor) { c -> up { it.copy(infoColor = c) } }
        SwitchRow("Battery %", l.showBattery) { v -> up { it.copy(showBattery = v) } }
        SwitchRow("Now playing", l.showMusic) { v -> up { it.copy(showMusic = v) } }
        Text("To-do list (max 4 shown)", color = Color.White, fontSize = 15.sp, modifier = Modifier.padding(horizontal = 18.dp, vertical = 6.dp))
        l.todos.forEach { t ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 4.dp)) {
                Text("○  $t", color = Color.White, modifier = Modifier.weight(1f))
                Text("✕", color = Color(0xFFFF6B6B), modifier = Modifier.clickable { up { it.copy(todos = it.todos - t) } })
            }
        }
        TextRow("New to-do", todo) { todo = it }
        ButtonRow("Add to-do") { if (todo.isNotBlank()) { up { it.copy(todos = it.todos + todo.trim()) }; todo = "" } }
    }
}

// ===================================================================== Call screen

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CallTab(f: FeatureCfg) {
    val context = LocalContext.current
    val helperOn by IvHelperService.running.collectAsState()
    val c = f.call
    var reply by remember { mutableStateOf("") }
    fun up(block: (com.iv.launcher.data.CallCfg) -> com.iv.launcher.data.CallCfg) = feat { it.copy(call = block(it.call)) }
    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
    Section("Call screen", "Your own incoming-call screen with slide to answer. Turn it off any time to see the normal Pixel screen.") {
        SwitchRow("IV incoming call screen", c.incoming) { v -> up { it.copy(incoming = v) } }
        SwitchRow("IV outgoing call screen", c.outgoing, "Shows name, timer and End. 'Phone screen' opens Pixel's controls.") { v -> up { it.copy(outgoing = v) } }
        SwitchRow("Volume Up declines a ringing call", c.volumeUpDeclines, "Works on the lock screen too (needs IV Helper)") { v -> up { it.copy(volumeUpDeclines = v) } }
        if (!helperOn) {
            Hint("Needs IV Helper (accessibility) + Notification access.", warn = true)
            ButtonRow("Turn on IV Helper") { IvHelperService.openSettings(context) }
        }
        ButtonRow("Allow phone permissions", "Phone state, call log (number), answer calls, SMS (quick reply)") {
            perms.launch(
                arrayOf(
                    Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG,
                    Manifest.permission.ANSWER_PHONE_CALLS, Manifest.permission.SEND_SMS,
                    Manifest.permission.POST_NOTIFICATIONS,
                )
            )
        }
        Hint("After allowing phone permissions, turn IV Helper off and on once so it starts listening.")
    }
    Section("Look") {
        TextRow("Label under the name", c.label) { v -> up { it.copy(label = v) } }
        TextRow("Emoji next to label", c.emoji) { v -> up { it.copy(emoji = v.take(6)) } }
        TextRow("Slider text", c.sliderText) { v -> up { it.copy(sliderText = v) } }
        ColorRow("Phone icon color", c.accent) { v -> up { it.copy(accent = v) } }
        SliderRow("Background blur", c.blurDp, 0f..60f, { "${it.roundToInt()} dp" }) { v -> up { it.copy(blurDp = v) } }
    }
    Section("Message replies") {
        c.quickReplies.forEach { r ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 5.dp)) {
                Text(r, color = Color.White, modifier = Modifier.weight(1f))
                Text("✕", color = Color(0xFFFF6B6B), modifier = Modifier.clickable { up { it.copy(quickReplies = it.quickReplies - r) } })
            }
        }
        TextRow("New reply", reply) { reply = it }
        ButtonRow("Add reply") { if (reply.isNotBlank()) { up { it.copy(quickReplies = it.quickReplies + reply.trim()) }; reply = "" } }
    }
    Section("Remind Me options") {
        FlowRow(Modifier.padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(5, 10, 15, 30, 60, 120).forEach { m ->
                val on = m in c.remindMinutes
                Text(
                    if (m >= 60) "${m / 60} h" else "$m min",
                    color = if (on) Color.Black else Color.White,
                    modifier = Modifier.clip(RoundedCornerShape(50)).background(if (on) MaterialTheme.colorScheme.primary else Color.White.copy(alpha = 0.08f))
                        .clickable { up { it.copy(remindMinutes = if (on) it.remindMinutes - m else (it.remindMinutes + m).sorted()) } }
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                )
            }
        }
    }
}

// ===================================================================== Permissions hub

@Composable
fun PermissionsTab() {
    val context = LocalContext.current
    val helperOn by IvHelperService.running.collectAsState()
    var refresh by remember { mutableIntStateOf(0) }
    androidx.lifecycle.compose.LifecycleEventEffect(androidx.lifecycle.Lifecycle.Event.ON_RESUME) { refresh++ }
    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh++ }
    fun has(p: String) = context.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    androidx.compose.runtime.key(refresh) {
    Section("What each permission does", "Everything stays on your phone. Turn any of these off later in Android settings.") {
        ButtonRow("Notification access", if (BadgeService.hasAccess(context)) "On ✓ – badges, music, pill, calls" else "Off – tap to allow") {
            runCatching {
                context.startActivity(
                    Intent(android.provider.Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS)
                        .putExtra(android.provider.Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME, BadgeService.component(context).flattenToString())
                )
            }
        }
        ButtonRow("IV Helper (accessibility)", if (helperOn) "On ✓ – gestures, pill, camera decor, call screen" else "Off – tap → Downloaded apps → IV Helper") {
            IvHelperService.openSettings(context)
        }
        Hint(
            "If Android shows \"Restricted setting\": Settings → Apps → IV Settings → ⋮ → Allow restricted settings, then try again.",
            warn = true,
        )
        ButtonRow("Location", if (has(Manifest.permission.ACCESS_COARSE_LOCATION)) "Allowed ✓ – weather" else "Tap to allow – weather") {
            perms.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION))
        }
        ButtonRow("Phone & calls", if (has(Manifest.permission.READ_PHONE_STATE) && has(Manifest.permission.ANSWER_PHONE_CALLS)) "Allowed ✓ – call screen" else "Tap to allow – call screen") {
            perms.launch(arrayOf(Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG, Manifest.permission.ANSWER_PHONE_CALLS))
        }
        ButtonRow("SMS", if (has(Manifest.permission.SEND_SMS)) "Allowed ✓ – quick replies" else "Tap to allow – quick replies") {
            perms.launch(arrayOf(Manifest.permission.SEND_SMS))
        }
        ButtonRow("Microphone, Contacts & Calls", if (has(Manifest.permission.RECORD_AUDIO) && has(Manifest.permission.READ_CONTACTS) && has(Manifest.permission.CALL_PHONE)) "Allowed ✓ – IV Voice" else "Tap to allow – IV Voice (\"call Papa\")") {
            perms.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE))
        }
        ButtonRow("Notifications", if (has(Manifest.permission.POST_NOTIFICATIONS)) "Allowed ✓ – Remind Me" else "Tap to allow – Remind Me") {
            perms.launch(arrayOf(Manifest.permission.POST_NOTIFICATIONS))
        }
    }
    }
}

// ===================================================================== Status bar

@Composable
fun StatusBarTab(f: FeatureCfg) {
    val context = LocalContext.current
    val sb = f.statusBar
    fun up(block: (com.iv.launcher.data.StatusBarCfg) -> com.iv.launcher.data.StatusBarCfg) = feat { it.copy(statusBar = block(it.statusBar)) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    Section("IV status bar", "On the IV home screen, Android's bar is hidden and IV draws its own: time, date, apps with notifications, 5G, signal, Wi-Fi and battery. Swipe down from the very top to see Android's bar for a moment.") {
        SwitchRow("IV status bar on home", sb.enabled) { v -> up { it.copy(enabled = v) } }
        SwitchRow("Date next to time", sb.showDate) { v -> up { it.copy(showDate = v) } }
        SwitchRow("Seconds", sb.showSeconds) { v -> up { it.copy(showSeconds = v) } }
        SwitchRow("Bold time", sb.boldTime) { v -> up { it.copy(boldTime = v) } }
        SwitchRow("Battery %", sb.showPercent) { v -> up { it.copy(showPercent = v) } }
        SwitchRow("Icons of apps with notifications", sb.showNotificationIcons) { v -> up { it.copy(showNotificationIcons = v) } }
        SwitchRow("5G / 4G label", sb.showNetworkType, "Needs the Phone permission") { v -> up { it.copy(showNetworkType = v) } }
        if (context.checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            ButtonRow("Allow Phone permission (for 5G label)") { perm.launch(Manifest.permission.READ_PHONE_STATE) }
        }
        SliderRow("Text size", sb.sizeSp, 11f..20f, { "${it.roundToInt()} sp" }) { v -> up { it.copy(sizeSp = v) } }
        Hint("Inside other apps Android always shows its own status bar – no launcher can change that.")
    }
}

// ===================================================================== Voice

@Composable
fun VoiceTab(f: FeatureCfg) {
    val context = LocalContext.current
    val v = f.voice
    var spoken by remember { mutableStateOf("") }
    var contact by remember { mutableStateOf("") }
    fun up(block: (com.iv.launcher.data.VoiceCfg) -> com.iv.launcher.data.VoiceCfg) = feat { it.copy(voice = block(it.voice)) }
    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
    Section(
        "IV Voice",
        "Say \"call Papa\", \"call Mom on speaker\" or \"open YouTube\". Uses Pixel's on-device speech, so it works without internet.",
    ) {
        SwitchRow("IV Voice", v.enabled) { b -> up { it.copy(enabled = b) } }
        SwitchRow("Mic button next to Search", v.micButton) { b -> up { it.copy(micButton = b) } }
        SwitchRow("Press Volume Down twice = IV Voice", v.volumeDownTwice, "Works anywhere, even on the lock screen (needs IV Helper)") { b -> up { it.copy(volumeDownTwice = b) } }
        SwitchRow("Offline only", v.offlineOnly, "Never use the internet for speech") { b -> up { it.copy(offlineOnly = b) } }
        ButtonRow("Try IV Voice now") { com.iv.launcher.voice.VoiceActivity.open(context) }
        ButtonRow("Allow mic, contacts & calls") {
            perms.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE))
        }
        Hint("For offline speech: Settings → System → Languages → On-device speech recognition → download English (India).")
        Hint("\"Hey Google\" itself belongs to Google Assistant / Gemini – it keeps working as before alongside IV.")
    }
    CommandsSection(v)
    Section("Nicknames", "Teach IV extra names. Mom/Mummy/Maa and Dad/Papa already work.") {
        v.aliases.forEach { (k, name) ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp)) {
                Text("\"$k\" → $name", color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text("✕", color = Color(0xFFFF6B6B), modifier = Modifier.clickable { up { it.copy(aliases = it.aliases - k) } })
            }
        }
        TextRow("When I say… (e.g. boss)", spoken) { spoken = it }
        TextRow("…call this contact (name as saved)", contact) { contact = it }
        ButtonRow("Add nickname") {
            if (spoken.isNotBlank() && contact.isNotBlank()) {
                up { it.copy(aliases = it.aliases + (spoken.trim().lowercase() to contact.trim())) }
                spoken = ""; contact = ""
            }
        }
    }
}

// ===================================================================== My commands

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun CommandsSection(v: com.iv.launcher.data.VoiceCfg) {
    val context = LocalContext.current
    var phrase by remember { mutableStateOf("") }
    var action by remember { mutableStateOf(com.iv.launcher.data.CmdAction.OPEN_APP) }
    var target by remember { mutableStateOf("") }
    var extra by remember { mutableStateOf("") }
    var speaker by remember { mutableStateOf(false) }
    var picking by remember { mutableStateOf(false) }
    var tryText by remember { mutableStateOf("") }
    var wake by remember { mutableStateOf(v.wakeWord) }

    fun runText(t: String) {
        val p = com.iv.launcher.voice.Commands.parse(t)
        if (p == null) say(context, "IV doesn't know \"$t\" yet – add it below")
        else say(context, com.iv.launcher.voice.Commands.run(context, p).message)
    }

    Section("Type a command", "Same as speaking. Works offline. Built in: call / message / whatsapp <name>, torch on/off, alarm 6:30 am, timer 5 minutes, play / next song, volume up, lock phone, selfie, navigate to <place>, open <app>.") {
        TextRow("e.g. call Papa on speaker", tryText) { tryText = it }
        ButtonRow("Run") { runText(tryText) }
    }

    Section("My commands", "Make your own: say or type the phrase → IV does the action. Your commands win over built-in ones.") {
        if (v.commands.isEmpty()) Hint("No commands yet. Example: \"gym time\" → Open an app → Spotify.")
        v.commands.forEach { c ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("\"${c.phrase}\"", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        c.action.title + (if (c.target.isNotBlank()) " · ${c.target}" else "") + (if (c.extra.isNotBlank()) " · \"${c.extra}\"" else "") + (if (c.speaker) " · speaker" else ""),
                        color = hintColor, fontSize = 12.5.sp,
                    )
                }
                Text("▶", color = MaterialTheme.colorScheme.primary, fontSize = 16.sp, modifier = Modifier.clickable { runText(c.phrase) }.padding(8.dp))
                Text("✕", color = Color(0xFFFF6B6B), modifier = Modifier.clickable {
                    feat { it.copy(voice = it.voice.copy(commands = it.voice.commands.filterNot { x -> x.id == c.id })) }
                }.padding(8.dp))
            }
        }
    }

    Section("New command") {
        TextRow("When I say / type…", phrase) { phrase = it }
        ChoiceRow("…IV does", com.iv.launcher.data.CmdAction.entries, action, { it.title }) { action = it; target = ""; extra = "" }
        if (action.needsTarget.isNotBlank()) {
            if (action == com.iv.launcher.data.CmdAction.OPEN_APP) {
                ButtonRow("App", value = target.ifBlank { "choose" }) { picking = true }
            } else {
                TextRow(action.needsTarget, target) { target = it }
            }
        }
        if (action.needsExtra.isNotBlank()) TextRow(action.needsExtra, extra) { extra = it }
        if (action == com.iv.launcher.data.CmdAction.CALL) SwitchRow("Start on loudspeaker", speaker) { speaker = it }
        ButtonRow("Save command") {
            val ok = phrase.isNotBlank() && (action.needsTarget.isBlank() || target.isNotBlank())
            if (!ok) say(context, "Fill in the phrase" + if (action.needsTarget.isNotBlank()) " and ${action.needsTarget.lowercase()}" else "")
            else {
                val cmd = com.iv.launcher.data.CustomCommand(
                    id = System.currentTimeMillis().toString(36), phrase = phrase.trim(), action = action,
                    target = target.trim(), extra = extra.trim(), speaker = speaker,
                )
                feat { it.copy(voice = it.voice.copy(commands = it.voice.commands + cmd)) }
                phrase = ""; target = ""; extra = ""; speaker = false
                say(context, "Command saved")
            }
        }
    }

    Section("Wake word", "Optional word before a command, e.g. \"Pixel, call Papa\". IV listens after you tap – it never listens in the background.") {
        TextRow("Wake word", wake) { wake = it; feat { f -> f.copy(voice = f.voice.copy(wakeWord = it.trim().lowercase())) } }
    }

    if (picking) AppPickerDialog("Which app?", onDismiss = { picking = false }) { a -> target = a.label; picking = false }
}
