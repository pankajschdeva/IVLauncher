package com.iv.launcher.ui

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import com.iv.launcher.data.BgType
import com.iv.launcher.data.ThemeCfg
import com.iv.launcher.data.Store
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Loads the picture chosen inside IV (if any). Re-loads when a new one is picked. */
@Composable
fun rememberBackgroundBitmap(theme: ThemeCfg): Bitmap? {
    val version = theme.background.imageVersion
    val wanted = theme.background.type == BgType.IMAGE
    val bmp by produceState<Bitmap?>(null, version, wanted) {
        value = if (wanted) withContext(Dispatchers.IO) { Store.loadBackground() } else null
    }
    return bmp
}

/** Draws the home background. SYSTEM = your normal Android wallpaper shows through. */
@Composable
fun IvBackground(theme: ThemeCfg, bitmap: Bitmap?, modifier: Modifier = Modifier) {
    val bg = theme.background
    Box(modifier.fillMaxSize()) {
        when (bg.type) {
            BgType.SYSTEM -> Unit
            BgType.SOLID -> Box(Modifier.fillMaxSize().background(bg.color.toColor()))
            BgType.GRADIENT -> Box(Modifier.fillMaxSize().background(bg.gradient.brush()))
            BgType.IMAGE -> {
                if (bitmap != null) {
                    Image(
                        bitmap = bitmap.asImageBitmap(),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxSize()
                            .then(if (bg.blurDp > 0f) Modifier.blur(bg.blurDp.dp, BlurredEdgeTreatment.Rectangle) else Modifier),
                    )
                } else {
                    Box(Modifier.fillMaxSize().background(Color.Black))
                }
            }
        }
        if (bg.dim > 0f) Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = bg.dim.coerceIn(0f, 0.9f))))
    }
}
