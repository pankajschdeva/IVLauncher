package com.iv.launcher.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.iv.launcher.data.AppInfo
import com.iv.launcher.data.StatusBarCfg
import com.iv.launcher.data.StatusInfo
import com.iv.launcher.data.ThemeCfg
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * IV's own status bar for the home screen (Android's bar is hidden there).
 * Left: time, date, apps with notifications. Right: 5G label, signal, Wi-Fi, battery.
 */
@Composable
fun IvStatusBar(theme: ThemeCfg, cfg: StatusBarCfg, notifApps: List<AppInfo>, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val st by StatusInfo.now.collectAsState()
    val color = theme.label.color.toColor()
    val font = rememberFont(theme.label.font, theme.customFontVersion)
    val now by produceState(System.currentTimeMillis(), cfg.showSeconds) {
        while (true) {
            value = System.currentTimeMillis()
            delay(if (cfg.showSeconds) 1000 else 60_000 - value % 60_000 + 30)
        }
    }
    val is24 = android.text.format.DateFormat.is24HourFormat(context)
    val time = SimpleDateFormat(if (is24) (if (cfg.showSeconds) "HH:mm:ss" else "HH:mm") else (if (cfg.showSeconds) "h:mm:ss" else "h:mm"), Locale.getDefault()).format(Date(now))
    val date = SimpleDateFormat("EEE d", Locale.getDefault()).format(Date(now))
    val size = cfg.sizeSp

    Row(
        modifier.fillMaxWidth().height(40.dp).padding(horizontal = 24.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        // ---- left
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(time, color = color, fontSize = size.sp, fontFamily = font, fontWeight = if (cfg.boldTime) FontWeight.Bold else FontWeight.Medium)
            if (cfg.showDate) {
                Spacer(Modifier.width(6.dp))
                Text(date, color = color.copy(alpha = 0.65f), fontSize = (size - 2).sp, fontFamily = font, fontWeight = FontWeight.Medium)
            }
            if (cfg.showNotificationIcons && notifApps.isNotEmpty()) {
                Spacer(Modifier.width(8.dp))
                notifApps.take(3).forEach { app ->
                    AppGlyph(app, theme.copy(icon = theme.icon.copy(showTile = false)), 14.dp, Modifier.padding(end = 3.dp))
                }
                if (notifApps.size > 3) Text("•", color = color.copy(alpha = 0.7f), fontSize = size.sp)
            }
        }
        // ---- right
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (st.airplane) {
                Text("✈", color = color, fontSize = size.sp)
                Spacer(Modifier.width(8.dp))
            } else {
                if (cfg.showNetworkType && st.netType.isNotBlank() && !st.wifi) {
                    Box(
                        Modifier.border(1.dp, color.copy(alpha = 0.6f), RoundedCornerShape(5.dp)).padding(horizontal = 4.dp),
                    ) { Text(st.netType, color = color, fontSize = (size - 4).sp, fontWeight = FontWeight.Bold) }
                    Spacer(Modifier.width(6.dp))
                }
                SignalBars(st.cellLevel, color)
                if (st.wifi) {
                    Spacer(Modifier.width(7.dp))
                    WifiIcon(st.wifiLevel, color)
                }
                Spacer(Modifier.width(8.dp))
            }
            BatteryIcon(st.battery, st.charging, color, cfg.showPercent, size)
        }
    }
}

@Composable
private fun SignalBars(level: Int, c: Color) {
    Canvas(Modifier.size(17.dp, 12.dp)) {
        val w = size.width / 4f
        for (i in 0 until 4) {
            val h = size.height * (0.35f + 0.65f * (i + 1) / 4f)
            drawRoundRect(
                color = if (i < level) c else c.copy(alpha = 0.3f),
                topLeft = Offset(i * w + 0.5f, size.height - h),
                size = Size(w - 2.5f, h),
                cornerRadius = CornerRadius(1.5f, 1.5f),
            )
        }
    }
}

@Composable
private fun WifiIcon(level: Int, c: Color) {
    Canvas(Modifier.size(16.dp, 12.dp)) {
        val cx = size.width / 2f
        val by = size.height
        for (i in 1..3) {
            val r = size.height * i / 3f
            drawArc(
                color = if (level >= i) c else c.copy(alpha = 0.3f),
                startAngle = 225f, sweepAngle = 90f, useCenter = false,
                topLeft = Offset(cx - r, by - r), size = Size(r * 2, r * 2),
                style = Stroke(width = 1.8.dp.toPx(), cap = StrokeCap.Round),
            )
        }
        drawCircle(c, radius = 1.6.dp.toPx(), center = Offset(cx, by - 1.dp.toPx()))
    }
}

@Composable
private fun BatteryIcon(level: Int, charging: Boolean, c: Color, showPercent: Boolean, sizeSp: Float) {
    val low = level <= 20 && !charging
    val fill = when {
        charging -> Color(0xFF34C759)
        low -> Color(0xFFFF3B30)
        else -> c
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(width = 27.dp, height = 13.dp)
                .border(1.2.dp, c.copy(alpha = 0.55f), RoundedCornerShape(4.dp))
                .padding(1.8.dp),
        ) {
            Box(
                Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(level.coerceIn(3, 100) / 100f)
                    .background(fill, RoundedCornerShape(2.5.dp)),
            )
            if (charging) {
                Canvas(Modifier.matchParentSize()) {
                    val p = Path().apply {
                        moveTo(size.width * 0.55f, 0f)
                        lineTo(size.width * 0.35f, size.height * 0.55f)
                        lineTo(size.width * 0.5f, size.height * 0.55f)
                        lineTo(size.width * 0.42f, size.height)
                        lineTo(size.width * 0.66f, size.height * 0.4f)
                        lineTo(size.width * 0.51f, size.height * 0.4f)
                        close()
                    }
                    drawPath(p, Color.White)
                }
            }
        }
        Box(Modifier.size(width = 2.dp, height = 5.dp).background(c.copy(alpha = 0.55f), RoundedCornerShape(topEnd = 1.dp, bottomEnd = 1.dp)))
        if (showPercent) {
            Spacer(Modifier.width(5.dp))
            Text("$level%", color = c, fontSize = (sizeSp - 2).sp, fontWeight = FontWeight.SemiBold)
        }
    }
}
