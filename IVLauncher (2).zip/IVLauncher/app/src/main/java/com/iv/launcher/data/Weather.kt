package com.iv.launcher.data

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.LocationManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.double
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.int
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import kotlin.math.roundToInt

data class HourWeather(val hour: String, val temp: Int, val code: Int)

data class WeatherNow(
    val city: String,
    val temp: Int,
    val code: Int,
    val isDay: Boolean,
    val high: Int,
    val low: Int,
    val hours: List<HourWeather>,
    val unit: WeatherUnit,
    val time: Long,
) {
    val emoji get() = Weather.emoji(code, isDay)
    val text get() = Weather.text(code)
}

/** Free weather from Open-Meteo (no API key, no account). */
object Weather {
    private val _now = MutableStateFlow<WeatherNow?>(null)
    val now: StateFlow<WeatherNow?> = _now
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    private var lastTry = 0L

    suspend fun refresh(context: Context, force: Boolean = false) = withContext(Dispatchers.IO) {
        val nowMs = System.currentTimeMillis()
        val cur = _now.value
        val cfg = Store.features.value.weather
        if (!cfg.enabled) return@withContext
        val maxAge = if (Store.features.value.batterySaver) 2 * 60 * 60_000L else 30 * 60_000L
        if (!force && cur != null && nowMs - cur.time < maxAge && cur.unit == cfg.unit) return@withContext
        if (!force && nowMs - lastTry < 60_000) return@withContext
        lastTry = nowMs
        runCatching {
            var lat = cfg.lat
            var lon = cfg.lon
            var city = cfg.city
            if (cfg.auto) {
                val loc = lastLocation(context) ?: error("Location not available – allow location for IV, or type a city in Weather settings")
                lat = loc.first; lon = loc.second
                city = cityName(context, loc.first, loc.second) ?: city.ifBlank { "Here" }
            } else if (lat == null || lon == null) {
                if (city.isBlank()) error("Type your city in IV Settings → Weather")
                val g = geocode(city) ?: error("City not found")
                lat = g.first; lon = g.second
                Store.editFeatures { it.copy(weather = it.weather.copy(lat = g.first, lon = g.second)) }
            }
            val unit = if (cfg.unit == WeatherUnit.F) "&temperature_unit=fahrenheit" else ""
            val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                "&current=temperature_2m,weather_code,is_day&daily=temperature_2m_max,temperature_2m_min" +
                "&hourly=temperature_2m,weather_code&forecast_days=2&timezone=auto$unit"
            val root = Json.parseToJsonElement(get(url)).jsonObject
            val current = root["current"]!!.jsonObject
            val daily = root["daily"]!!.jsonObject
            val hourly = root["hourly"]!!.jsonObject
            val currentTime = current["time"]!!.jsonPrimitive.content   // e.g. 2026-11-05T09:30
            val times = hourly["time"]!!.jsonArray.map { it.jsonPrimitive.content }
            val temps = hourly["temperature_2m"]!!.jsonArray
            val codes = hourly["weather_code"]!!.jsonArray
            val startIdx = times.indexOfFirst { it >= currentTime.take(13) }.coerceAtLeast(0)
            val hours = (startIdx until minOf(startIdx + 6, times.size)).map { i ->
                HourWeather(
                    hour = times[i].substringAfter('T').take(2).toInt().let { h -> if (h == 0) "12a" else if (h < 12) "${h}a" else if (h == 12) "12p" else "${h - 12}p" },
                    temp = temps[i].jsonPrimitive.doubleOrNull?.roundToInt() ?: 0,
                    code = codes[i].jsonPrimitive.doubleOrNull?.toInt() ?: 0,
                )
            }
            _now.value = WeatherNow(
                city = city,
                temp = current["temperature_2m"]!!.jsonPrimitive.double.roundToInt(),
                code = current["weather_code"]!!.jsonPrimitive.int,
                isDay = current["is_day"]?.jsonPrimitive?.int != 0,
                high = (daily["temperature_2m_max"] as JsonArray)[0].jsonPrimitive.double.roundToInt(),
                low = (daily["temperature_2m_min"] as JsonArray)[0].jsonPrimitive.double.roundToInt(),
                hours = hours,
                unit = cfg.unit,
                time = nowMs,
            )
            _error.value = null
        }.onFailure { _error.value = it.message ?: "Weather failed" }
        Unit
    }

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10_000
        c.readTimeout = 10_000
        c.setRequestProperty("User-Agent", "IVLauncher/1.0")
        return try { c.inputStream.bufferedReader().readText() } finally { c.disconnect() }
    }

    fun geocode(city: String): Pair<Double, Double>? {
        val q = URLEncoder.encode(city.trim(), "UTF-8")
        val root = Json.parseToJsonElement(get("https://geocoding-api.open-meteo.com/v1/search?name=$q&count=1")).jsonObject
        val first = (root["results"] as? JsonArray)?.firstOrNull() as? JsonObject ?: return null
        return first["latitude"]!!.jsonPrimitive.double to first["longitude"]!!.jsonPrimitive.double
    }

    fun hasLocationPermission(context: Context) =
        context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    private fun lastLocation(context: Context): Pair<Double, Double>? {
        if (!hasLocationPermission(context)) return null
        val lm = context.getSystemService(LocationManager::class.java) ?: return null
        val providers = listOf("fused", LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER, LocationManager.PASSIVE_PROVIDER)
        val best = providers.mapNotNull { p -> runCatching { lm.getLastKnownLocation(p) }.getOrNull() }.maxByOrNull { it.time }
        return best?.let { it.latitude to it.longitude }
    }

    @Suppress("DEPRECATION")
    private fun cityName(context: Context, lat: Double, lon: Double): String? = runCatching {
        Geocoder(context, Locale.getDefault()).getFromLocation(lat, lon, 1)?.firstOrNull()?.let {
            it.locality ?: it.subAdminArea ?: it.adminArea
        }
    }.getOrNull()

    fun emoji(code: Int, day: Boolean = true): String = when (code) {
        0 -> if (day) "☀️" else "🌙"
        1, 2 -> if (day) "🌤️" else "☁️"
        3 -> "☁️"
        45, 48 -> "🌫️"
        51, 53, 55, 56, 57 -> "🌦️"
        61, 63, 65, 66, 67, 80, 81, 82 -> "🌧️"
        71, 73, 75, 77, 85, 86 -> "❄️"
        95, 96, 99 -> "⛈️"
        else -> "🌡️"
    }

    fun text(code: Int): String = when (code) {
        0 -> "Clear"
        1 -> "Mostly clear"
        2 -> "Partly cloudy"
        3 -> "Cloudy"
        45, 48 -> "Fog"
        51, 53, 55, 56, 57 -> "Drizzle"
        61, 63, 66 -> "Rain"
        65, 67 -> "Heavy rain"
        80, 81, 82 -> "Showers"
        71, 73, 75, 77, 85, 86 -> "Snow"
        95, 96, 99 -> "Thunderstorm"
        else -> "—"
    }
}
