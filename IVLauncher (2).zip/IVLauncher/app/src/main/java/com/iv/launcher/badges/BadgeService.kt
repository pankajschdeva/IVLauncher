package com.iv.launcher.badges

import android.app.Notification
import android.content.ComponentName
import android.content.Context
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Counts notifications per app so the launcher can show numbers on icons.
 * Nothing is stored or sent anywhere: counts live in memory only.
 */
class BadgeService : NotificationListenerService() {

    override fun onListenerConnected() {
        connected.value = true
        recount()
        com.iv.launcher.data.Media.attach(this, component(this))
    }

    override fun onListenerDisconnected() {
        connected.value = false
        _counts.value = emptyMap()
        Live.clear()
        com.iv.launcher.data.Media.detach()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) = recount()
    override fun onNotificationRemoved(sbn: StatusBarNotification?) = recount()
    override fun onNotificationRankingUpdate(rankingMap: RankingMap?) = recount()

    private fun recount() {
        val active = runCatching { activeNotifications }.getOrNull() ?: return
        runCatching { Live.parse(this, active) }
        val rankingMap = runCatching { currentRanking }.getOrNull()
        val result = HashMap<String, Int>()

        // Group summaries are skipped when the app also posted the individual messages.
        val groupsWithChildren = active
            .filter { it.notification.group != null && (it.notification.flags and Notification.FLAG_GROUP_SUMMARY) == 0 }
            .map { it.packageName + "|" + it.notification.group }
            .toSet()

        for (sbn in active) {
            val n = sbn.notification
            if ((n.flags and Notification.FLAG_ONGOING_EVENT) != 0) continue
            if ((n.flags and Notification.FLAG_FOREGROUND_SERVICE) != 0) continue
            val isSummary = (n.flags and Notification.FLAG_GROUP_SUMMARY) != 0
            if (isSummary && (sbn.packageName + "|" + n.group) in groupsWithChildren) continue
            if (rankingMap != null) {
                val r = Ranking()
                if (rankingMap.getRanking(sbn.key, r) && !r.canShowBadge()) continue
            }
            val messages = runCatching {
                NotificationCompat.MessagingStyle.extractMessagingStyleFromNotification(n)?.messages?.size
            }.getOrNull() ?: 0
            val count = when {
                messages > 0 -> messages
                n.number > 0 -> n.number
                else -> 1
            }
            result[sbn.packageName] = (result[sbn.packageName] ?: 0) + count
        }
        _counts.value = result
    }

    companion object {
        private val _counts = MutableStateFlow<Map<String, Int>>(emptyMap())
        val counts: StateFlow<Map<String, Int>> = _counts
        val connected = MutableStateFlow(false)

        fun hasAccess(context: Context): Boolean =
            NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)

        fun component(context: Context) = ComponentName(context, BadgeService::class.java)
    }
}
