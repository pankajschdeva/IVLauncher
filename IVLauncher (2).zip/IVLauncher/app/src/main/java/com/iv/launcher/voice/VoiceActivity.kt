package com.iv.launcher.voice

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.iv.launcher.data.AppRepo
import com.iv.launcher.data.Store
import com.iv.launcher.ui.toColor

/**
 * IV Voice: say "call Papa", "call Mom on speaker", "open YouTube".
 * Uses the phone's on-device speech recognition (works without internet on Pixel).
 */
class VoiceActivity : ComponentActivity() {

    private var recognizer: SpeechRecognizer? = null
    private val status = mutableStateOf("Listening…")
    private val heard = mutableStateOf("")
    private val listening = mutableStateOf(false)
    private var triedOnline = false

    private val askPerms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (has(Manifest.permission.RECORD_AUDIO)) startListening()
        else { status.value = "Allow the microphone to use IV Voice"; listening.value = false }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        enableEdgeToEdge()
        setContent { VoiceUi() }
        intent?.getStringExtra("command")?.let { cmd -> runTyped(cmd); if (isFinishing) return }
        val needed = listOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE)
            .filter { !has(it) }
        if (needed.isEmpty()) startListening() else askPerms.launch(needed.toTypedArray())
    }

    private fun has(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun startListening(online: Boolean = false) {
        recognizer?.destroy()
        val offlineOnly = Store.features.value.voice.offlineOnly
        val r = when {
            !online && SpeechRecognizer.isOnDeviceRecognitionAvailable(this) -> SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
            !offlineOnly && SpeechRecognizer.isRecognitionAvailable(this) -> SpeechRecognizer.createSpeechRecognizer(this)
            else -> null
        }
        if (r == null) {
            status.value = "Speech recognition is not available on this phone"
            return
        }
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { listening.value = true; status.value = "Listening…" }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { listening.value = false; status.value = "Working…" }
            override fun onError(error: Int) {
                listening.value = false
                // On-device model missing for this language → try the normal recogniser once.
                if (!online && !triedOnline && !offlineOnly &&
                    (error == SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED || error == SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE)
                ) { triedOnline = true; startListening(online = true); return }
                status.value = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Didn't catch that. Tap the mic and try again."
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Allow the microphone for IV"
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Offline speech isn't ready. Settings → System → Languages → On-device speech → download English."
                    else -> "Voice error ($error). Tap the mic to retry."
                }
            }
            override fun onResults(results: Bundle?) {
                val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                handle(list)
            }
            override fun onPartialResults(partialResults: Bundle?) {
                partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { heard.value = it }
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
        heard.value = ""
        status.value = "Listening…"
        listening.value = true
        r.startListening(intent)
    }

    private fun handle(candidates: List<String>) {
        if (candidates.isEmpty()) { status.value = "Didn't catch that. Tap the mic and try again."; return }
        heard.value = candidates.first()
        var firstFail: Outcome? = null
        // Try every alternative the recogniser heard until one works.
        for (text in candidates) {
            val p = Commands.parse(text) ?: continue
            val out = Commands.run(this, p)
            if (out.ok) { toast(out.message); finish(); return }
            if (firstFail == null) firstFail = out
            if (!out.retryOtherHearing) break
        }
        status.value = firstFail?.message ?: "Try: \"call Papa\", \"call Mom on speaker\", \"torch on\", \"alarm 6 am\", \"open YouTube\""
    }

    /** Runs a typed command (same engine as voice). */
    fun runTyped(text: String) {
        if (text.isBlank()) return
        recognizer?.cancel()
        listening.value = false
        handle(listOf(text))
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        recognizer?.destroy()
        recognizer = null
        super.onDestroy()
    }

    @androidx.compose.runtime.Composable
    private fun VoiceUi() {
        val accent = Store.features.value.gestures.arcAccent.toColor()
        val isListening by listening
        val st by status
        val text by heard
        val pulse = rememberInfiniteTransition(label = "p")
        val s by pulse.animateFloat(1f, 1.25f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "s")
        Box(
            Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.55f)).clickable { finish() },
            contentAlignment = Alignment.BottomCenter,
        ) {
            Column(
                Modifier
                    .navigationBarsPadding()
                    .imePadding()
                    .padding(12.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(30.dp))
                    .background(Color(0xF2141417))
                    .clickable(enabled = false) {}
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("IV Voice", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(18.dp))
                Box(
                    Modifier
                        .size(84.dp)
                        .graphicsLayer { val k = if (isListening) s else 1f; scaleX = k; scaleY = k }
                        .clip(CircleShape)
                        .background(accent.copy(alpha = if (isListening) 0.9f else 0.35f))
                        .clickable { triedOnline = false; startListening() },
                    contentAlignment = Alignment.Center,
                ) { Text("🎙", fontSize = 32.sp) }
                Spacer(Modifier.height(18.dp))
                Text(
                    text.ifBlank { st }, color = Color.White, fontSize = 20.sp, textAlign = TextAlign.Center,
                    fontWeight = if (text.isBlank()) FontWeight.Normal else FontWeight.SemiBold,
                )
                if (text.isNotBlank()) {
                    Spacer(Modifier.height(6.dp))
                    Text(st, color = Color(0xFF9A9AA2), fontSize = 13.sp, textAlign = TextAlign.Center)
                }
                Spacer(Modifier.height(18.dp))
                var typed by androidx.compose.runtime.remember { mutableStateOf("") }
                androidx.compose.material3.OutlinedTextField(
                    value = typed,
                    onValueChange = { typed = it },
                    singleLine = true,
                    placeholder = { Text("…or type a command") },
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(imeAction = androidx.compose.ui.text.input.ImeAction.Go),
                    keyboardActions = androidx.compose.foundation.text.KeyboardActions(onGo = { runTyped(typed) }),
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("call Papa", "torch on", "alarm 6 am").forEach {
                        Text(
                            it, color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp,
                            modifier = Modifier.clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.08f))
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                        )
                    }
                }
            }
        }
    }

    companion object {
        fun open(context: Context) {
            runCatching {
                context.startActivity(
                    Intent(context, VoiceActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                )
            }
        }
    }
}
