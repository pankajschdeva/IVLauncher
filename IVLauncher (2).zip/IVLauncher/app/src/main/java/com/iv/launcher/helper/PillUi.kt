package com.iv.launcher.helper

import android.graphics.Bitmap
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.iv.launcher.badges.LiveItem
import com.iv.launcher.data.MediaNow
import com.iv.launcher.data.PillCfg
import com.iv.launcher.data.Store
import com.iv.launcher.ui.toColor
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow

class PillButton(val label: String, val onClick: () -> Unit)

data class PillEntry(
    val key: String,
    val title: String,
    val text: String,
    val icon: Bitmap?,
    val avatar: Bitmap?,
    val chronoBase: Long?,
    val countDown: Boolean,
    val buttons: List<PillButton>,
    val onOpen: (() -> Unit)?,
    val recording: Boolean,     // red dot
    val isMedia: Boolean = false,
    val playing: Boolean = false,
)

object PillState {
    val entries = MutableStateFlow<List<PillEntry>>(emptyList())

    fun compute(cfg: PillCfg, items: List<LiveItem>, media: MediaNow?): List<PillEntry> {
        if (!cfg.enabled) return emptyList()
        val out = ArrayList<PillEntry>()
        items.filter { it.pkg !in cfg.blocked }.forEach { li ->
            val timer = li.chronoBase != null
            val take = (li.isCall && cfg.calls) || (timer && cfg.timers) || cfg.allOngoing
            if (!take) return@forEach
            // media players are handled by the media entry below
            if (media != null && li.pkg == media.pkg) return@forEach
            out += PillEntry(
                key = li.key,
                title = li.title,
                text = li.text,
                icon = li.smallIcon,
                avatar = li.largeIcon,
                chronoBase = li.chronoBase,
                countDown = li.countDown,
                buttons = li.actions.map { a -> PillButton(a.title) { runCatching { a.intent.send() } } },
                onOpen = li.content?.let { pi -> { runCatching { pi.send() }; Unit } },
                recording = li.isCall || li.title.contains("record", true) || li.text.contains("record", true),
            )
        }
        if (media != null && cfg.media && media.pkg !in cfg.blocked) {
            out += PillEntry(
                key = "media", title = media.title, text = media.artist, icon = null, avatar = media.art,
                chronoBase = null, countDown = false,
                buttons = listOf(
                    PillButton("⏮") { com.iv.launcher.data.Media.previous() },
                    PillButton(if (media.playing) "❚❚" else "▶") { com.iv.launcher.data.Media.togglePlay() },
                    PillButton("⏭") { com.iv.launcher.data.Media.next() },
                ),
                onOpen = null, recording = false, isMedia = true, playing = media.playing,
            )
        }
        // Calls first, then timers/recordings, then music.
        return out.sortedBy { if (it.recording) 0 else if (it.isMedia) 2 else 1 }
    }
}

private fun fmtTimer(base: Long, countDown: Boolean, now: Long): String {
    val sec = ((if (countDown) base - now else now - base) / 1000).coerceAtLeast(0)
    val h = sec / 3600
    val m = (sec % 3600) / 60
    val s = sec % 60
    return if (h > 0) String.format("%d:%02d:%02d", h, m, s) else String.format("%02d:%02d", m, s)
}

@Composable
fun PillContent(onOpenApp: () -> Unit) {
    val entries by PillState.entries.collectAsState()
    val features by Store.features.collectAsState()
    val cfg = features.pill
    val first = entries.firstOrNull() ?: return
    var expanded by remember { mutableStateOf(false) }
    // Tick every second only while something shows a running timer (saves battery).
    val needTick = entries.any { it.chronoBase != null }
    val now by produceState(System.currentTimeMillis(), needTick) {
        value = System.currentTimeMillis()
        while (needTick) { delay(1000); value = System.currentTimeMillis() }
    }
    LaunchedEffect(expanded) { if (expanded) { delay(7000); expanded = false } }

    val bg = cfg.color.toColor()
    val fg = cfg.textColor.toColor()
    val shape = RoundedCornerShape(if (expanded) 30.dp else 50.dp)

    Column(
        Modifier
            .padding(top = cfg.yOffsetDp.coerceAtLeast(0f).dp)
            .animateContentSize(spring(dampingRatio = 0.75f, stiffness = 500f))
            .clip(shape)
            .background(bg)
            .then(if (cfg.outline) Modifier.border(1.dp, Color.White.copy(alpha = 0.18f), shape) else Modifier)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { expanded = !expanded },
    ) {
        if (!expanded) {
            Row(
                Modifier.height(cfg.heightDp.dp).widthIn(min = cfg.minWidthDp.dp).padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (first.recording) RecDot(cfg.dotColor.toColor())
                    else if (first.isMedia && first.avatar != null) Image(first.avatar.asImageBitmap(), null, Modifier.size(22.dp).clip(RoundedCornerShape(6.dp)))
                    else if (first.icon != null) Image(first.icon.asImageBitmap(), null, Modifier.size(16.dp), colorFilter = ColorFilter.tint(fg))
                    else if (first.isMedia) Text("♪", color = fg, fontSize = 14.sp)
                    Spacer(Modifier.width(6.dp))
                    val t = first.chronoBase?.let { fmtTimer(it, first.countDown, now) }
                    if (t != null) Text(t, color = fg, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                }
                // the camera sits in the middle of the pill
                Spacer(Modifier.width(36.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (first.isMedia) Bars(first.playing, fg)
                    else if (first.avatar != null) Image(first.avatar.asImageBitmap(), null, Modifier.size(22.dp).clip(CircleShape))
                    if (entries.size > 1) {
                        Spacer(Modifier.width(6.dp))
                        Text("+${entries.size - 1}", color = fg.copy(alpha = 0.7f), fontSize = 11.sp)
                    }
                }
            }
        } else {
            Column(Modifier.widthIn(min = 300.dp, max = 360.dp).padding(16.dp)) {
                entries.take(3).forEachIndexed { i, e ->
                    if (i > 0) Spacer(Modifier.height(12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (e.recording) { RecDot(cfg.dotColor.toColor()); Spacer(Modifier.width(6.dp)) }
                                e.chronoBase?.let { Text(fmtTimer(it, e.countDown, now), color = fg, fontSize = 14.sp) }
                            }
                            Text(
                                e.title.ifBlank { "Active" }, color = fg, fontSize = 22.sp, fontWeight = FontWeight.Bold,
                                maxLines = 1, overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.clickable { e.onOpen?.invoke() ?: onOpenApp() },
                            )
                            if (e.text.isNotBlank()) Text(e.text, color = fg.copy(alpha = 0.65f), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        if (e.avatar != null) {
                            Spacer(Modifier.width(10.dp))
                            Image(e.avatar.asImageBitmap(), null, Modifier.size(72.dp).clip(RoundedCornerShape(18.dp)))
                        }
                    }
                    if (e.buttons.isNotEmpty()) {
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            e.buttons.forEach { b ->
                                val danger = b.label.equals("end", true) || b.label.contains("hang", true) || b.label.contains("stop", true)
                                Box(
                                    Modifier
                                        .height(48.dp)
                                        .widthIn(min = 48.dp)
                                        .clip(RoundedCornerShape(50))
                                        .background(if (danger) Color(0xFF5A1E1E) else Color.White.copy(alpha = 0.14f))
                                        .clickable { b.onClick() }
                                        .padding(horizontal = 14.dp),
                                    contentAlignment = Alignment.Center,
                                ) {
                                    Text(b.label, color = if (danger) Color(0xFFFF5F57) else fg, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RecDot(c: Color) {
    val t = rememberInfiniteTransition(label = "rec")
    val a by t.animateFloat(1f, 0.35f, infiniteRepeatable(tween(800), RepeatMode.Reverse), label = "a")
    Box(Modifier.size(9.dp).clip(CircleShape).background(c.copy(alpha = a)))
}

@Composable
private fun Bars(playing: Boolean, c: Color) {
    val t = rememberInfiniteTransition(label = "bars")
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        listOf(500, 650, 420, 580).forEachIndexed { i, d ->
            val h by t.animateFloat(4f, 14f, infiniteRepeatable(tween(d), RepeatMode.Reverse), label = "b$i")
            Box(Modifier.width(3.dp).height(if (playing) h.dp else 4.dp).clip(RoundedCornerShape(2.dp)).background(c))
        }
    }
}
